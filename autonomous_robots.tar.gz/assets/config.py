"""
config.py — Central Configuration for Autonomous Vehicle Scheduler

PURPOSE:
    Single file that holds every tunable constant in the system.
    No magic numbers anywhere else in the codebase — all values live here.
    Changing a value here changes behaviour globally.

SECTIONS:
    1. Window / Display
    2. Map Geometry
    3. Road & Lane
    4. Vehicle Physics
    5. Scheduling & Timing
    6. Conflict Resolution
    7. Task System
    8. Parking
    9. Deadlock & Safety
    10. Colors — Vehicle States
    11. Colors — Map Elements
    12. Key Bindings
    13. ML / Debug
"""

# ─────────────────────────────────────────────────────────
# 1. WINDOW / DISPLAY
# ─────────────────────────────────────────────────────────

WINDOW_W          = 1680          # total window width  (px)
WINDOW_H          = 982           # total window height (px)
METRIC_PANEL_W    = 350           # right-side metrics panel width (px)
MAP_BORDER        = 50            # border around the road grid (px)
FPS               = 60            # simulation frames per second

# ─────────────────────────────────────────────────────────
# 2. MAP GEOMETRY
# ─────────────────────────────────────────────────────────

GRID_COLS         = 7             # number of cell columns
GRID_ROWS         = 6             # number of cell rows
# Resulting in 8 vertical road lines (cols+1) and 7 horizontal road lines (rows+1)

# ─────────────────────────────────────────────────────────
# 3. ROAD & LANE
# ─────────────────────────────────────────────────────────

LANE_WIDTH        = 12            # width of one traffic lane (px)
LANE_GAP          = 4             # median gap between two opposing lanes (px)
ROAD_WIDTH        = 2 * LANE_WIDTH + LANE_GAP   # = 28 px total road width
STATION_SIZE      = 20            # pickup/drop marker square size (px)
BUFFER_RADIUS     = 35            # transparent buffer zone around stations (px)

# ─────────────────────────────────────────────────────────
# 4. VEHICLE PHYSICS
# ─────────────────────────────────────────────────────────

VEHICLE_COUNT     = 10            # starting fleet size (max 20)
VEHICLE_MAX       = 20            # maximum allowed vehicles
BASE_SPEED        = 2.0           # pixels moved per tick at speed multiplier 1.0
VEHICLE_RADIUS    = 7             # visual circle radius (px)
COLLISION_RADIUS  = 14            # distance below which a confirmed collision is flagged

# ─────────────────────────────────────────────────────────
# 5. SCHEDULING & TIMING
# ─────────────────────────────────────────────────────────

# How many ticks ahead the system plans vehicle schedules.
# A vehicle's route is fully reserved for LOOKAHEAD_TICKS into the future.
LOOKAHEAD_TICKS       = 400

# Maximum ticks a departure can be delayed at Level 4 (Extended Delay).
# Level 1 now only tries 10 ticks; Level 4 handles longer waits.
# 300 ticks is enough for nearly all real conflicts on a 56-node grid.
MAX_DEPARTURE_DELAY   = 300       # 300 ticks ≈ 5 seconds at 60fps

# Interval between new task generation.
TASK_INTERVAL         = 90        # every 90 ticks ≈ 1.5 seconds

# ─────────────────────────────────────────────────────────
# 6. CONFLICT RESOLUTION TUNING
# ─────────────────────────────────────────────────────────

# Speed multiplier applied per reservation density unit.
# Raised from 0.15 → 0.35 so bots meaningfully slow/speed-up on busy segments.
DENSITY_WEIGHT        = 0.35      # higher = more aggressive slowdown on busy segments

# Minimum speed multiplier — vehicles never go below this.
# Lowered from 0.3 → 0.2 to give more adjustment range.
MIN_SPEED_MULT        = 0.2

# Lane propagation: speed reduction factor per hop.
PROPAGATION_FACTOR    = 0.90      # each follower gets 90% of the leader's multiplier
PROPAGATION_MAX_HOPS  = 3         # stop propagating after 3 hops

# Station proximity: extra slowdown when near a station.
STATION_PROXIMITY_MULT = 0.6      # reduce to 60% speed within buffer radius

# How many ticks after repair before a vehicle re-enters service.
REPAIR_TICKS          = 300       # ≈ 5 seconds at 60fps
STATION_DELAY_TICKS   = 60        # 1 second delay at pickup/drop stations

# Minimum ticks gap enforced at each intersection node.
# Bot A passes a node at tick 100, so bot B cannot enter until tick 100+INTERSECTION_CLEAR_TICKS.
# At BASE_SPEED=2.0 a typical 175px segment takes ~87 ticks to cross.
# Set to 20 so node clearance covers ~23% of a segment — visually distinct gaps.
INTERSECTION_CLEAR_TICKS = 20    # 20-tick exclusion window per node arrival

# ─────────────────────────────────────────────────────────
# 7. TASK SYSTEM
# ─────────────────────────────────────────────────────────

# Task priority weights for random generation.
# Keys match TaskPriority enum string values.
PRIORITY_WEIGHTS = {
    "HIGH":   20,   # 20% of tasks are HIGH priority
    "NORMAL": 50,   # 50% are NORMAL
    "LOW":    30,   # 30% are LOW
}

# Numeric weight for priority comparisons (higher = more important).
PRIORITY_WEIGHT = {
    "HIGH":   3,
    "NORMAL": 2,
    "LOW":    1,
}

# Ticks a task can be PENDING before its allocation priority is escalated.
STARVATION_THRESHOLD  = 300       # ≈ 5 seconds

# Ticks a task can be PENDING before it expires (FAILED / TIMEOUT).
TASK_EXPIRY_TICKS     = 600       # ≈ 10 seconds

# Maximum number of tasks pre-assigned to a single vehicle.
MAX_PENDING_TASKS     = 3

# ─────────────────────────────────────────────────────────
# 8. PARKING
# ─────────────────────────────────────────────────────────

# Ticks a vehicle waits at drop location before going to parking.
# Set to 0 automatically if task queue is non-empty.
PARKING_GRACE_TICKS   = 30

# Ticks vehicle must be idle before parking command is sent.
# Separate from grace period — provides hysteresis.
PARKING_IDLE_TICKS    = 15

# Ticks wait considered too long → triggers reactive deadlock check.
DEADLOCK_WAIT_THRESHOLD = 15

# ─────────────────────────────────────────────────────────
# 9. DEADLOCK & SAFETY
# ─────────────────────────────────────────────────────────

# How often the full deadlock scan runs (ticks).
DEADLOCK_CHECK_INTERVAL  = 60

# How many past reservations to keep for debugging (0 = delete immediately).
# Reservations older than current_tick - GC_KEEP_TICKS are deleted.
GC_KEEP_TICKS            = 10

# How many lines to keep in the brain decision log (ring buffer).
DECISION_LOG_SIZE        = 10

# When True, physical distance check runs each tick.
# Non-zero confirmed collisions turn the safety display red.
DEBUG_COLLISION_ASSERT   = True

# Throughput optimizer periodic trigger interval (ticks).
OPTIMIZER_INTERVAL       = 30

# Ticks to wait before pre-positioning during WAITING_FOR_START.
PREPOSITION_THRESHOLD    = 20

# Fleet utilisation signals.
UNDERPROVISION_TICKS     = 100    # ticks of queue > 2x fleet before signal
OVERPROVISION_TICKS      = 200    # ticks of idle > 50% fleet before signal

# ─────────────────────────────────────────────────────────
# 10. COLORS — VEHICLE STATES
# ─────────────────────────────────────────────────────────

COLOR_IDLE              = (200, 200, 200)   # light grey  — no task
COLOR_WAITING_FOR_START = (160,  32, 240)   # purple      — scheduled, not yet moving
COLOR_MOVING_TO_PICKUP  = (  0, 220, 220)   # cyan        — heading to pickup
COLOR_MOVING_TO_DEST    = (255, 220,   0)   # yellow      — carrying cargo
COLOR_MOVING_TO_PARKING = (100, 149, 255)   # light blue  — heading to park
COLOR_PARKED            = ( 30,  80, 200)   # dark blue   — parked
COLOR_FAILED            = (255,  60,  60)   # red         — broken down
COLOR_REPAIRING         = (255, 140,   0)   # orange      — being repaired

# ─────────────────────────────────────────────────────────
# 11. COLORS — MAP ELEMENTS
# ─────────────────────────────────────────────────────────

BG                = ( 28,  28,  28)   # dark background
BLACK             = (  0,   0,   0)
WHITE             = (255, 255, 255)
LANE_COLOR        = (100, 100, 100)   # road surface
MEDIAN_COLOR      = ( 55,  55,  55)   # lane divider
INTERSECTION_COL  = (255, 220,   0)   # intersection dot (yellow)
PICKUP_COLOR      = (  0, 200,  80)   # pickup station (green)
DROP_COLOR        = ( 30, 120, 255)   # drop station   (blue)
PANEL_BG          = ( 18,  18,  18)   # metrics panel background
ARROW_COLOR       = (160, 160, 160)   # direction arrows on road
BUFFER_ALPHA      = 60                # transparency for station buffer circles
PARKING_BG        = (  0,   0,   0)   # parking zone fill
GATE_ENTRY_COLOR  = (  0, 220,   0)   # entry gate green
GATE_EXIT_COLOR   = (220,   0,   0)   # exit gate red
ROUTE_COLOR       = ( 80, 200, 255)   # route preview line
HEATMAP_HIGH      = (255,  50,  50)   # hot zone on heatmap
HEATMAP_LOW       = ( 50, 100, 255)   # cool zone on heatmap
CONFLICT_COLOR    = (255, 100,   0)   # segment in conflict

# ─────────────────────────────────────────────────────────
# 12. KEY BINDINGS
# ─────────────────────────────────────────────────────────

import pygame

KEY_QUIT          = pygame.K_ESCAPE
KEY_FULLSCREEN    = pygame.K_F11
KEY_HEATMAP       = pygame.K_h        # toggle heatmap overlay
KEY_FAIL_VEHICLE  = pygame.K_f        # manually trigger a vehicle failure
KEY_SPEED_UP      = pygame.K_EQUALS   # increase simulation speed
KEY_SPEED_DOWN    = pygame.K_MINUS    # decrease simulation speed
KEY_PAUSE         = pygame.K_SPACE    # pause / resume
KEY_ADD_BOT       = pygame.K_b        # spawn one extra bot (up to VEHICLE_MAX)

# ─────────────────────────────────────────────────────────
# 13. ML / DEBUG
# ─────────────────────────────────────────────────────────

# Collect ML training samples every N ticks.
ML_SAMPLE_INTERVAL   = 30

# Rolling window for demand heatmap.
HEATMAP_WINDOW_TICKS = 500
