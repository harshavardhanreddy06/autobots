"""
test_runner.py — Unified 3-Scenario Test Runner

PURPOSE:
    Runs 3 targeted simulation stress tests that an interviewer can select
    from the on-screen test menu. Each test proves a different property of
    the Space-Time Scheduling System.

TESTS:
    TEST 1 — 4-Bot Junction Convergence (original test_junction.py)
        4 bots placed at compass points around junction 3_3.
        All dispatched simultaneously. Must cross ONE AT A TIME.
        PROVES: Collision avoidance at a single junction.

    TEST 2 — 8-Bot Multi-Path Merge
        Two groups of 4 bots approaching from opposite ends of the map.
        All routes merge onto the same central corridor.
        PROVES: System handles multi-point convergence with correct ordering.

    TEST 3 — Full Fleet Stress (20 Bots)
        All 20 bots spawned across the map and dispatched simultaneously
        to far destinations — maximum possible congestion.
        PROVES: System remains stable and collision-free under full load.

CONTROLS:
    1 / 2 / 3  — Switch active test
    SPACE       — Pause/Resume
    R           — Reset and re-dispatch current test
    +/-         — Sim speed
    ESC         — Quit

    On-screen buttons at the bottom replace all keyboard shortcuts.
"""

import json
import os
import sys
import math
import pygame

import config

# ── Override fleet size per-test (will be set in test setup) ──
config.VEHICLE_COUNT = 20   # max needed for Test 3

from config import (
    WINDOW_W, WINDOW_H, METRIC_PANEL_W, FPS, COLLISION_RADIUS,
    KEY_QUIT, KEY_FULLSCREEN, KEY_PAUSE, KEY_SPEED_UP, KEY_SPEED_DOWN,
)
from core.models import VehicleRecord, VehicleState, ParkingSlot
from brain.road_graph import graph
from brain.speed_coordinator import speed_coordinator
from brain.task_generator import task_gen
from brain.parking_manager import parking_mgr
from brain.metrics_tracker import metrics
from brain.central_brain import brain
from brain.reservation_manager import reservations
from vehicle.vehicle_registry import registry
from vehicle.vehicle import Vehicle
from visualization.renderer import renderer
from visualization.ui_panels import ui_panel
from visualization.button_bar import (
    button_bar,
    ACT_PAUSE, ACT_SPEED_UP, ACT_SPEED_DOWN,
    ACT_TEST_1, ACT_TEST_2, ACT_TEST_3,
)

# ── Map helpers ──────────────────────────────────────────

def load_map(path):
    with open(path) as f:
        return json.load(f)

def build_geometry(map_data):
    roads = map_data["roads"]
    return dict(
        vertical_x    = roads["vertical_roads_px"],
        horizontal_y  = roads["horizontal_roads_px"],
        intersections = [(i["x_px"], i["y_px"]) for i in map_data["intersections"]],
        pickups  = [(s["x_px"], s["y_px"], f"{s['grid_col']}_{s['grid_row']}")
                    for s in map_data["stations"]["pickups"]],
        drops    = [(s["x_px"], s["y_px"], f"{s['grid_col']}_{s['grid_row']}")
                    for s in map_data["stations"]["drops"]],
        parking_zones = [pygame.Rect(z["x_px"], z["y_px"], z["width_px"], z["height_px"])
                         for z in map_data["parking_zones"]],
        parking_gates = [(pygame.Rect(g["x_px"], g["y_px"], g["width_px"], g["height_px"]), g["type"])
                         for g in map_data["parking_gates"]],
        map_w = map_data["screen"]["width_px"] - map_data["screen"]["metric_panel_width_px"],
        map_h = map_data["screen"]["height_px"],
    )

def make_parking_slots(map_data):
    node_map = {f"{i['col']}_{i['row']}": (i["x_px"], i["y_px"])
                for i in map_data["intersections"]}
    slots = []
    for nid in ["2_2", "2_3", "3_2", "3_3", "4_3", "4_4", "5_3", "5_4"]:
        if nid in node_map:
            slots.append(ParkingSlot(node_id=nid, zone_id=0,
                                     center_px=node_map[nid], occupied_by=None))
    return slots


# ─────────────────────────────────────────────────────────
# TEST 1 — 4-Bot Junction Convergence
# ─────────────────────────────────────────────────────────

TEST1_NAME = "4-Bot Junction Convergence"
TEST1_DESC = [
    "4 bots cross junction 3_3 simultaneously.",
    "Watch them queue ONE-AT-A-TIME.",
    "Collisions must stay at ZERO.",
]
TEST1_JUNCTION = "3_3"
TEST1_BOTS = [
    ("2_3", "5_3"),   # V0: left  → right
    ("4_3", "1_3"),   # V1: right → left
    ("3_2", "3_5"),   # V2: top   → bottom
    ("3_4", "3_1"),   # V3: bottom → top
]


# ─────────────────────────────────────────────────────────
# TEST 2 — 8-Bot Multi-Path Merge
# ─────────────────────────────────────────────────────────

TEST2_NAME = "8-Bot Multi-Path Merge"
TEST2_DESC = [
    "8 bots from 4 corners merge onto",
    "the central corridor simultaneously.",
    "Tests multi-point traffic ordering.",
]
# Two groups approaching from all 4 corners, all merging through center corridor
TEST2_BOTS = [
    # Group A: horizontal merge (left side → right side via center row)
    ("0_3", "7_3"),   # V0: far left  → far right
    ("7_3", "0_3"),   # V1: far right → far left
    ("0_4", "7_4"),   # V2
    ("7_4", "0_4"),   # V3
    # Group B: vertical merge (top → bottom through center column)
    ("3_0", "3_6"),   # V4: top    → bottom
    ("3_6", "3_0"),   # V5: bottom → top
    ("4_0", "4_6"),   # V6
    ("4_6", "4_0"),   # V7
]


# ─────────────────────────────────────────────────────────
# TEST 3 — Full Fleet Stress (20 Bots)
# ─────────────────────────────────────────────────────────

TEST3_NAME = "Full Fleet Stress (20 Bots)"
TEST3_DESC = [
    "20 bots dispatched simultaneously.",
    "Maximum congestion — every road busy.",
    "Proves system stability at full load.",
]
# 20 bots spread across the map, all crossing through high-traffic zones
TEST3_BOTS = [
    # Row traversals
    ("0_0", "7_0"), ("7_0", "0_0"),
    ("0_1", "7_1"), ("7_1", "0_1"),
    ("0_2", "7_2"), ("7_2", "0_2"),
    ("0_3", "7_3"), ("7_3", "0_3"),
    ("0_4", "7_4"), ("7_4", "0_4"),
    # Column traversals
    ("0_0", "0_6"), ("7_0", "7_6"),
    ("3_0", "3_6"), ("4_0", "4_6"),
    ("2_0", "2_6"),
    # Diagonal-ish paths
    ("0_0", "7_6"), ("7_0", "0_6"),
    ("1_0", "6_6"), ("6_0", "1_6"),
    ("0_2", "7_4"),
]


# ─────────────────────────────────────────────────────────
# Test Definitions Dictionary
# ─────────────────────────────────────────────────────────

TESTS = {
    1: (TEST1_NAME, TEST1_DESC, TEST1_BOTS),
    2: (TEST2_NAME, TEST2_DESC, TEST2_BOTS),
    3: (TEST3_NAME, TEST3_DESC, TEST3_BOTS),
}


# ─────────────────────────────────────────────────────────
# Shared test utilities
# ─────────────────────────────────────────────────────────

def reset_simulation_state():
    """
    Clear all singletons so a fresh test can start.

    Uses the actual APIs available on each singleton:
      - reservations: release() per vehicle (no bulk clear)
      - registry: clear() exists
      - metrics: zero out counters manually
    """
    # Release all vehicle reservations first (before clearing registry)
    for rec in registry.snapshot():
        try:
            reservations.release(rec.vehicle_id)
        except Exception:
            pass

    # Clear vehicle registry
    registry.clear()

    # Zero out relevant metrics counters for a clean test display
    metrics.confirmed_collisions  = 0
    metrics.prevented_collisions  = 0
    metrics.predicted_collisions  = 0
    metrics.tasks_completed       = 0
    metrics.tasks_failed          = 0
    metrics.tasks_generated       = 0
    metrics.tasks_assigned        = 0
    metrics.tasks_expired         = 0
    metrics.level_1_departures    = 0
    metrics.level_2_speed         = 0
    metrics.level_3_propagation   = 0
    metrics.level_4_optimiser     = 0
    metrics.level_5_reroutes      = 0
    metrics.level_6_emergency     = 0
    metrics.failures              = 0

    # GC the reservation table completely (tick=999999 clears all past entries)
    try:
        reservations.gc(999_999)
    except Exception:
        pass


def spawn_bots(bot_configs: list, node_map: dict) -> list:
    """
    Spawn vehicles at the start nodes defined in bot_configs.
    Returns list of Vehicle executor objects.
    """
    vehicles = []
    for idx, (start_node, _) in enumerate(bot_configs):
        vid = f"V{idx}"
        if start_node not in node_map:
            print(f"[test] WARNING: node {start_node} not in map — skipping V{idx}")
            continue
        px, py = node_map[start_node]
        record = VehicleRecord(
            vehicle_id = vid,
            state      = VehicleState.IDLE,
            x_px       = float(px),
            y_px       = float(py),
            node_id    = start_node,
        )
        registry.register(record)
        vehicles.append(Vehicle(vid))
    return vehicles


def dispatch_bots(bot_configs: list, tick: int):
    """Dispatch all bots in one tick using the brain pipeline."""
    for idx, (start_node, dest_node) in enumerate(bot_configs):
        vid = f"V{idx}"
        rec = registry.get(vid)
        if not rec or rec.state != VehicleState.IDLE:
            continue
        success = brain._run_pipeline(
            vehicle_id       = vid,
            start_node       = start_node,
            end_node         = dest_node,
            current_tick     = tick,
            task_id          = None,
            destination_type = "TO_DROP",
            task_priority    = "NORMAL",
        )
        if not success:
            print(f"[test] V{idx}: scheduling FAILED @ tick {tick}")


def check_physical_collisions() -> int:
    """Check and count physical bot collisions this tick."""
    active_states = {VehicleState.MOVING_TO_PICKUP, VehicleState.MOVING_TO_DEST,
                     VehicleState.MOVING_TO_PARKING}
    active = [r for r in registry.snapshot() if r.state in active_states]
    count = 0
    for i in range(len(active)):
        for j in range(i + 1, len(active)):
            a, b = active[i], active[j]
            if math.hypot(a.x_px - b.x_px, a.y_px - b.y_px) < COLLISION_RADIUS:
                count += 1
    if count > 0:
        metrics.confirmed_collisions += count
    return count


# ─────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────

def main():
    pygame.init()
    pygame.font.init()
    screen = pygame.display.set_mode((WINDOW_W, WINDOW_H), pygame.RESIZABLE)
    pygame.display.set_caption("🧪 Autonomous Robot Scheduler — Test Runner")
    clock  = pygame.time.Clock()

    here     = os.path.dirname(os.path.abspath(__file__))
    map_data = load_map(os.path.join(here, "map_config.json"))
    geo      = build_geometry(map_data)
    node_map = {f"{i['col']}_{i['row']}": (i["x_px"], i["y_px"])
                for i in map_data["intersections"]}

    # One-time setup
    graph.build(map_data["intersections"])
    print(f"[test] Graph built: {graph.node_count()} nodes")

    all_station_px = ([(s["x_px"], s["y_px"]) for s in map_data["stations"]["pickups"]] +
                      [(s["x_px"], s["y_px"]) for s in map_data["stations"]["drops"]])
    speed_coordinator.set_stations(all_station_px)

    pickup_data = [{"node_id": f"{s['grid_col']}_{s['grid_row']}", "x_px": s["x_px"], "y_px": s["y_px"]}
                   for s in map_data["stations"]["pickups"]]
    drop_data   = [{"node_id": f"{s['grid_col']}_{s['grid_row']}", "x_px": s["x_px"], "y_px": s["y_px"]}
                   for s in map_data["stations"]["drops"]]
    task_gen.set_stations(pickup_data, drop_data)
    parking_mgr.set_slots(make_parking_slots(map_data))

    renderer.setup(
        vertical_x    = geo["vertical_x"],
        horizontal_y  = geo["horizontal_y"],
        intersections = geo["intersections"],
        pickups       = geo["pickups"],
        drops         = geo["drops"],
        parking_zones = geo["parking_zones"],
        parking_gates = geo["parking_gates"],
        map_w         = geo["map_w"],
        map_h         = geo["map_h"],
    )

    # ── Test state ────────────────────────────────────────

    current_test = 1
    vehicles     = []
    dispatched   = False
    tick         = 0
    paused       = False
    sim_speed    = 1.0
    speed_acc    = 0.0
    running      = True
    fullscreen   = False
    map_w        = geo["map_w"]
    map_h        = geo["map_h"]

    def load_test(test_num: int):
        """Reset simulation and spawn bots for the chosen test."""
        nonlocal vehicles, dispatched, tick
        reset_simulation_state()
        _, _, bot_cfgs = TESTS[test_num]
        vehicles   = spawn_bots(bot_cfgs, node_map)
        dispatched = False
        tick       = 0
        name, _, _ = TESTS[test_num]
        pygame.display.set_caption(f"🧪 Test {test_num}: {name}")
        print(f"\n[test] ── Loaded Test {test_num}: {name} ──")
        print(f"[test] {len(vehicles)} bots ready. Dispatching at tick 30...")

    load_test(current_test)

    try:
        overlay_font = pygame.font.SysFont("Arial", 14, bold=True)
        label_font   = pygame.font.SysFont("Arial", 12)
    except Exception:
        overlay_font = label_font = pygame.font.Font(None, 14)

    # ── Main Loop ─────────────────────────────────────────
    while running:
        dt = clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == KEY_QUIT:
                    running = False
                elif event.key == KEY_FULLSCREEN:
                    fullscreen = not fullscreen
                    screen = pygame.display.set_mode(
                        (0, 0) if fullscreen else (WINDOW_W, WINDOW_H),
                        pygame.FULLSCREEN if fullscreen else pygame.RESIZABLE
                    )
                elif event.key == KEY_PAUSE:
                    paused = not paused
                elif event.key in (KEY_SPEED_UP, pygame.K_EQUALS):
                    sim_speed = min(8.0, sim_speed + 0.5)
                elif event.key == KEY_SPEED_DOWN:
                    sim_speed = max(0.25, sim_speed - 0.25)
                elif event.key == pygame.K_r:
                    load_test(current_test)
                elif event.key == pygame.K_1:
                    current_test = 1; load_test(1)
                elif event.key == pygame.K_2:
                    current_test = 2; load_test(2)
                elif event.key == pygame.K_3:
                    current_test = 3; load_test(3)

            elif event.type == pygame.VIDEORESIZE and not fullscreen:
                screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)
                map_w = event.w - METRIC_PANEL_W
                map_h = event.h
                renderer._map_w = map_w
                renderer._map_h = map_h
                renderer._buffer_surf = None

            # ── Button bar events ──────────────────────────
            btn_actions = button_bar.handle_event(event, map_w, map_h)
            for act in btn_actions:
                if act == ACT_PAUSE:
                    paused = not paused
                elif act == ACT_SPEED_UP:
                    sim_speed = min(8.0, sim_speed + 0.5)
                elif act == ACT_SPEED_DOWN:
                    sim_speed = max(0.25, sim_speed - 0.25)
                elif act == ACT_TEST_1:
                    current_test = 1; load_test(1)
                elif act == ACT_TEST_2:
                    current_test = 2; load_test(2)
                elif act == ACT_TEST_3:
                    current_test = 3; load_test(3)

        # ── Simulation step ────────────────────────────────
        if not paused:
            speed_acc += sim_speed
            steps = int(speed_acc)
            speed_acc -= steps

            for _ in range(steps):
                tick += 1

                # Dispatch bots at tick 30
                if tick == 30 and not dispatched:
                    dispatched = True
                    _, _, bot_cfgs = TESTS[current_test]
                    dispatch_bots(bot_cfgs, tick)
                    print(f"[test] Dispatched {len(bot_cfgs)} bots @ tick {tick}")

                # Brain support (no task gen — manual control)
                parking_mgr.update(tick)
                if tick % 60 == 0:
                    reservations.gc(tick)

                # Vehicle movement
                for v in vehicles:
                    v.tick(tick)

                check_physical_collisions()

        # ── Render ────────────────────────────────────────
        screen.fill((18, 18, 28))
        renderer.draw(screen, tick)

        # Highlight junction for Test 1
        if current_test == 1:
            try:
                jx, jy = node_map[TEST1_JUNCTION]
                pygame.draw.circle(screen, (255, 60, 60), (int(jx), int(jy)), 22, 3)
                lbl = label_font.render("← JUNCTION 3_3", True, (255, 60, 60))
                screen.blit(lbl, (jx + 25, jy - 8))
            except Exception:
                pass

        # Metrics panel
        pygame.draw.rect(screen, (40, 40, 55), (map_w, 0, METRIC_PANEL_W, map_h))
        ui_panel.draw(screen, map_w, map_h, tick, sim_speed, paused)

        # ── Test info overlay (top-left) ───────────────────
        test_name, test_desc, bot_cfgs = TESTS[current_test]

        header_lines = [
            f"TEST {current_test}: {test_name}",
            f"Tick: {tick}   Bots: {len(vehicles)}   Speed: {sim_speed:.1f}x",
            f"Confirmed Collisions: {metrics.confirmed_collisions}  "
            f"{'← ZERO ✓' if metrics.confirmed_collisions == 0 else '← FAIL ✗'}",
            f"Prevented Collisions: {metrics.prevented_collisions}",
            "",
        ] + test_desc + [
            "",
            "Keys: 1/2/3=Test  R=Reset  SPACE=Pause  +/-=Speed  ESC=Quit",
        ]

        for li, line in enumerate(header_lines):
            if "ZERO ✓" in line:
                color = (80, 255, 80)
            elif "FAIL ✗" in line:
                color = (255, 80, 80)
            elif li == 0:
                color = (255, 220, 50)
            elif "Keys:" in line:
                color = (130, 130, 160)
            else:
                color = (200, 200, 220)
            surf = overlay_font.render(line, True, color)
            screen.blit(surf, (10, 10 + li * 18))

        # ── Test selector tab strip ────────────────────────
        tab_y = map_h - 80
        for t in range(1, 4):
            tname = TESTS[t][0]
            tw    = min(220, (map_w - 20) // 3 - 8)
            tx    = 10 + (t - 1) * (tw + 8)
            tcol  = (40, 110, 40) if t == current_test else (35, 35, 55)
            tbor  = (80, 200, 80) if t == current_test else (60, 60, 90)
            pygame.draw.rect(screen, tcol, (tx, tab_y, tw, 22), border_radius=5)
            pygame.draw.rect(screen, tbor, (tx, tab_y, tw, 22), 1, border_radius=5)
            ts = label_font.render(f"{t}: {tname[:24]}", True,
                                   (220, 255, 220) if t == current_test else (150, 150, 180))
            screen.blit(ts, (tx + 5, tab_y + 4))

        # ── Button bar ────────────────────────────────────
        button_bar.draw(screen, map_w, map_h, paused, sim_speed)

        # FPS
        try:
            fps_s = label_font.render(f"FPS: {clock.get_fps():.0f}", True, (70, 70, 90))
            screen.blit(fps_s, (4, map_h - 95))
        except Exception:
            pass

        pygame.display.flip()

    pygame.quit()
    print(f"\n[test] Finished at tick {tick}")
    print(f"       Test: {TESTS[current_test][0]}")
    print(f"       Confirmed collisions: {metrics.confirmed_collisions}  (expected: 0)")
    print(f"       Prevented collisions: {metrics.prevented_collisions}")


if __name__ == "__main__":
    main()
