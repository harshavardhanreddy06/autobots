"""
test_junction.py — 4-Bot Junction Convergence Test

PURPOSE:
    A focused stress test for the collision avoidance system.
    Exactly 4 bots are placed at the 4 compass directions around
    junction node 3_3 (the center of the map). All 4 are forced to
    route THROUGH 3_3 to the opposite side simultaneously.

    With correct collision avoidance, each bot waits its turn and
    crosses the junction ONE-BY-ONE with a visible gap.

    Without collision avoidance, all 4 would visually pass through
    the same pixel at the same tick — clearly visible as a single
    merged dot.

JUNCTION LAYOUT:
                       V2 (3_2) ↓
                           |
    V0 (2_3) →  — — — [ 3_3 ] — — —  ← V1 (4_3)
                           |
                       V3 (3_4) ↑

    Each bot crosses 3_3 heading to the opposite side:
        V0: left  → right  (2_3 → 3_3 → 4_3 → 5_3 → 6_3)
        V1: right → left   (4_3 → 3_3 → 2_3 → 1_3 → 0_3)
        V2: top   → bottom (3_2 → 3_3 → 3_4 → 3_5 → 3_6)
        V3: bottom → top   (3_4 → 3_3 → 3_2 → 3_1 → 3_0)

HOW TO RUN:
    cd /Users/harshareddy/Downloads/Autonomous_Robots
    python3 test_junction.py

WHAT TO WATCH:
    - All 4 bots converge toward the yellow dot at 3_3
    - They should pass through ONE AT A TIME (visible gap between each)
    - The "Confirmed Collisions" counter on the right panel should stay at 0
    - Brain log on the right shows departure delay decisions (L1)
"""

import json
import os
import sys
import pygame

# ── Import all simulation modules ────────────────────────
import config

# Override fleet size to exactly 4 for this test
config.VEHICLE_COUNT = 4

from config import (
    WINDOW_W, WINDOW_H, METRIC_PANEL_W, FPS,
    KEY_QUIT, KEY_FULLSCREEN, KEY_PAUSE, KEY_SPEED_UP, KEY_SPEED_DOWN,
)
from core.models import VehicleRecord, VehicleState, ParkingSlot
from brain.road_graph import graph
from brain.speed_coordinator import speed_coordinator
from brain.task_generator import task_gen
from brain.parking_manager import parking_mgr
from brain.metrics_tracker import metrics
from brain.central_brain import brain
from brain.reservation_manager import reservations
from vehicle.vehicle_registry import registry
from vehicle.vehicle import Vehicle
from visualization.renderer import renderer
from visualization.ui_panels import ui_panel


# ── Map helpers (same as main.py) ───────────────────────

def load_map(path):
    with open(path) as f:
        return json.load(f)

def build_geometry(map_data):
    roads = map_data["roads"]
    vertical_x   = roads["vertical_roads_px"]
    horizontal_y = roads["horizontal_roads_px"]
    intersections = [(i["x_px"], i["y_px"]) for i in map_data["intersections"]]
    pickups  = [(s["x_px"], s["y_px"], f"{s['grid_col']}_{s['grid_row']}")
                for s in map_data["stations"]["pickups"]]
    drops    = [(s["x_px"], s["y_px"], f"{s['grid_col']}_{s['grid_row']}")
                for s in map_data["stations"]["drops"]]
    parking_zones = [pygame.Rect(z["x_px"], z["y_px"], z["width_px"], z["height_px"])
                     for z in map_data["parking_zones"]]
    parking_gates = [(pygame.Rect(g["x_px"], g["y_px"], g["width_px"], g["height_px"]), g["type"])
                     for g in map_data["parking_gates"]]
    map_w = map_data["screen"]["width_px"] - map_data["screen"]["metric_panel_width_px"]
    map_h = map_data["screen"]["height_px"]
    return dict(vertical_x=vertical_x, horizontal_y=horizontal_y,
                intersections=intersections, pickups=pickups, drops=drops,
                parking_zones=parking_zones, parking_gates=parking_gates,
                map_w=map_w, map_h=map_h)

def make_parking_slots(map_data):
    node_map = {f"{i['col']}_{i['row']}": (i["x_px"], i["y_px"])
                for i in map_data["intersections"]}
    slots = []
    for nid in ["2_2", "2_3", "3_2", "3_3", "4_3", "4_4", "5_3", "5_4"]:
        if nid in node_map:
            slots.append(ParkingSlot(node_id=nid, zone_id=0,
                                     center_px=node_map[nid], occupied_by=None))
    return slots


# ── 4-bot junction test setup ───────────────────────────

# The junction node all 4 bots must cross
JUNCTION_NODE = "3_3"

# Each bot: (start_node, destination_node)
# Routes are chosen so that ALL pass through JUNCTION_NODE
BOT_CONFIGS = [
    ("2_3", "5_3"),   # V0: left  → right  (through 3_3 → 4_3 → 5_3)
    ("4_3", "1_3"),   # V1: right → left   (through 3_3 → 2_3 → 1_3)
    ("3_2", "3_5"),   # V2: top   → bottom (through 3_3 → 3_4 → 3_5)
    ("3_4", "3_1"),   # V3: bottom → top   (through 3_3 → 3_2 → 3_1)
]


def spawn_test_vehicles(map_data):
    """
    Spawn exactly 4 vehicles at the 4 compass positions around junction 3_3.
    Returns list of Vehicle executor objects.
    """
    node_map = {f"{i['col']}_{i['row']}": (i["x_px"], i["y_px"])
                for i in map_data["intersections"]}

    vehicles = []
    for idx, (start_node, _dest_node) in enumerate(BOT_CONFIGS):
        vid = f"V{idx}"
        px, py = node_map[start_node]

        record = VehicleRecord(
            vehicle_id=vid,
            state=VehicleState.IDLE,
            x_px=float(px),
            y_px=float(py),
            node_id=start_node,
        )
        registry.register(record)
        vehicles.append(Vehicle(vid))

    return vehicles


def dispatch_all_bots(vehicles, tick):
    """
    Directly tell each bot where to go using the brain pipeline.
    All 4 are dispatched in the same tick so they all converge at once.
    """
    for idx, (start_node, dest_node) in enumerate(BOT_CONFIGS):
        vid = f"V{idx}"
        rec = registry.get(vid)
        if not rec or rec.state != VehicleState.IDLE:
            continue

        # Run the scheduling pipeline directly
        success = brain._run_pipeline(
            vehicle_id       = vid,
            start_node       = start_node,
            end_node         = dest_node,
            current_tick     = tick,
            task_id          = None,
            destination_type = "TO_DROP",   # any type — just needs to move
            task_priority    = "NORMAL",
        )
        if success:
            print(f"[test] {vid}: {start_node} → {dest_node} scheduled OK")
        else:
            print(f"[test] {vid}: scheduling FAILED — will retry next tick")


def check_physical_collisions():
    """Count confirmed physical collisions (same as main.py)."""
    import math
    from config import COLLISION_RADIUS
    active_states = {VehicleState.MOVING_TO_PICKUP, VehicleState.MOVING_TO_DEST,
                     VehicleState.MOVING_TO_PARKING}
    active = [r for r in registry.snapshot() if r.state in active_states]
    collisions = 0
    for i in range(len(active)):
        for j in range(i + 1, len(active)):
            a, b = active[i], active[j]
            if math.hypot(a.x_px - b.x_px, a.y_px - b.y_px) < COLLISION_RADIUS:
                collisions += 1
    if collisions > 0:
        metrics.confirmed_collisions += collisions
    return collisions


# ── Main test loop ───────────────────────────────────────

def main():
    pygame.init()
    pygame.font.init()
    screen = pygame.display.set_mode((WINDOW_W, WINDOW_H), pygame.RESIZABLE)
    pygame.display.set_caption("🔴 4-Bot Junction Test — Watch for collision at center node 3_3")
    clock = pygame.time.Clock()

    # Load map
    here     = os.path.dirname(os.path.abspath(__file__))
    map_data = load_map(os.path.join(here, "map_config.json"))
    geo      = build_geometry(map_data)

    # Build graph
    graph.build(map_data["intersections"])
    print(f"[test] Graph built: {graph.node_count()} nodes")

    # Station + parking setup (needed by brain modules)
    all_station_px = (
        [(s["x_px"], s["y_px"]) for s in map_data["stations"]["pickups"]] +
        [(s["x_px"], s["y_px"]) for s in map_data["stations"]["drops"]]
    )
    speed_coordinator.set_stations(all_station_px)

    pickup_data = [{"node_id": f"{s['grid_col']}_{s['grid_row']}",
                    "x_px": s["x_px"], "y_px": s["y_px"]}
                   for s in map_data["stations"]["pickups"]]
    drop_data   = [{"node_id": f"{s['grid_col']}_{s['grid_row']}",
                    "x_px": s["x_px"], "y_px": s["y_px"]}
                   for s in map_data["stations"]["drops"]]
    task_gen.set_stations(pickup_data, drop_data)

    parking_slots = make_parking_slots(map_data)
    parking_mgr.set_slots(parking_slots)

    renderer.setup(
        vertical_x    = geo["vertical_x"],
        horizontal_y  = geo["horizontal_y"],
        intersections = geo["intersections"],
        pickups       = geo["pickups"],
        drops         = geo["drops"],
        parking_zones = geo["parking_zones"],
        parking_gates = geo["parking_gates"],
        map_w         = geo["map_w"],
        map_h         = geo["map_h"],
    )

    # Spawn 4 bots at compass positions around junction 3_3
    vehicles = spawn_test_vehicles(map_data)
    print(f"[test] 4 bots spawned around junction {JUNCTION_NODE}")
    print(f"[test] V0: 2_3→5_3  |  V1: 4_3→1_3  |  V2: 3_2→3_5  |  V3: 3_4→3_1")
    print(f"[test] All routes cross junction {JUNCTION_NODE}")
    print(f"[test] Watch for ONE-AT-A-TIME crossing. Press SPACE=pause  ESC=quit")

    # Simulation state
    tick         = 0
    paused       = False
    fullscreen   = False
    sim_speed    = 1.0
    speed_acc    = 0.0
    running      = True
    dispatched   = False    # have we sent the 4 bots yet?
    map_w        = geo["map_w"]
    map_h        = geo["map_h"]

    # Overlay font for the junction indicator
    try:
        overlay_font = pygame.font.SysFont("Arial", 14, bold=True)
    except Exception:
        overlay_font = None

    while running:
        dt = clock.tick(FPS)

        # Events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == KEY_QUIT:
                    running = False
                elif event.key == KEY_FULLSCREEN:
                    fullscreen = not fullscreen
                    if fullscreen:
                        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
                    else:
                        screen = pygame.display.set_mode((WINDOW_W, WINDOW_H), pygame.RESIZABLE)
                elif event.key == KEY_PAUSE:
                    paused = not paused
                elif event.key in (KEY_SPEED_UP, pygame.K_EQUALS):
                    sim_speed = min(8.0, sim_speed + 0.5)
                elif event.key == KEY_SPEED_DOWN:
                    sim_speed = max(0.25, sim_speed - 0.25)
                elif event.key == pygame.K_r:
                    # R = Reset: re-dispatch bots if they've finished
                    dispatched = False
                    print("[test] Resetting — bots will be re-dispatched")
            elif event.type == pygame.VIDEORESIZE:
                if not fullscreen:
                    screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)
                    map_w = event.w - METRIC_PANEL_W
                    map_h = event.h
                    renderer._map_w = map_w
                    renderer._map_h = map_h
                    renderer._buffer_surf = None

        if not paused:
            speed_acc += sim_speed
            steps = int(speed_acc)
            speed_acc -= steps

            for _ in range(steps):
                tick += 1

                # Dispatch all 4 bots on tick 30 (lets the window open and render first)
                if tick == 30 and not dispatched:
                    dispatched = True
                    dispatch_all_bots(vehicles, tick)

                # Brain tick (handles collision resolution, GC, etc.)
                # Skip task generation — we control the scenario manually
                from brain.parking_manager import parking_mgr as pmgr
                pmgr.update(tick)
                from brain.reservation_manager import reservations as res
                if tick % 60 == 0:
                    res.gc(tick)

                # Vehicle movement
                for v in vehicles:
                    v.tick(tick)

                # Physical collision check
                check_physical_collisions()

        # Render
        screen.fill((20, 20, 20))
        renderer.draw(screen, tick)

        # Draw junction 3_3 highlight ring so user can focus on it
        try:
            node_map = {f"{i['col']}_{i['row']}": (i["x_px"], i["y_px"])
                        for i in map_data["intersections"]}
            jx, jy = node_map[JUNCTION_NODE]
            pygame.draw.circle(screen, (255, 60, 60), (int(jx), int(jy)), 22, 3)
            if overlay_font:
                lbl = overlay_font.render("← WATCH HERE", True, (255, 60, 60))
                screen.blit(lbl, (jx + 25, jy - 8))
        except Exception:
            pass

        # Metrics panel separator
        pygame.draw.rect(screen, (40, 40, 55), (map_w, 0, METRIC_PANEL_W, map_h))
        ui_panel.draw(screen, map_w, map_h, tick, sim_speed, paused)

        # Test-specific overlay: top-left instructions
        if overlay_font:
            lines = [
                "4-BOT JUNCTION TEST",
                f"Junction: {JUNCTION_NODE}  |  Tick: {tick}",
                f"Confirmed Collisions: {metrics.confirmed_collisions}  (should stay 0!)",
                f"Prevented Collisions: {metrics.prevented_collisions}",
                "",
                "R = Re-dispatch bots  |  SPACE = Pause  |  ESC = Quit",
            ]
            for li, line in enumerate(lines):
                color = (255, 80, 80) if "Collision" in line and metrics.confirmed_collisions > 0 else \
                        (80, 255, 80) if "Collision" in line else \
                        (255, 200, 50) if li == 0 else (200, 200, 200)
                surf = overlay_font.render(line, True, color)
                screen.blit(surf, (10, 10 + li * 18))

        # FPS
        fps_val = clock.get_fps()
        try:
            fps_font = pygame.font.SysFont("Arial", 10)
            screen.blit(fps_font.render(f"FPS: {fps_val:.0f}", True, (80, 80, 80)), (4, 130))
        except Exception:
            pass

        pygame.display.flip()

    pygame.quit()
    print(f"\n[test] Finished at tick {tick}")
    print(f"       Confirmed collisions: {metrics.confirmed_collisions}  (expected: 0)")
    print(f"       Prevented collisions: {metrics.prevented_collisions}")


if __name__ == "__main__":
    main()
