import pygame
import random
import math
import json

pygame.init()

# =====================================================
# WINDOW
# =====================================================

WINDOW_W = 1680
WINDOW_H = 982

screen = pygame.display.set_mode((WINDOW_W, WINDOW_H), pygame.RESIZABLE)
pygame.display.set_caption("Autonomous Vehicle Scheduler - Final")
clock = pygame.time.Clock()
fullscreen = False

# =====================================================
# CONFIG
# =====================================================

METRIC_PANEL = 350
BORDER = 50
LANE_WIDTH = 12
LANE_GAP = 4
STATION_SIZE = 20
VEHICLE_COUNT = 10
VEHICLE_SPEED = 2.0
BUFFER_RADIUS = 35
GATE_LENGTH = 16          # how far the gate extends from the parking block

# =====================================================
# COLORS
# =====================================================

BG = (28, 28, 28)
BLACK = (0, 0, 0)
LANE_COLOR = (120, 120, 120)
MEDIAN_COLOR = (60, 60, 60)
INTERSECTION = (255, 220, 0)
PICKUP = (0, 200, 0)
DROP = (0, 120, 255)
PANEL = (18, 18, 18)
BOT = (255, 255, 255)
ARROW_COLOR = (200, 200, 200)
BUFFER_COLOR = (100, 150, 200, 80)   # semi‑transparent
ENTRY_COLOR = (0, 255, 0)            # green
EXIT_COLOR = (255, 0, 0)             # red

# =====================================================
# FONT
# =====================================================

pygame.font.init()
font = pygame.font.SysFont("Arial", 22)
big_font = pygame.font.SysFont("Arial", 28, bold=True)

# =====================================================
# MAP VARIABLES
# =====================================================

MAP_W = 0
MAP_H = 0
VERTICAL_X = []
HORIZONTAL_Y = []
INTERSECTIONS = []
PICKUPS = []
DROPS = []
PARKING_ZONES = []          # list of pygame.Rect
PARKING_GATES = []          # list of (rect, type)

# =====================================================
# JSON EXPORT FUNCTION
# =====================================================

def export_map_json():
    cell_w = VERTICAL_X[1] - VERTICAL_X[0] if len(VERTICAL_X) > 1 else 0
    cell_h = HORIZONTAL_Y[1] - HORIZONTAL_Y[0] if len(HORIZONTAL_Y) > 1 else 0

    intersections_data = []
    for col, x in enumerate(VERTICAL_X):
        for row, y in enumerate(HORIZONTAL_Y):
            intersections_data.append({
                "col": col,
                "row": row,
                "x_px": x,
                "y_px": y
            })

    def station_grid_index(px, py):
        best_col = best_row = -1
        best_dist = float('inf')
        for col, x in enumerate(VERTICAL_X):
            for row, y in enumerate(HORIZONTAL_Y):
                d = abs(px - x) + abs(py - y)
                if d < best_dist:
                    best_dist = d
                    best_col, best_row = col, row
        return best_col, best_row

    pickups_data = []
    for sx, sy in PICKUPS:
        col, row = station_grid_index(sx, sy)
        pickups_data.append({
            "type": "pickup",
            "x_px": sx,
            "y_px": sy,
            "grid_col": col,
            "grid_row": row,
            "buffer_radius_px": BUFFER_RADIUS
        })

    drops_data = []
    for sx, sy in DROPS:
        col, row = station_grid_index(sx, sy)
        drops_data.append({
            "type": "drop",
            "x_px": sx,
            "y_px": sy,
            "grid_col": col,
            "grid_row": row,
            "buffer_radius_px": BUFFER_RADIUS
        })

    parking_data = []
    for rect in PARKING_ZONES:
        parking_data.append({
            "x_px": rect.x,
            "y_px": rect.y,
            "width_px": rect.width,
            "height_px": rect.height,
            "type": "rectangle"
        })

    gates_data = []
    for gate_rect, gtype in PARKING_GATES:
        gates_data.append({
            "x_px": gate_rect.x,
            "y_px": gate_rect.y,
            "width_px": gate_rect.width,
            "height_px": gate_rect.height,
            "type": gtype
        })

    map_config = {
        "version": "1.0",
        "description": "Complete map configuration with separated entry/exit gates",
        "screen": {
            "width_px": pygame.display.get_surface().get_width(),
            "height_px": pygame.display.get_surface().get_height(),
            "metric_panel_width_px": METRIC_PANEL,
            "border_px": BORDER
        },
        "map_area": {
            "width_px": MAP_W,
            "height_px": MAP_H,
            "grid_columns": len(VERTICAL_X) - 1,
            "grid_rows": len(HORIZONTAL_Y) - 1,
            "cell_width_px": cell_w,
            "cell_height_px": cell_h
        },
        "roads": {
            "lane_width_px": LANE_WIDTH,
            "lane_gap_px": LANE_GAP,
            "total_road_width_px": 2 * LANE_WIDTH + LANE_GAP,
            "vertical_roads_px": VERTICAL_X,
            "horizontal_roads_px": HORIZONTAL_Y
        },
        "intersections": intersections_data,
        "stations": {
            "size_px": STATION_SIZE,
            "default_buffer_radius_px": BUFFER_RADIUS,
            "pickups": pickups_data,
            "drops": drops_data
        },
        "parking_zones": parking_data,
        "parking_gates": gates_data
    }

    with open("map_config.json", "w") as f:
        json.dump(map_config, f, indent=2)
    print("Map configuration saved to map_config.json")

# =====================================================
# HELPER: NEAREST INTERSECTION
# =====================================================

def nearest_intersection(px, py):
    best = None
    best_dist = float('inf')
    for ix, iy in INTERSECTIONS:
        d = abs(px - ix) + abs(py - iy)
        if d < best_dist:
            best_dist = d
            best = (ix, iy)
    return best

# =====================================================
# BUILD MAP (integer cell sizes, border, centered)
# =====================================================

def rebuild_map():
    global MAP_W, MAP_H, VERTICAL_X, HORIZONTAL_Y, INTERSECTIONS, PICKUPS, DROPS, PARKING_ZONES, PARKING_GATES

    sw, sh = screen.get_size()
    MAP_W = sw - METRIC_PANEL
    MAP_H = sh

    available_w = MAP_W - 2 * BORDER
    available_h = MAP_H - 2 * BORDER

    cell_w = available_w // 7
    cell_h = available_h // 6
    cell_w = max(1, cell_w)
    cell_h = max(1, cell_h)

    grid_w = cell_w * 7
    grid_h = cell_h * 6

    left_border = BORDER + (available_w - grid_w) // 2
    top_border = BORDER + (available_h - grid_h) // 2

    VERTICAL_X = [left_border + i * cell_w for i in range(8)]
    HORIZONTAL_Y = [top_border + j * cell_h for j in range(7)]

    INTERSECTIONS = [(x, y) for x in VERTICAL_X for y in HORIZONTAL_Y]

    # Stations (exact indices as originally required)
    PICKUPS = [
        (VERTICAL_X[1], HORIZONTAL_Y[0]),
        (VERTICAL_X[5], HORIZONTAL_Y[0]),
        (VERTICAL_X[2], HORIZONTAL_Y[2]),
        (VERTICAL_X[6], HORIZONTAL_Y[3]),
        (VERTICAL_X[1], HORIZONTAL_Y[5]),
        (VERTICAL_X[4], HORIZONTAL_Y[6]),
        (VERTICAL_X[0], HORIZONTAL_Y[3]),
        (VERTICAL_X[7], HORIZONTAL_Y[2]),
    ]

    DROPS = [
        (VERTICAL_X[3], HORIZONTAL_Y[1]),
        (VERTICAL_X[6], HORIZONTAL_Y[1]),
        (VERTICAL_X[4], HORIZONTAL_Y[3]),
        (VERTICAL_X[2], HORIZONTAL_Y[4]),
        (VERTICAL_X[5], HORIZONTAL_Y[5]),
        (VERTICAL_X[1], HORIZONTAL_Y[6]),
        (VERTICAL_X[0], HORIZONTAL_Y[1]),
        (VERTICAL_X[7], HORIZONTAL_Y[5]),
    ]

    # Parking zones (two central cells)
    margin_park = 10
    road_total_width = 2 * LANE_WIDTH + LANE_GAP

    def get_cell_rect(row, col):
        cell_left = VERTICAL_X[col] + road_total_width // 2
        cell_right = VERTICAL_X[col+1] - road_total_width // 2
        cell_top = HORIZONTAL_Y[row] + road_total_width // 2
        cell_bottom = HORIZONTAL_Y[row+1] - road_total_width // 2
        rect = pygame.Rect(
            cell_left + margin_park,
            cell_top + margin_park,
            (cell_right - cell_left) - 2 * margin_park,
            (cell_bottom - cell_top) - 2 * margin_park
        )
        return rect

    zone1 = get_cell_rect(2, 2)   # row=2, col=2
    zone2 = get_cell_rect(3, 4)   # row=3, col=4
    PARKING_ZONES = [zone1, zone2]

    # =====================================================
    # CREATE ENTRY/EXIT GATES WITH GOOD SEPARATION
    # =====================================================
    PARKING_GATES = []

    def add_gates_for_zone(zone_rect):
        h = zone_rect.height
        w = zone_rect.width

        # West side (left edge) – entry near top third, exit near bottom third
        west_entry_y = zone_rect.top + h // 3
        west_exit_y = zone_rect.top + 2 * h // 3
        west_entry = pygame.Rect(
            zone_rect.left - GATE_LENGTH,
            west_entry_y - LANE_WIDTH//2,
            GATE_LENGTH, LANE_WIDTH
        )
        west_exit = pygame.Rect(
            zone_rect.left - GATE_LENGTH,
            west_exit_y - LANE_WIDTH//2,
            GATE_LENGTH, LANE_WIDTH
        )
        PARKING_GATES.append((west_entry, "entry"))
        PARKING_GATES.append((west_exit, "exit"))

        # East side (right edge)
        east_entry_y = zone_rect.top + h // 3
        east_exit_y = zone_rect.top + 2 * h // 3
        east_entry = pygame.Rect(
            zone_rect.right,
            east_entry_y - LANE_WIDTH//2,
            GATE_LENGTH, LANE_WIDTH
        )
        east_exit = pygame.Rect(
            zone_rect.right,
            east_exit_y - LANE_WIDTH//2,
            GATE_LENGTH, LANE_WIDTH
        )
        PARKING_GATES.append((east_entry, "entry"))
        PARKING_GATES.append((east_exit, "exit"))

        # North side (top edge) – entry near left third, exit near right third
        north_entry_x = zone_rect.left + w // 3
        north_exit_x = zone_rect.left + 2 * w // 3
        north_entry = pygame.Rect(
            north_entry_x - LANE_WIDTH//2,
            zone_rect.top - GATE_LENGTH,
            LANE_WIDTH, GATE_LENGTH
        )
        north_exit = pygame.Rect(
            north_exit_x - LANE_WIDTH//2,
            zone_rect.top - GATE_LENGTH,
            LANE_WIDTH, GATE_LENGTH
        )
        PARKING_GATES.append((north_entry, "entry"))
        PARKING_GATES.append((north_exit, "exit"))

        # South side (bottom edge)
        south_entry_x = zone_rect.left + w // 3
        south_exit_x = zone_rect.left + 2 * w // 3
        south_entry = pygame.Rect(
            south_entry_x - LANE_WIDTH//2,
            zone_rect.bottom,
            LANE_WIDTH, GATE_LENGTH
        )
        south_exit = pygame.Rect(
            south_exit_x - LANE_WIDTH//2,
            zone_rect.bottom,
            LANE_WIDTH, GATE_LENGTH
        )
        PARKING_GATES.append((south_entry, "entry"))
        PARKING_GATES.append((south_exit, "exit"))

    add_gates_for_zone(PARKING_ZONES[0])
    add_gates_for_zone(PARKING_ZONES[1])

    export_map_json()

# =====================================================
# LANE POSITION HELPERS
# =====================================================

def get_vertical_lanes(center_x):
    left_lane = center_x - LANE_GAP/2 - LANE_WIDTH/2
    right_lane = center_x + LANE_GAP/2 + LANE_WIDTH/2
    return left_lane, right_lane

def get_horizontal_lanes(center_y):
    top_lane = center_y - LANE_GAP/2 - LANE_WIDTH/2
    bottom_lane = center_y + LANE_GAP/2 + LANE_WIDTH/2
    return top_lane, bottom_lane

# =====================================================
# DRAW FUNCTIONS
# =====================================================

def draw_dual_roads():
    for cx in VERTICAL_X:
        left_lane, right_lane = get_vertical_lanes(cx)
        pygame.draw.rect(screen, LANE_COLOR,
                         (left_lane - LANE_WIDTH/2, 0, LANE_WIDTH, MAP_H))
        pygame.draw.rect(screen, LANE_COLOR,
                         (right_lane - LANE_WIDTH/2, 0, LANE_WIDTH, MAP_H))
        pygame.draw.rect(screen, MEDIAN_COLOR,
                         (left_lane + LANE_WIDTH/2, 0, LANE_GAP, MAP_H))

        for y in range(50, MAP_H, 100):
            # Northbound arrow (left lane)
            pygame.draw.polygon(screen, ARROW_COLOR, [
                (left_lane, y + 10), (left_lane - 6, y + 2), (left_lane - 3, y + 2),
                (left_lane - 3, y - 6), (left_lane + 3, y - 6), (left_lane + 3, y + 2),
                (left_lane + 6, y + 2)
            ])
            # Southbound arrow (right lane)
            pygame.draw.polygon(screen, ARROW_COLOR, [
                (right_lane, y - 10), (right_lane - 6, y - 2), (right_lane - 3, y - 2),
                (right_lane - 3, y + 6), (right_lane + 3, y + 6), (right_lane + 3, y - 2),
                (right_lane + 6, y - 2)
            ])

    for cy in HORIZONTAL_Y:
        top_lane, bottom_lane = get_horizontal_lanes(cy)
        pygame.draw.rect(screen, LANE_COLOR,
                         (0, top_lane - LANE_WIDTH/2, MAP_W, LANE_WIDTH))
        pygame.draw.rect(screen, LANE_COLOR,
                         (0, bottom_lane - LANE_WIDTH/2, MAP_W, LANE_WIDTH))
        pygame.draw.rect(screen, MEDIAN_COLOR,
                         (0, top_lane + LANE_WIDTH/2, MAP_W, LANE_GAP))

        for x in range(50, MAP_W, 100):
            # Eastbound arrow (top lane)
            pygame.draw.polygon(screen, ARROW_COLOR, [
                (x - 10, top_lane), (x - 2, top_lane - 6), (x - 2, top_lane - 3),
                (x + 6, top_lane - 3), (x + 6, top_lane + 3), (x - 2, top_lane + 3),
                (x - 2, top_lane + 6)
            ])
            # Westbound arrow (bottom lane)
            pygame.draw.polygon(screen, ARROW_COLOR, [
                (x + 10, bottom_lane), (x + 2, bottom_lane - 6), (x + 2, bottom_lane - 3),
                (x - 6, bottom_lane - 3), (x - 6, bottom_lane + 3), (x + 2, bottom_lane + 3),
                (x + 2, bottom_lane + 6)
            ])

def draw_intersections():
    for cx, cy in INTERSECTIONS:
        pygame.draw.circle(screen, INTERSECTION, (int(cx), int(cy)), 8)

def draw_station_buffers():
    buffer_surf = pygame.Surface((MAP_W, MAP_H), pygame.SRCALPHA)
    for sx, sy in PICKUPS + DROPS:
        pygame.draw.circle(buffer_surf, BUFFER_COLOR, (int(sx), int(sy)), BUFFER_RADIUS)
    screen.blit(buffer_surf, (0, 0))

def draw_stations():
    for x, y in PICKUPS:
        pygame.draw.rect(screen, PICKUP,
                         (x - STATION_SIZE//2, y - STATION_SIZE//2, STATION_SIZE, STATION_SIZE))
    for x, y in DROPS:
        pygame.draw.rect(screen, DROP,
                         (x - STATION_SIZE//2, y - STATION_SIZE//2, STATION_SIZE, STATION_SIZE))

def draw_parking_zones():
    for zone in PARKING_ZONES:
        pygame.draw.rect(screen, BLACK, zone, border_radius=4)

def draw_parking_gates():
    for gate_rect, gtype in PARKING_GATES:
        color = ENTRY_COLOR if gtype == "entry" else EXIT_COLOR
        pygame.draw.rect(screen, color, gate_rect)

def draw_metrics_panel(tick, vehicle_count):
    pygame.draw.rect(screen, PANEL, (MAP_W, 0, METRIC_PANEL, MAP_H))
    title = big_font.render("Fleet Metrics", True, (255, 255, 255))
    screen.blit(title, (MAP_W + 20, 20))

    metrics = [
        f"Tick : {tick}", "", f"Vehicles : {vehicle_count}",
        "Completed : 0", "Pending : 25", "Failures : 0",
        "Reroutes : 0", "Collisions : 0", "", "Central Brain",
        "Status : ACTIVE", "", "Model 1", "Fastest Route",
        "", "Model 2", "Congestion Prediction", "",
        "F11 : Fullscreen", "ESC : Exit", "",
        f"Cell size: {VERTICAL_X[1]-VERTICAL_X[0]} x {HORIZONTAL_Y[1]-HORIZONTAL_Y[0]} px",
        "Parking zones: 2", f"Buffer radius: {BUFFER_RADIUS} px",
        f"Gates: {len(PARKING_GATES)} (entry/exit) - separated"
    ]
    y = 80
    for item in metrics:
        txt = font.render(item, True, (255, 255, 255))
        screen.blit(txt, (MAP_W + 20, y))
        y += 34

# =====================================================
# VEHICLE CLASS (constant speed, no overtaking)
# =====================================================

class Vehicle:
    def __init__(self):
        self.path = self.create_route()
        self.segment = 0
        self.x = self.path[0][0]
        self.y = self.path[0][1]
        self.speed = VEHICLE_SPEED

    def create_route(self):
        start = random.choice(PICKUPS + DROPS)
        end = random.choice(PICKUPS + DROPS)
        while end == start:
            end = random.choice(PICKUPS + DROPS)

        start_int = nearest_intersection(start[0], start[1])
        end_int = nearest_intersection(end[0], end[1])
        inter1 = random.choice(INTERSECTIONS)
        inter2 = random.choice(INTERSECTIONS)

        path = [start, start_int, inter1, inter2, end_int, end]
        cleaned = []
        for p in path:
            if not cleaned or p != cleaned[-1]:
                cleaned.append(p)
        return cleaned

    def update(self):
        if self.segment >= len(self.path) - 1:
            self.path = self.create_route()
            self.segment = 0
            self.x = self.path[0][0]
            self.y = self.path[0][1]

        tx, ty = self.path[self.segment + 1]
        dx = tx - self.x
        dy = ty - self.y
        dist = math.hypot(dx, dy)

        if dist < self.speed:
            self.x = tx
            self.y = ty
            self.segment += 1
        else:
            self.x += self.speed * dx / dist
            self.y += self.speed * dy / dist

    def draw(self):
        pygame.draw.circle(screen, BOT, (int(self.x), int(self.y)), 7)

# =====================================================
# INIT
# =====================================================

rebuild_map()
vehicles = [Vehicle() for _ in range(VEHICLE_COUNT)]

# =====================================================
# MAIN LOOP
# =====================================================

tick = 0
running = True

while running:
    clock.tick(60)
    tick += 1

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            elif event.key == pygame.K_F11:
                fullscreen = not fullscreen
                if fullscreen:
                    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
                else:
                    screen = pygame.display.set_mode((WINDOW_W, WINDOW_H), pygame.RESIZABLE)
                rebuild_map()
        elif event.type == pygame.VIDEORESIZE:
            if not fullscreen:
                screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)
                rebuild_map()

    for v in vehicles:
        v.update()

    screen.fill(BG)
    draw_dual_roads()
    draw_intersections()
    draw_station_buffers()
    draw_stations()
    draw_parking_zones()
    draw_parking_gates()
    for v in vehicles:
        v.draw()
    draw_metrics_panel(tick, len(vehicles))

    pygame.display.flip()

pygame.quit()