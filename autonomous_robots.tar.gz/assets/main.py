"""
main.py — Simulation Entry Point (Desktop + Web/Pygbag Compatible)

Desktop: python3 main.py
Web:     python3 -m pygbag --width 1330 --height 982 main.py
         → open http://localhost:8000

Pygbag requires:
  - async def main()
  - await asyncio.sleep(0) at end of each frame
  - asyncio.run(main()) at module level
"""

import asyncio
import json
import os
import sys
import random
import math
import pygame

# ── Platform detection ───────────────────────────────────
_IS_WEB = sys.platform in ("emscripten", "wasi")

# ── Disable XGBoost in web (not available in WASM) ───────
if _IS_WEB:
    os.environ["AUTONOMOUS_ROBOTS_NO_XGBOOST"] = "1"
    os.environ["PYGBAG"] = "1"

# ─────────────────────────────────────────────────────────
# IMPORT ALL MODULES (order matters — dependencies first)
# ─────────────────────────────────────────────────────────

import config
from config import (
    WINDOW_W, WINDOW_H, METRIC_PANEL_W, FPS,
    VEHICLE_COUNT, VEHICLE_MAX,
    KEY_QUIT, KEY_HEATMAP,
    KEY_FAIL_VEHICLE, KEY_SPEED_UP, KEY_SPEED_DOWN, KEY_PAUSE, KEY_ADD_BOT,
    COLLISION_RADIUS,
)

from core.models import VehicleRecord, VehicleState, ParkingSlot
from core.event_bus import bus

from brain.road_graph import graph
from brain.speed_coordinator import speed_coordinator
from brain.task_generator import task_gen
from brain.parking_manager import parking_mgr
from brain.metrics_tracker import metrics
from brain.central_brain import brain
from brain.failure_manager import failure_mgr

from vehicle.vehicle_registry import registry
from vehicle.vehicle import Vehicle

from visualization.renderer import renderer
from visualization.ui_panels import ui_panel
from visualization.button_bar import (
    button_bar,
    ACT_PAUSE, ACT_SPEED_UP, ACT_SPEED_DOWN,
    ACT_ADD_BOT, ACT_FORCE_TASK, ACT_HEATMAP,
    ACT_FAIL_BOT, ACT_FULLSCREEN,
    ACT_TEST_1, ACT_TEST_2, ACT_TEST_3,
)

# ─────────────────────────────────────────────────────────
# MAP LOADING
# ─────────────────────────────────────────────────────────

def load_map_data() -> dict:
    """Load map_config.json — works on desktop and in pygbag WASM."""
    candidates = [
        "map_config.json",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "map_config.json"),
    ]
    for path in candidates:
        try:
            with open(path, "r") as f:
                return json.load(f)
        except Exception:
            pass
    raise FileNotFoundError("map_config.json not found")


def toggle_fullscreen(screen: pygame.Surface, fullscreen: bool) -> tuple:
    """
    Toggle fullscreen mode.
    Desktop: uses pygame FULLSCREEN flag.
    Web/WASM: calls browser fullscreen API via JavaScript.
    Returns (new_screen, new_fullscreen_state).
    """
    if _IS_WEB:
        # Use browser fullscreen API
        try:
            import platform
            if not fullscreen:
                platform.window.eval("document.documentElement.requestFullscreen().catch(()=>{})")
            else:
                platform.window.eval("document.exitFullscreen().catch(()=>{})")
        except Exception:
            pass
        return screen, not fullscreen   # state toggled, screen surface unchanged
    else:
        fullscreen = not fullscreen
        if fullscreen:
            new_screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        else:
            new_screen = pygame.display.set_mode((WINDOW_W, WINDOW_H), pygame.RESIZABLE)
        return new_screen, fullscreen


def build_geometry(map_data: dict) -> dict:
    roads = map_data["roads"]
    vertical_x   = roads["vertical_roads_px"]
    horizontal_y = roads["horizontal_roads_px"]
    intersections = [(i["x_px"], i["y_px"]) for i in map_data["intersections"]]
    pickups  = [(s["x_px"], s["y_px"], f"{s['grid_col']}_{s['grid_row']}") for s in map_data["stations"]["pickups"]]
    drops    = [(s["x_px"], s["y_px"], f"{s['grid_col']}_{s['grid_row']}") for s in map_data["stations"]["drops"]]
    parking_zones = [pygame.Rect(z["x_px"], z["y_px"], z["width_px"], z["height_px"]) for z in map_data["parking_zones"]]
    parking_gates = [(pygame.Rect(g["x_px"], g["y_px"], g["width_px"], g["height_px"]), g["type"]) for g in map_data["parking_gates"]]
    map_w = map_data["screen"]["width_px"] - map_data["screen"]["metric_panel_width_px"]
    map_h = map_data["screen"]["height_px"]
    return dict(vertical_x=vertical_x, horizontal_y=horizontal_y,
                intersections=intersections, pickups=pickups, drops=drops,
                parking_zones=parking_zones, parking_gates=parking_gates,
                map_w=map_w, map_h=map_h)


def make_parking_slots(map_data: dict) -> list:
    node_map = {f"{i['col']}_{i['row']}": (i["x_px"], i["y_px"]) for i in map_data["intersections"]}
    slots = []
    for nid in ["2_2", "2_3", "3_2", "3_3", "4_3", "4_4", "5_3", "5_4"]:
        if nid in node_map:
            slots.append(ParkingSlot(node_id=nid, zone_id=0, center_px=node_map[nid], occupied_by=None))
    return slots


def spawn_vehicles(map_data: dict, count: int) -> list:
    intersections = map_data["intersections"]
    vehicles = []
    for i in range(count):
        vid   = f"V{i}"
        node  = random.choice(intersections)
        nid   = f"{node['col']}_{node['row']}"
        x     = node["x_px"] + random.uniform(-3, 3)
        y     = node["y_px"] + random.uniform(-3, 3)
        registry.register(VehicleRecord(vehicle_id=vid, state=VehicleState.IDLE,
                                        x_px=x, y_px=y, node_id=nid))
        vehicles.append(Vehicle(vid))
    return vehicles


def spawn_one_vehicle(map_data: dict, vehicles: list) -> str:
    if len(vehicles) >= VEHICLE_MAX:
        return ""
    intersections = map_data["intersections"]
    occupied = {r.node_id for r in registry.snapshot()}
    free = [n for n in intersections if f"{n['col']}_{n['row']}" not in occupied]
    node = random.choice(free if free else intersections)
    ids  = []
    for r in registry.snapshot():
        try: ids.append(int(r.vehicle_id[1:]))
        except ValueError: pass
    vid = f"V{max(ids, default=-1) + 1}"
    nid = f"{node['col']}_{node['row']}"
    x = node["x_px"] + random.uniform(-3, 3)
    y = node["y_px"] + random.uniform(-3, 3)
    registry.register(VehicleRecord(vehicle_id=vid, state=VehicleState.IDLE,
                                    x_px=x, y_px=y, node_id=nid))
    vehicles.append(Vehicle(vid))
    print(f"[main] Bot {vid} spawned at {nid} (fleet size: {len(vehicles)}/{VEHICLE_MAX})")
    return vid


def check_physical_collisions() -> None:
    active_states = {VehicleState.MOVING_TO_PICKUP, VehicleState.MOVING_TO_DEST, VehicleState.MOVING_TO_PARKING}
    active = [r for r in registry.snapshot() if r.state in active_states]
    for i in range(len(active)):
        for j in range(i + 1, len(active)):
            a, b = active[i], active[j]
            if math.hypot(a.x_px - b.x_px, a.y_px - b.y_px) < COLLISION_RADIUS:
                metrics.confirmed_collisions += 1


# ─────────────────────────────────────────────────────────
# ASYNC MAIN — works on desktop (asyncio.run) and in browser
# ─────────────────────────────────────────────────────────

async def main():
    """Main simulation loop — async for pygbag/web compatibility."""

    # ── 1. Pygame init ────────────────────────────────────
    pygame.init()
    pygame.font.init()
    if _IS_WEB:
        screen = pygame.display.set_mode((WINDOW_W, WINDOW_H))
    else:
        screen = pygame.display.set_mode((WINDOW_W, WINDOW_H), pygame.RESIZABLE)
    pygame.display.set_caption("Autonomous Robot Space-Time Scheduler")
    clock = pygame.time.Clock()

    # ── 2. Load map ───────────────────────────────────────
    map_data = load_map_data()
    geo      = build_geometry(map_data)
    print(f"[main] Map loaded")

    # ── 3. Build road graph ───────────────────────────────
    graph.build(map_data["intersections"])
    print(f"[main] Graph built: {graph.node_count()} nodes")

    # ── 4. Station positions ──────────────────────────────
    all_station_px = ([(s["x_px"], s["y_px"]) for s in map_data["stations"]["pickups"]] +
                      [(s["x_px"], s["y_px"]) for s in map_data["stations"]["drops"]])
    speed_coordinator.set_stations(all_station_px)

    pickup_data = [{"node_id": f"{s['grid_col']}_{s['grid_row']}", "x_px": s["x_px"], "y_px": s["y_px"]}
                   for s in map_data["stations"]["pickups"]]
    drop_data   = [{"node_id": f"{s['grid_col']}_{s['grid_row']}", "x_px": s["x_px"], "y_px": s["y_px"]}
                   for s in map_data["stations"]["drops"]]
    task_gen.set_stations(pickup_data, drop_data)

    # ── 5. Parking ────────────────────────────────────────
    parking_slots = make_parking_slots(map_data)
    parking_mgr.set_slots(parking_slots)
    print(f"[main] {len(parking_slots)} parking slots configured")

    # ── 6. Renderer ───────────────────────────────────────
    renderer.setup(
        vertical_x    = geo["vertical_x"],
        horizontal_y  = geo["horizontal_y"],
        intersections = geo["intersections"],
        pickups       = geo["pickups"],
        drops         = geo["drops"],
        parking_zones = geo["parking_zones"],
        parking_gates = geo["parking_gates"],
        map_w         = geo["map_w"],
        map_h         = geo["map_h"],
    )

    # ── Simulation state ──────────────────────────────────
    vehicles:  list  = []
    tick:      int   = 0
    paused:    bool  = True
    sim_speed: float = 1.0
    speed_acc: float = 0.0
    running:   bool  = True
    map_w = geo["map_w"]
    map_h = geo["map_h"]
    fullscreen = False

    current_mode     = "FREE_ROAM"
    dispatched       = False
    transitioning    = False
    transition_timer = 0
    node_map = {f"{i['col']}_{i['row']}": (i["x_px"], i["y_px"]) for i in map_data["intersections"]}

    print("[main] Simulation ready. Click START to begin, or select a Test.")

    # ── Main Loop ─────────────────────────────────────────
    while running:
        clock.tick(FPS)

        # ── Events ────────────────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == KEY_QUIT:
                    running = False
                elif event.key == KEY_HEATMAP:
                    renderer.show_heatmap = not renderer.show_heatmap
                elif event.key == pygame.K_r:
                    renderer.show_routes = not renderer.show_routes
                elif event.key == KEY_PAUSE:
                    paused = not paused
                elif event.key == KEY_FAIL_VEHICLE:
                    failure_mgr.trigger_random(tick)
                elif event.key == KEY_ADD_BOT:
                    spawn_one_vehicle(map_data, vehicles)
                elif event.key in (KEY_SPEED_UP, pygame.K_EQUALS):
                    sim_speed = min(8.0, sim_speed + 0.5)
                    print(f"[main] Speed: {sim_speed}x")
                elif event.key == KEY_SPEED_DOWN:
                    sim_speed = max(0.25, sim_speed - 0.25)
                    print(f"[main] Speed: {sim_speed}x")
                elif event.key == pygame.K_t:
                    task_gen.force_generate(tick)
                elif not _IS_WEB and event.key == pygame.K_F11:
                    screen, fullscreen = toggle_fullscreen(screen, fullscreen)

            elif not _IS_WEB and event.type == pygame.VIDEORESIZE:
                screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)
                map_w = event.w - METRIC_PANEL_W
                map_h = event.h
                renderer._map_w = map_w
                renderer._map_h = map_h
                renderer._buffer_surf = None

            # ── Button bar ────────────────────────────────
            btn_actions = button_bar.handle_event(event, map_w, map_h)
            for act in btn_actions:
                if act == ACT_PAUSE:
                    if current_mode != "FREE_ROAM" or tick == 0:
                        from test_runner import reset_simulation_state
                        reset_simulation_state()
                        vehicles = []
                        current_mode = "FREE_ROAM"
                        paused = True
                        transitioning = True
                        transition_timer = pygame.time.get_ticks() + 2000
                        dispatched = False
                        print("[main] Starting in 2 seconds...")
                    else:
                        paused = not paused
                        print(f"[main] {'Paused' if paused else 'Resumed'}")

                elif act == ACT_SPEED_UP:
                    sim_speed = min(8.0, sim_speed + 0.5)
                elif act == ACT_SPEED_DOWN:
                    sim_speed = max(0.25, sim_speed - 0.25)
                elif act == ACT_ADD_BOT:
                    spawn_one_vehicle(map_data, vehicles)
                elif act == ACT_FORCE_TASK:
                    task_gen.force_generate(tick)
                elif act == ACT_HEATMAP:
                    renderer.show_heatmap = not renderer.show_heatmap
                elif act == ACT_FAIL_BOT:
                    failure_mgr.trigger_random(tick)
                elif act == ACT_FULLSCREEN:
                    screen, fullscreen = toggle_fullscreen(screen, fullscreen)
                    # Update button label to reflect state
                    for btn in button_bar._buttons:
                        if btn.action == ACT_FULLSCREEN:
                            btn.label = "✕ EXIT" if fullscreen else "⛶ FULL"
                            break
                elif act in [ACT_TEST_1, ACT_TEST_2, ACT_TEST_3]:
                    from test_runner import reset_simulation_state
                    test_num = 1 if act == ACT_TEST_1 else (2 if act == ACT_TEST_2 else 3)
                    reset_simulation_state()
                    vehicles = []
                    current_mode = f"TEST_{test_num}"
                    paused = True
                    transitioning = True
                    transition_timer = pygame.time.get_ticks() + 2000
                    dispatched = False
                    print(f"[main] Starting Test {test_num} in 2 seconds...")

        # ── State transitions ─────────────────────────────
        if transitioning and pygame.time.get_ticks() >= transition_timer:
            transitioning = False
            tick = 0
            paused = False
            if current_mode == "FREE_ROAM":
                vehicles = spawn_vehicles(map_data, VEHICLE_COUNT)
                print("[main] Main simulation started!")
            else:
                from test_runner import spawn_bots, TESTS
                test_num = int(current_mode.split('_')[1])
                name, desc, bot_cfgs = TESTS[test_num]
                vehicles = spawn_bots(bot_cfgs, node_map)
                print(f"[main] Test {test_num} started!")

        # ── Simulation ticks ──────────────────────────────
        if not paused and not transitioning:
            speed_acc += sim_speed
            steps = int(speed_acc)
            speed_acc -= steps
            for _ in range(steps):
                tick += 1
                if current_mode == "FREE_ROAM":
                    brain.tick(tick)
                else:
                    from test_runner import dispatch_bots, TESTS
                    if tick == 30 and not dispatched:
                        dispatched = True
                        test_num = int(current_mode.split('_')[1])
                        _, _, bot_cfgs = TESTS[test_num]
                        dispatch_bots(bot_cfgs, tick)
                    parking_mgr.update(tick)
                    from brain.reservation_manager import reservations
                    if tick % 60 == 0:
                        reservations.gc(tick)
                for v in vehicles:
                    v.tick(tick)
                check_physical_collisions()

        # ── Render ────────────────────────────────────────
        screen.fill((20, 20, 20))
        renderer.draw(screen, tick)
        pygame.draw.rect(screen, (40, 40, 55), (map_w, 0, METRIC_PANEL_W, map_h))
        ui_panel.draw(screen, map_w, map_h, tick, sim_speed, paused)

        # FPS counter (desktop only — fonts expensive in WASM)
        if not _IS_WEB:
            try:
                fps_val  = clock.get_fps()
                fps_font = pygame.font.SysFont("Arial", 10)
                fps_surf = fps_font.render(f"FPS: {fps_val:.0f}", True, (80, 80, 80))
                screen.blit(fps_surf, (4, 4))
            except Exception:
                pass

        # Button bar label
        if current_mode != "FREE_ROAM" or tick == 0:
            button_bar._buttons[0].label = "▶ START"
        else:
            button_bar._buttons[0].label = "▶ RESUME" if paused else "⏸ PAUSE"

        button_bar.draw(screen, map_w, map_h, paused, sim_speed, tick)
        pygame.display.flip()

        # ← REQUIRED by pygbag: yield to browser each frame
        await asyncio.sleep(0)

    pygame.quit()
    print(f"[main] Simulation ended at tick {tick}")


# ─────────────────────────────────────────────────────────
# ENTRY POINT — works on desktop AND in pygbag/browser
# ─────────────────────────────────────────────────────────
asyncio.run(main())
