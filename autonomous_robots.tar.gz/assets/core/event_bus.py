"""
core/event_bus.py — Publish-Subscribe Event Bus

PURPOSE:
    Decouples modules that produce events from modules that consume them.
    A module that generates tasks doesn't need to know who handles task creation.
    A module that detects failures doesn't need to import the UI directly.

HOW IT WORKS:
    Modules call bus.subscribe("EVENT_TYPE", my_callback) at startup.
    Modules call bus.emit(SystemEvent(...)) when something happens.
    The bus calls all registered callbacks for that event type.

WHY THIS MATTERS:
    Without an event bus, modules must directly import each other, creating
    tangled dependencies. With the bus, each module only knows about the bus.

DESIGN:
    Single global 'bus' instance. All modules import this one instance.
    Synchronous — callbacks are called immediately in the same tick.
    No threading needed for a single-threaded pygame simulation.
"""

from collections import defaultdict
from core.models import SystemEvent


class EventBus:
    """
    A simple synchronous publish-subscribe message bus.

    Modules register callbacks for event types they care about.
    When an event is emitted, all callbacks for that type are called.
    """

    def __init__(self):
        # Map from event_type string → list of callback functions
        self._subscribers: dict = defaultdict(list)

    def subscribe(self, event_type: str, callback) -> None:
        """
        Register a callback for a specific event type.

        Args:
            event_type: String identifier (e.g., "TASK_CREATED")
            callback:   Function accepting a SystemEvent argument
        """
        self._subscribers[event_type].append(callback)

    def unsubscribe(self, event_type: str, callback) -> None:
        """Remove a previously registered callback."""
        subs = self._subscribers.get(event_type, [])
        if callback in subs:
            subs.remove(callback)

    def emit(self, event: SystemEvent) -> None:
        """
        Publish an event to all subscribers.

        All callbacks for this event_type are called synchronously
        before this function returns. Order of callback execution
        matches registration order.

        Args:
            event: The SystemEvent to broadcast
        """
        for callback in self._subscribers.get(event.event_type, []):
            try:
                callback(event)
            except Exception as e:
                # Log but don't crash — a bad subscriber shouldn't kill the sim
                print(f"[EventBus] Error in subscriber for {event.event_type}: {e}")

    def clear(self) -> None:
        """Remove all subscriptions. Used in tests / resets."""
        self._subscribers.clear()


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# All modules import this one 'bus' instance.
# ─────────────────────────────────────────────────────────

bus = EventBus()


# ─────────────────────────────────────────────────────────
# EVENT TYPE CONSTANTS
# Using constants avoids typos in event type strings.
# ─────────────────────────────────────────────────────────

class EventType:
    """
    Canonical string constants for all event types in the system.
    Use these instead of raw strings to avoid typos.
    """
    TASK_CREATED       = "TASK_CREATED"       # new task entered PENDING state
    TASK_ASSIGNED      = "TASK_ASSIGNED"       # task assigned to a vehicle
    TASK_COMPLETED     = "TASK_COMPLETED"      # delivery successful
    TASK_FAILED        = "TASK_FAILED"         # task failed or expired
    TASK_REASSIGNED    = "TASK_REASSIGNED"     # task requeued after vehicle failure
    VEHICLE_FAILED     = "VEHICLE_FAILED"      # vehicle broke down
    VEHICLE_REPAIRED   = "VEHICLE_REPAIRED"    # vehicle back in service
    VEHICLE_PARKED     = "VEHICLE_PARKED"      # vehicle entered parking slot
    DEADLOCK_DETECTED  = "DEADLOCK_DETECTED"   # wait-for cycle found
    DEADLOCK_RESOLVED  = "DEADLOCK_RESOLVED"   # deadlock broken
    PICKUP_REACHED     = "PICKUP_REACHED"      # vehicle arrived at pickup
    DROP_REACHED       = "DROP_REACHED"        # vehicle arrived at drop
    FLEET_UNDERPROVISION = "FLEET_UNDERPROVISION"  # task queue overloaded
    FLEET_OVERPROVISION  = "FLEET_OVERPROVISION"   # fleet underutilised
