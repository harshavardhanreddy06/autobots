"""
core/models.py — All Data Structures for the Autonomous Vehicle Scheduler

PURPOSE:
    Single source of truth for every dataclass and enum in the system.
    Every other module imports its types from here.
    No logic lives here — only structure definitions.

WHY A SINGLE MODELS FILE:
    Keeps all type definitions in one place. When you need to know what
    a Task looks like, you look here. No hunting across modules.

CONTENTS:
    VehicleState  — all states a vehicle can be in
    TaskState     — all states a task moves through
    Task          — a pickup-to-drop work order
    ScheduleEntry — one segment of a vehicle's time-stamped route
    VehicleInstruction — complete instruction packet sent to a vehicle
    VehicleRecord — full live state of one vehicle (stored in registry)
    ConflictEvent — a detected scheduling conflict
    SystemEvent   — a bus message between modules
    ParkingSlot   — a parking slot with occupancy tracking
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional


# ─────────────────────────────────────────────────────────
# ENUMS
# ─────────────────────────────────────────────────────────

class VehicleState(Enum):
    """
    Every state a vehicle can occupy.
    The Central Brain reads this to determine eligibility for allocation,
    parking, deadlock detection, and failure handling.
    """
    IDLE              = auto()   # No task. Sitting at a node. Eligible for tasks.
    WAITING_FOR_START = auto()   # Has schedule but departure tick is in the future.
    MOVING_TO_PICKUP  = auto()   # En route to pickup station. Committed — not reassignable.
    MOVING_TO_DEST    = auto()   # Carrying cargo, en route to drop. Pre-assignable.
    MOVING_TO_PARKING = auto()   # Heading to parking. Interruptible by task assignment.
    PARKED            = auto()   # In parking slot. Eligible for tasks.
    FAILED            = auto()   # Broken down. No movement.
    REPAIRING         = auto()   # Repair in progress. Re-enters service after REPAIR_TICKS.


class TaskState(Enum):
    """
    Every state a task moves through from creation to completion.
    """
    PENDING               = auto()   # Created, not yet assigned to any vehicle.
    ASSIGNED              = auto()   # Vehicle selected, scheduling pipeline running.
    MOVING_TO_PICKUP      = auto()   # Vehicle en route to pickup.
    MOVING_TO_DESTINATION = auto()   # Vehicle carrying cargo to drop.
    COMPLETED             = auto()   # Successfully delivered.
    FAILED                = auto()   # Failed — vehicle breakdown with cargo, or timeout.


# ─────────────────────────────────────────────────────────
# TASK
# ─────────────────────────────────────────────────────────

@dataclass
class Task:
    """
    A work order: pick up from pickup_node, deliver to drop_node.

    Fields:
        task_id       — unique identifier (e.g., "T0", "T1")
        pickup_node   — road graph node id where item is picked up (e.g., "1_0")
        drop_node     — road graph node id where item is delivered (e.g., "3_1")
        pickup_px     — pixel position of pickup (for display and distance calc)
        drop_px       — pixel position of drop   (for display and distance calc)
        priority      — "HIGH", "NORMAL", or "LOW"
        created_tick  — tick when task was generated
        state         — current TaskState
        assigned_to   — vehicle_id if assigned, else None
        assign_tick   — tick when assignment was made
        complete_tick — tick when delivery was completed
        effective_priority — used by allocator; starts equal to PRIORITY_WEIGHT[priority]
                             and increases with age to prevent starvation
    """
    task_id:            str
    pickup_node:        str
    drop_node:          str
    pickup_px:          tuple
    drop_px:            tuple
    priority:           str
    created_tick:       int
    state:              TaskState = TaskState.PENDING
    assigned_to:        Optional[str] = None
    assign_tick:        Optional[int] = None
    complete_tick:      Optional[int] = None
    effective_priority: int = 2   # default NORMAL weight


# ─────────────────────────────────────────────────────────
# SCHEDULE ENTRY
# ─────────────────────────────────────────────────────────

@dataclass
class ScheduleEntry:
    """
    One leg of a vehicle's route — occupancy of one road segment
    during a specific time window.

    The Reservation Manager stores these as space-time ownership records.
    Collision detection uses time-range overlap:
        conflict if A.enter < B.exit AND A.exit > B.enter

    Fields:
        segment_id  — unique id for the directed road segment (e.g., "1_0__2_0")
        from_node   — node id at start of this segment
        to_node     — node id at end of this segment
        enter_tick  — tick when vehicle enters the segment
        exit_tick   — tick when vehicle clears the segment
    """
    segment_id:  str
    from_node:   str
    to_node:     str
    enter_tick:  int
    exit_tick:   int


# ─────────────────────────────────────────────────────────
# VEHICLE INSTRUCTION
# ─────────────────────────────────────────────────────────

@dataclass
class VehicleInstruction:
    """
    Complete movement packet delivered to a vehicle by the Central Brain.

    A vehicle only follows an instruction if its schedule_version
    matches the version stored in its VehicleRecord. Version mismatch
    means the instruction is stale (e.g., the vehicle was rerouted)
    and the vehicle must wait for a new one.

    Fields:
        vehicle_id       — which vehicle this is for
        schedule         — ordered list of ScheduleEntry (full route, tick-stamped)
        schedule_version — monotonically increasing per vehicle; guards against stale instructions
        task_id          — task this instruction is serving (None for parking/idle)
        destination_type — "TO_PICKUP" | "TO_DROP" | "TO_PARKING"
        start_tick       — first tick of movement (= schedule[0].enter_tick)
        end_node         — final destination node id
    """
    vehicle_id:       str
    schedule:         list          # list[ScheduleEntry]
    schedule_version: int
    task_id:          Optional[str]
    destination_type: str           # "TO_PICKUP" | "TO_DROP" | "TO_PARKING"
    start_tick:       int
    end_node:         str


# ─────────────────────────────────────────────────────────
# VEHICLE RECORD
# ─────────────────────────────────────────────────────────

@dataclass
class VehicleRecord:
    """
    Complete live state of one vehicle, stored in the Vehicle Registry.

    The Registry is the single source of truth — no other module
    stores authoritative vehicle state.

    Fields:
        vehicle_id        — unique string (e.g., "V0", "V1")
        state             — current VehicleState
        x_px, y_px        — current pixel position (updated every tick)
        node_id           — nearest or last completed road graph node
        task_id           — currently active task id (None if idle)
        pending_task_ids  — queue of pre-assigned tasks (up to MAX_PENDING_TASKS)
                            set when vehicle is MOVING_TO_DEST and a new task
                            is pre-assigned to it; executed after current delivery
        instruction       — current VehicleInstruction (None if idle)
        schedule_version  — must match instruction.schedule_version to be valid
        repair_until      — tick when repair completes (only relevant in REPAIRING)
        grace_since       — tick when idle grace period started (for parking timer)
    """
    vehicle_id:        str
    state:             VehicleState
    x_px:              float
    y_px:              float
    node_id:           str
    task_id:           Optional[str]       = None
    pending_task_ids:  list                = field(default_factory=list)
    instruction:       Optional[object]    = None   # VehicleInstruction
    schedule_version:  int                 = 0
    repair_until:      int                 = 0
    grace_since:       int                 = -1     # -1 means no grace period active


# ─────────────────────────────────────────────────────────
# CONFLICT EVENT
# ─────────────────────────────────────────────────────────

@dataclass
class ConflictEvent:
    """
    Describes a detected schedule conflict between the proposed schedule
    for vehicle_a and an existing reservation owned by vehicle_b.

    The Decision Engine receives a list of ConflictEvents and resolves them.

    Fields:
        segment_id   — the segment where conflict occurs
        enter_a      — when vehicle_a enters this segment (proposed)
        exit_a       — when vehicle_a exits this segment (proposed)
        vehicle_b    — the vehicle already owning this segment-time
        enter_b      — when vehicle_b enters
        exit_b       — when vehicle_b exits
        priority_b   — priority of vehicle_b's task (for priority filtering)
    """
    segment_id:  str
    enter_a:     int
    exit_a:      int
    vehicle_b:   str
    enter_b:     int
    exit_b:      int
    priority_b:  str = "NORMAL"


# ─────────────────────────────────────────────────────────
# SYSTEM EVENT
# ─────────────────────────────────────────────────────────

@dataclass
class SystemEvent:
    """
    A message published on the EventBus between modules.
    Modules subscribe to event types they care about.

    Using an event bus decouples producers from consumers —
    the Task Generator doesn't need to know who handles task creation.

    Fields:
        event_type — string identifier (e.g., "TASK_CREATED", "VEHICLE_FAILED")
        tick       — simulation tick when event occurred
        data       — arbitrary payload dict
    """
    event_type: str
    tick:       int
    data:       dict = field(default_factory=dict)


# ─────────────────────────────────────────────────────────
# PARKING SLOT
# ─────────────────────────────────────────────────────────

@dataclass
class ParkingSlot:
    """
    One parking position in a parking zone.

    For simplicity, each slot is identified by a road graph node
    near the parking zone. The vehicle drives to that node and parks.

    Fields:
        node_id     — road graph node the vehicle targets when parking
        zone_id     — which parking zone this slot belongs to (0 or 1)
        occupied_by — vehicle_id currently in this slot, or None
        center_px   — pixel position for display (= node position)
    """
    node_id:     str
    zone_id:     int
    center_px:   tuple
    occupied_by: Optional[str] = None
