"""
core/__init__.py

PURPOSE:
    Marks the 'core' directory as a Python package.
    Core contains foundational data structures and utilities that every
    other layer depends on. Nothing in core imports from brain, vehicle,
    or visualization — it is the bottom of the dependency stack.
"""
