"""
core/decision_cache.py — Route and Speed Profile Cache

PURPOSE:
    Avoids recomputing A* routes and speed profiles for repeated
    start/end node combinations. A* on a 56-node grid is fast, but
    with 10 vehicles and frequent task turnover, caching provides
    a meaningful speedup.

HOW IT WORKS:
    Route cache:  (start_node, end_node) → list of node_ids
    Speed cache:  route_key → speed_profile list

INVALIDATION:
    When a road node is disabled (e.g., due to an accident or reroute),
    all cached routes that pass through that node are removed.
    Invalidation uses exact node membership — not string pattern matching —
    to prevent false invalidations of unrelated routes.

THREAD SAFETY:
    Not thread-safe. Single-threaded pygame simulation — not needed.
"""

from __future__ import annotations
from typing import Optional


class DecisionCache:
    """
    Two-level cache:
        Level 1: route_cache  — maps (start, end) → list of node_ids
        Level 2: speed_cache  — maps route_key → speed_profile list

    The speed_cache is smaller and more volatile (density changes every tick),
    so it has a maximum size and evicts oldest entries when full.
    """

    MAX_SPEED_CACHE = 200   # max speed profiles to store

    def __init__(self):
        # Key: (start_node, end_node) → list of node_id strings
        self._route_cache: dict[tuple, list] = {}

        # Key: (route_key, density_hash) → speed_profile list
        self._speed_cache: dict[tuple, list] = {}

        # For route cache: store node sets for fast invalidation
        # Key: (start, end) → frozenset of node_ids in route
        self._route_node_sets: dict[tuple, frozenset] = {}

        # Insertion order for speed cache eviction
        self._speed_cache_order: list = []

    # ─── Route Cache ──────────────────────────────────────

    def cache_route(self, start: str, end: str, route: list) -> None:
        """
        Store a computed A* route.

        Args:
            start: starting node id
            end:   destination node id
            route: ordered list of node ids from start to end
        """
        key = (start, end)
        self._route_cache[key] = route
        # Store the set of nodes for O(1) invalidation check
        self._route_node_sets[key] = frozenset(route)

    def get_route(self, start: str, end: str) -> Optional[list]:
        """
        Retrieve a cached route if available.

        Returns:
            List of node_ids, or None if not cached.
        """
        return self._route_cache.get((start, end))

    def invalidate_node(self, node_id: str) -> int:
        """
        Remove all cached routes that pass through this node.

        Uses exact frozenset membership — no string matching —
        so "2_3" never accidentally matches "12_3".

        Args:
            node_id: the node that was disabled

        Returns:
            Number of routes invalidated
        """
        keys_to_remove = [
            key for key, node_set in self._route_node_sets.items()
            if node_id in node_set
        ]
        for key in keys_to_remove:
            del self._route_cache[key]
            del self._route_node_sets[key]
        return len(keys_to_remove)

    def invalidate_segment(self, segment_id: str) -> None:
        """
        Remove all cached routes that use this directed segment.
        Segment id format: "from_node__to_node".
        """
        parts = segment_id.split("__")
        if len(parts) == 2:
            from_node, to_node = parts
            keys_to_remove = [
                key for key, node_set in self._route_node_sets.items()
                if from_node in node_set and to_node in node_set
            ]
            for key in keys_to_remove:
                del self._route_cache[key]
                del self._route_node_sets[key]

    # ─── Speed Cache ──────────────────────────────────────

    def cache_speed(self, route_key: str, density_hash: int,
                    profile: list) -> None:
        """
        Store a speed profile for a route under current density conditions.

        Args:
            route_key:    string representation of route (e.g., "1_0-2_0-3_0")
            density_hash: hash of segment densities (changes when traffic changes)
            profile:      list of speed multipliers, one per segment
        """
        key = (route_key, density_hash)
        if key not in self._speed_cache:
            if len(self._speed_cache_order) >= self.MAX_SPEED_CACHE:
                # Evict oldest
                oldest = self._speed_cache_order.pop(0)
                self._speed_cache.pop(oldest, None)
            self._speed_cache_order.append(key)
        self._speed_cache[key] = profile

    def get_speed(self, route_key: str, density_hash: int) -> Optional[list]:
        """
        Retrieve a cached speed profile.

        Returns None if not cached or if density has changed
        (density_hash encodes the traffic conditions at cache time).
        """
        return self._speed_cache.get((route_key, density_hash))

    def clear_speed_cache(self) -> None:
        """Clear all speed profiles. Called when traffic changes significantly."""
        self._speed_cache.clear()
        self._speed_cache_order.clear()

    # ─── Stats ────────────────────────────────────────────

    def stats(self) -> dict:
        """Return cache statistics for the metrics panel."""
        return {
            "route_cache_size": len(self._route_cache),
            "speed_cache_size": len(self._speed_cache),
        }


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

cache = DecisionCache()
