"""
vehicle/vehicle_registry.py — Vehicle State Store (Single Source of Truth)

PURPOSE:
    The Registry is the ONLY place that stores authoritative vehicle state.
    No other module keeps a local copy of vehicle state — they all read
    and write through the Registry.

WHY THIS MATTERS:
    If multiple modules could modify vehicle state independently, state
    would diverge — the brain might think a vehicle is IDLE while the
    parking manager thinks it's PARKED. The Registry enforces a single
    consistent view of the fleet.

HOW IT WORKS:
    Stores VehicleRecord objects keyed by vehicle_id.
    Modules call:
        registry.get(vehicle_id)          → read a record
        registry.update(vehicle_id, ...)  → modify specific fields
        registry.snapshot()               → get a copy of all records
        registry.register(record)         → add a new vehicle

    update() uses keyword arguments so callers only specify the fields
    they're changing — other fields are preserved unchanged.

THREAD SAFETY:
    Not needed. Single-threaded pygame simulation.
"""

from __future__ import annotations
from typing import Optional
from core.models import VehicleRecord, VehicleState


class VehicleRegistry:
    """
    Central store for all vehicle state.

    Provides get, update, register, snapshot, and query operations.
    All state mutations go through update() to keep state consistent.
    """

    def __init__(self):
        # vehicle_id → VehicleRecord
        self._vehicles: dict[str, VehicleRecord] = {}

    # ─── Registration ─────────────────────────────────────

    def register(self, record: VehicleRecord) -> None:
        """
        Add a new vehicle to the registry.
        Called once per vehicle from main.py at startup.

        Args:
            record: A fully initialised VehicleRecord
        """
        self._vehicles[record.vehicle_id] = record

    # ─── Read ─────────────────────────────────────────────

    def get(self, vehicle_id: str) -> Optional[VehicleRecord]:
        """
        Retrieve the live record for a vehicle.

        Returns:
            VehicleRecord or None if vehicle_id not found
        """
        return self._vehicles.get(vehicle_id)

    def snapshot(self) -> list:
        """
        Return a list of all current VehicleRecords.

        This is a shallow copy of the list (the records themselves
        are not copied). Callers should not mutate the returned records
        directly — use update() instead.

        Returns:
            List of VehicleRecord
        """
        return list(self._vehicles.values())

    def all_ids(self) -> list:
        """Return all registered vehicle_ids."""
        return list(self._vehicles.keys())

    def count(self) -> int:
        """Total number of registered vehicles."""
        return len(self._vehicles)

    # ─── Write ────────────────────────────────────────────

    def update(self, vehicle_id: str, **kwargs) -> None:
        """
        Update specific fields of a vehicle's record.

        Only the provided keyword arguments are changed.
        All other fields remain as they were.

        Example:
            registry.update("V3", state=VehicleState.PARKED, task_id=None)

        This prevents accidental overwrites of unrelated fields.

        Args:
            vehicle_id: which vehicle to update
            **kwargs:   field names and new values to set
        """
        rec = self._vehicles.get(vehicle_id)
        if rec is None:
            return   # vehicle not found — silently ignore (may have been removed)

        for field_name, value in kwargs.items():
            if hasattr(rec, field_name):
                setattr(rec, field_name, value)
            else:
                # Programming error — warn but don't crash
                print(f"[Registry] Warning: unknown field '{field_name}' for {vehicle_id}")

    # ─── Query Helpers ────────────────────────────────────

    def vehicles_in_state(self, *states: VehicleState) -> list:
        """
        Return all vehicles currently in any of the given states.

        Args:
            *states: one or more VehicleState enum values

        Returns:
            List of VehicleRecord
        """
        state_set = set(states)
        return [r for r in self._vehicles.values() if r.state in state_set]

    def vehicle_count_by_state(self) -> dict:
        """
        Return a dict mapping VehicleState → count of vehicles in that state.
        Used by metrics_tracker.
        """
        counts = {s: 0 for s in VehicleState}
        for rec in self._vehicles.values():
            counts[rec.state] += 1
        return counts

    def increment_version(self, vehicle_id: str) -> int:
        """
        Increment the schedule_version for a vehicle.
        This invalidates any existing instruction the vehicle holds.

        Returns:
            The new version number
        """
        rec = self._vehicles.get(vehicle_id)
        if not rec:
            return 0
        rec.schedule_version += 1
        return rec.schedule_version

    def clear(self) -> None:
        """Remove all vehicles. Used for reset."""
        self._vehicles.clear()


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# All modules import this one 'registry' instance.
# ─────────────────────────────────────────────────────────

registry = VehicleRegistry()
