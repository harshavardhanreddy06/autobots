"""
vehicle/__init__.py

PURPOSE:
    Marks the 'vehicle' directory as a Python package.
    The vehicle layer contains the vehicle registry (state store),
    vehicle executor, and communication manager.
    It depends on core/ and brain/ modules.
"""
