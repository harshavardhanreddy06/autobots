"""
vehicle/comm_manager.py — Vehicle-to-Brain Communication Layer

PURPOSE:
    The Communication Manager receives notifications from vehicle executors
    (when they arrive at a pickup or drop) and drives all post-arrival
    state transitions by calling the appropriate CentralBrain pipeline methods.

    This is the bridge between the Vehicle Layer and the Brain Layer.
    Vehicles only call comm_mgr. Comm_mgr calls brain. Brain calls registry.
    This one-way dependency chain prevents circular imports.

POST-DELIVERY LOGIC (3 Paths):
    When a vehicle completes a delivery:

    Path A — Pre-assigned task:
        A task was already queued for this vehicle during delivery.
        → Immediately route to the pre-assigned pickup.
        → Highest throughput: zero idle time between deliveries.

    Path B — Immediate reassignment:
        No pre-assigned task, but tasks exist in the queue.
        → Immediately query allocator for next task.
        → Vehicle transitions directly to MOVING_TO_PICKUP.

    Path C — Adaptive grace / parking:
        No tasks available. Start the grace period.
        → ParkingManager handles the grace timer and eventually
          issues a park command if no task arrives.

PICKUP ARRIVED:
    Vehicle at pickup → immediate route to drop via brain.schedule_to_drop()
"""

from __future__ import annotations
from core.models import VehicleState
from brain.brain_logger import brain_log
from brain.task_manager import task_mgr
from brain.parking_manager import parking_mgr
from brain.metrics_tracker import metrics
from vehicle.vehicle_registry import registry


class CommManager:
    """
    Event handler for vehicle lifecycle events.

    Methods are called by vehicle.py when vehicles arrive at waypoints.
    Each method drives the appropriate next action via the Central Brain.
    """

    def on_pickup_reached(self, vehicle_id: str, task_id: str,
                          current_tick: int) -> None:
        """
        Vehicle has arrived at the pickup station.

        Records an ML training sample for the Smart Allocator:
        we now know the actual ticks it took from assignment to arrival.

        Next action: route to drop location.
        """
        task = task_mgr.get_task(task_id) if task_id else None
        if not task:
            registry.update(vehicle_id, state=VehicleState.IDLE, task_id=None)
            return

        brain_log(f"{vehicle_id} reached pickup for {task_id}")

        # ── ML: record actual arrival ticks for Allocator training ──
        if task.assign_tick and task.assign_tick > 0:
            try:
                from brain.task_allocator import allocator
                allocator.record_allocation_outcome(
                    vehicle_id   = vehicle_id,
                    pickup_x     = task.pickup_px[0],
                    pickup_y     = task.pickup_px[1],
                    assign_tick  = task.assign_tick,
                    arrival_tick = current_tick,
                    task         = task,
                )
            except Exception:
                pass

        task_mgr.mark_to_destination(task_id)

        # Route to drop
        from brain.central_brain import brain
        from config import STATION_DELAY_TICKS
        success = brain.schedule_to_drop(vehicle_id, task, current_tick + STATION_DELAY_TICKS)
        if not success:
            task_mgr.fail(task_id, reason="no_route_to_drop")
            registry.update(vehicle_id, state=VehicleState.IDLE, task_id=None)

    def on_delivery_completed(self, vehicle_id: str, task_id: str,
                              current_tick: int) -> None:
        """
        Vehicle has arrived at the drop station and completed delivery.

        Follows 3-path post-delivery logic.

        Args:
            vehicle_id:   vehicle that delivered
            task_id:      completed task
            current_tick: current simulation tick
        """
        # Complete the task
        if task_id:
            task = task_mgr.get_task(task_id)
            if task and task.assign_tick:
                metrics.record_completion(task.assign_tick, current_tick)
            task_mgr.complete(task_id, current_tick)
            brain_log(f"{vehicle_id} delivered {task_id} @{current_tick}")

        # Clear task from registry
        rec = registry.get(vehicle_id)
        if not rec:
            return

        registry.update(vehicle_id, state=VehicleState.IDLE, task_id=None)

        # ── Path A: Pre-assigned task in queue ────────────
        if rec.pending_task_ids:
            next_task_id = rec.pending_task_ids.pop(0)
            next_task = task_mgr.get_task(next_task_id)
            if next_task:
                registry.update(vehicle_id, pending_task_ids=rec.pending_task_ids)
                from brain.central_brain import brain
                from config import STATION_DELAY_TICKS
                success = brain.schedule_to_pickup(vehicle_id, next_task, current_tick + STATION_DELAY_TICKS)
                if success:
                    task_mgr.assign(next_task_id, vehicle_id, current_tick)
                    task_mgr.mark_pickup_enroute(next_task_id)
                    metrics.pre_assignment_hits += 1
                    brain_log(f"Path A: {vehicle_id} → {next_task_id}")
                    return

        # ── Path B: Immediate reassignment from queue ─────
        pending = task_mgr.get_pending()
        if pending:
            from brain.task_allocator import allocator
            # Find best task for this vehicle from its current position
            rec = registry.get(vehicle_id)   # refresh
            if rec:
                best_task = self._find_best_for_vehicle(rec, pending)
                if best_task:
                    from brain.central_brain import brain
                    from config import STATION_DELAY_TICKS
                    success = brain.schedule_to_pickup(vehicle_id, best_task, current_tick + STATION_DELAY_TICKS)
                    if success:
                        task_mgr.assign(best_task.task_id, vehicle_id, current_tick)
                        task_mgr.mark_pickup_enroute(best_task.task_id)
                        metrics.immediate_reassignments += 1
                        brain_log(f"Path B: {vehicle_id} → {best_task.task_id}")
                        return

        # ── Path C: Grace period → parking ────────────────
        parking_mgr.start_grace(vehicle_id, current_tick)
        brain_log(f"Path C: {vehicle_id} grace period started")

    def on_repair_complete(self, vehicle_id: str, current_tick: int) -> None:
        """
        Vehicle repair is complete. Returns to IDLE.
        Called by failure_manager.check_repair().

        Args:
            vehicle_id:   repaired vehicle
            current_tick: current tick
        """
        registry.update(vehicle_id, state=VehicleState.IDLE)
        brain_log(f"{vehicle_id} back in service @{current_tick}")
        # The allocator will pick it up in the next allocation cycle

    def send_to_parking(self, vehicle_id: str, current_tick: int) -> None:
        """
        Explicitly send a vehicle to parking.
        Called by ParkingManager after grace period expires.

        Args:
            vehicle_id:   vehicle to park
            current_tick: current tick
        """
        from brain.central_brain import brain
        success = brain.schedule_to_parking(vehicle_id, current_tick)
        if not success:
            # No parking slot available — stay idle
            registry.update(vehicle_id, state=VehicleState.IDLE)

    # ─── Helpers ──────────────────────────────────────────

    def _find_best_for_vehicle(self, rec, pending_tasks: list):
        """
        From the vehicle's current drop position, find the nearest
        pending task pickup. Simple nearest-pickup heuristic for Path B.

        Args:
            rec:           VehicleRecord of the vehicle just arrived at drop
            pending_tasks: list of PENDING Task objects

        Returns:
            Best Task or None
        """
        import math
        best_task = None
        best_dist = float("inf")
        for task in pending_tasks:
            d = math.hypot(rec.x_px - task.pickup_px[0],
                           rec.y_px - task.pickup_px[1])
            if d < best_dist:
                best_dist = d
                best_task = task
        return best_task


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

comm_mgr = CommManager()
