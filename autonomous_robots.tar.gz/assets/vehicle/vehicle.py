"""
vehicle/vehicle.py — Vehicle Executor (Pure Movement Engine)

PURPOSE:
    A vehicle is a PURE EXECUTOR. It has NO intelligence.
    It reads its current VehicleInstruction from the Registry,
    checks that the schedule_version matches (instruction is current),
    interpolates its position along the schedule, and notifies
    the CommManager when it arrives at its destination.

HOW MOVEMENT WORKS:
    The schedule is a list of ScheduleEntry:
        (segment_id, from_node, to_node, enter_tick, exit_tick)

    For each simulation tick, the vehicle:
        1. Finds the segment where enter_tick ≤ current_tick < exit_tick
        2. Computes fraction = (current_tick - enter_tick) / (exit_tick - enter_tick)
        3. Linearly interpolates position between from_node and to_node positions
        4. Updates its position in the Registry

    This gives smooth, deterministic movement without per-tick speed math.

WAITING FOR DEPARTURE:
    If current_tick < schedule[0].enter_tick:
    → Vehicle is WAITING_FOR_START. Stays at its current position.
    → Auto-transitions to MOVING state when departure tick arrives.

LANE OFFSET:
    For visual clarity, vehicles moving in opposite directions on the
    same road are offset to their respective lanes:
        Moving right: y -= LANE_OFFSET
        Moving left:  y += LANE_OFFSET
        Moving up:    x -= LANE_OFFSET
        Moving down:  x += LANE_OFFSET

REPAIR CHECK:
    REPAIRING vehicles check their repair_until tick every frame.
    When repair completes, they return to IDLE automatically.
"""

from __future__ import annotations
from config import BASE_SPEED, LANE_GAP, LANE_WIDTH, VEHICLE_RADIUS
from core.models import VehicleState
from brain.road_graph import graph
from vehicle.vehicle_registry import registry

# Visual lane offset: half the distance between lane centers
LANE_OFFSET = LANE_WIDTH / 2 + LANE_GAP / 2


class Vehicle:
    """
    A single autonomous vehicle — pure position interpolator.

    Each Vehicle object holds only its vehicle_id. All state is
    stored in the Registry and read each tick. This ensures the
    Registry is always the single source of truth.
    """

    def __init__(self, vehicle_id: str):
        self.vehicle_id = vehicle_id
        self._has_notified_arrival = False   # prevents duplicate arrival events

    def tick(self, current_tick: int) -> None:
        """
        Main update called once per frame.

        Args:
            current_tick: simulation tick counter
        """
        rec = registry.get(self.vehicle_id)
        if not rec:
            return

        # ── Repair check ──────────────────────────────────
        if rec.state == VehicleState.REPAIRING:
            from brain.failure_manager import failure_mgr
            failure_mgr.check_repair(self.vehicle_id, current_tick)
            return

        if rec.state == VehicleState.FAILED:
            return

        # ── Auto-transition WAITING_FOR_START → MOVING ───
        if rec.state == VehicleState.WAITING_FOR_START:
            if (rec.instruction and rec.instruction.schedule and
                    current_tick >= rec.instruction.schedule[0].enter_tick):
                from core.models import VehicleState as VS
                new_state = {
                    "TO_PICKUP":  VS.MOVING_TO_PICKUP,
                    "TO_DROP":    VS.MOVING_TO_DEST,
                    "TO_PARKING": VS.MOVING_TO_PARKING,
                }.get(rec.instruction.destination_type, VS.IDLE)
                registry.update(self.vehicle_id, state=new_state)
                rec = registry.get(self.vehicle_id)   # refresh

        # ── No instruction → stay idle ────────────────────
        if not rec.instruction:
            return

        instr = rec.instruction

        # ── Version check: stale instruction? ─────────────
        if instr.schedule_version != rec.schedule_version:
            return   # instruction is stale — wait for new one

        schedule = instr.schedule

        # ── Empty schedule → already at destination ───────
        if not schedule:
            if not self._has_notified_arrival:
                self._has_notified_arrival = True
                self._on_arrival(rec, current_tick)
            return

        # ── Check if fully arrived ────────────────────────
        last_entry = schedule[-1]
        if current_tick >= last_entry.exit_tick:
            if not self._has_notified_arrival:
                self._has_notified_arrival = True
                # Snap to final position
                final_pos = graph.node_pos(last_entry.to_node)
                registry.update(
                    self.vehicle_id,
                    x_px=final_pos[0],
                    y_px=final_pos[1],
                    node_id=last_entry.to_node
                )
                self._on_arrival(rec, current_tick)
            return

        # Not yet arrived — reset flag for next instruction
        self._has_notified_arrival = False

        # ── Waiting for departure ─────────────────────────
        if current_tick < schedule[0].enter_tick:
            # Stay at start position
            start_pos = graph.node_pos(schedule[0].from_node)
            registry.update(
                self.vehicle_id,
                x_px=start_pos[0],
                y_px=start_pos[1],
                node_id=schedule[0].from_node
            )
            return

        # ── Find current segment and interpolate ──────────
        for entry in schedule:
            if entry.enter_tick <= current_tick < entry.exit_tick:
                duration = entry.exit_tick - entry.enter_tick
                fraction = (current_tick - entry.enter_tick) / max(1, duration)
                fraction = min(1.0, max(0.0, fraction))

                from_pos = graph.node_pos(entry.from_node)
                to_pos   = graph.node_pos(entry.to_node)

                # Base position (center of road)
                base_x = from_pos[0] + fraction * (to_pos[0] - from_pos[0])
                base_y = from_pos[1] + fraction * (to_pos[1] - from_pos[1])

                # Lane offset for visual lane separation
                ox, oy = self._lane_offset(from_pos, to_pos)

                registry.update(
                    self.vehicle_id,
                    x_px    = base_x + ox,
                    y_px    = base_y + oy,
                    node_id = entry.from_node
                )
                return

    # ─── Arrival ──────────────────────────────────────────

    def _on_arrival(self, rec, current_tick: int) -> None:
        """
        Handle arrival at the scheduled destination.
        Notifies CommManager which drives all state transitions.

        Args:
            rec:          VehicleRecord at time of arrival
            current_tick: current simulation tick
        """
        from vehicle.comm_manager import comm_mgr

        dest_type = rec.instruction.destination_type if rec.instruction else ""

        if dest_type == "TO_PICKUP" and rec.state == VehicleState.MOVING_TO_PICKUP:
            comm_mgr.on_pickup_reached(self.vehicle_id, rec.task_id, current_tick)

        elif dest_type == "TO_DROP" and rec.state == VehicleState.MOVING_TO_DEST:
            comm_mgr.on_delivery_completed(self.vehicle_id, rec.task_id, current_tick)

        elif dest_type == "TO_PARKING":
            # Arrived at parking — just update state
            registry.update(
                self.vehicle_id,
                state       = VehicleState.PARKED,
                instruction = None,
                grace_since = -1,
            )

    # ─── Lane Offset ──────────────────────────────────────

    def _lane_offset(self, from_pos: tuple, to_pos: tuple) -> tuple:
        """
        Compute pixel offset to place vehicle in correct lane.

        Direction-to-lane mapping:
            Moving right (dx > 0) → top lane  (offset y up)
            Moving left  (dx < 0) → bottom lane (offset y down)
            Moving down  (dy > 0) → right lane (offset x right)
            Moving up    (dy < 0) → left lane  (offset x left)

        Returns:
            (ox, oy) pixel offset to add to base position
        """
        dx = to_pos[0] - from_pos[0]
        dy = to_pos[1] - from_pos[1]

        if abs(dx) > abs(dy):
            # Horizontal movement
            if dx > 0:
                return (0, -LANE_OFFSET)   # moving right → top lane
            else:
                return (0, +LANE_OFFSET)   # moving left → bottom lane
        else:
            # Vertical movement
            if dy > 0:
                return (+LANE_OFFSET, 0)   # moving down → right lane
            else:
                return (-LANE_OFFSET, 0)   # moving up → left lane

        return (0, 0)
