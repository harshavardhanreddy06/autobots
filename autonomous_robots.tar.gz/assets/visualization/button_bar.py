"""
visualization/button_bar.py — Clickable On-Screen Button Bar

PURPOSE:
    Draws a row of clickable buttons at the bottom of the MAP area
    (not the metrics panel). Provides mouse-clickable alternatives to
    every keyboard shortcut so the simulation is fully usable in a browser
    (where keyboard focus can be lost) or for non-technical demos.

BUTTONS (left to right):
    [▶/⏸ Start/Pause]  [+Speed]  [-Speed]  [B Add Bot]  [T Task]
    [H Heatmap]         [F Fail]  [1 Test1] [2 Test2]    [3 Test3]

USAGE:
    bar = ButtonBar()
    # in game loop:
    actions = bar.handle_event(event, map_w, map_h)
    for action in actions:
        handle_action(action)
    bar.draw(screen, map_w, map_h, paused, sim_speed)
"""

from __future__ import annotations
import pygame

# Action string constants
ACT_PAUSE       = "PAUSE"
ACT_SPEED_UP    = "SPEED_UP"
ACT_SPEED_DOWN  = "SPEED_DOWN"
ACT_ADD_BOT     = "ADD_BOT"
ACT_FORCE_TASK  = "FORCE_TASK"
ACT_HEATMAP     = "HEATMAP"
ACT_FAIL_BOT    = "FAIL_BOT"
ACT_FULLSCREEN  = "FULLSCREEN"
ACT_TEST_1      = "TEST_1"
ACT_TEST_2      = "TEST_2"
ACT_TEST_3      = "TEST_3"

# Visual config
BAR_H       = 42
BTN_H       = 32
BTN_MARGIN  = 6
BTN_RADIUS  = 6
FONT_SIZE   = 13

# Color palette
_BG      = (18, 18, 28)
_BORDER  = (55, 55, 80)
_NORMAL  = (38, 42, 62)
_HOVER   = (55, 62, 95)
_ACTIVE  = (30, 90, 170)
_TEST    = (35, 70, 35)
_TEST_H  = (45, 110, 45)
_TEXT    = (220, 225, 255)
_TEXT_DIM= (120, 125, 160)


class _Button:
    def __init__(self, label: str, action: str,
                 color=None, hover_color=None, tooltip: str = ""):
        self.label       = label
        self.action      = action
        self.color       = color or _NORMAL
        self.hover_color = hover_color or _HOVER
        self.tooltip     = tooltip
        self.rect        = pygame.Rect(0, 0, 0, 0)  # set by layout

    def hit(self, mx: int, my: int) -> bool:
        return self.rect.collidepoint(mx, my)


class ButtonBar:
    """
    On-screen button bar drawn at the bottom of the map area.
    Call handle_event() then draw() each frame.
    """

    def __init__(self):
        self._buttons: list[_Button] = [
            _Button("▶ START",  ACT_PAUSE,      _ACTIVE, (50, 120, 220), "Space: Pause/Resume"),
            _Button("⚡ +SPD",  ACT_SPEED_UP,   _NORMAL, _HOVER,         "+: Speed up"),
            _Button("🐢 -SPD",  ACT_SPEED_DOWN, _NORMAL, _HOVER,         "-: Slow down"),
            _Button("🤖 +BOT",  ACT_ADD_BOT,    _NORMAL, _HOVER,         "B: Add a bot"),
            _Button("📦 TASK",  ACT_FORCE_TASK, _NORMAL, _HOVER,         "T: Force new task"),
            _Button("🌡 HEAT",  ACT_HEATMAP,    _NORMAL, _HOVER,         "H: Toggle heatmap"),
            _Button("💥 FAIL",  ACT_FAIL_BOT,   (70,20,20),(110,30,30),  "F: Fail random bot"),
            _Button("⛶ FULL",  ACT_FULLSCREEN, (25,45,70),(40,70,120),   "F11: Fullscreen"),
            _Button("🔬 T1",    ACT_TEST_1,     _TEST,   _TEST_H,        "Test 1: 4-Bot Junction"),
            _Button("🔬 T2",    ACT_TEST_2,     _TEST,   _TEST_H,        "Test 2: 8-Bot Merge"),
            _Button("🔬 T3",    ACT_TEST_3,     _TEST,   _TEST_H,        "Test 3: Fleet Stress"),
        ]
        self._hover_idx: int  = -1
        self._font = None
        self._tip_font = None
        self._fullscreen: bool = False  # track toggle state

    def _init_fonts(self):
        try:
            self._font     = pygame.font.SysFont("Arial", FONT_SIZE, bold=True)
            self._tip_font = pygame.font.SysFont("Arial", 11)
        except Exception:
            self._font = self._tip_font = pygame.font.Font(None, FONT_SIZE + 2)

    def _layout(self, map_w: int, map_h: int):
        """Compute button rects to fit evenly across the bar."""
        bar_y   = map_h - BAR_H
        n       = len(self._buttons)
        total_m = BTN_MARGIN * (n + 1)
        btn_w   = max(60, (map_w - total_m) // n)

        for i, btn in enumerate(self._buttons):
            x = BTN_MARGIN + i * (btn_w + BTN_MARGIN)
            y = bar_y + (BAR_H - BTN_H) // 2
            btn.rect = pygame.Rect(x, y, btn_w, BTN_H)

    def handle_event(self, event: pygame.event.Event,
                     map_w: int, map_h: int) -> list[str]:
        """
        Process one pygame event. Returns list of action strings triggered.

        Args:
            event:  pygame event
            map_w:  map area width
            map_h:  total screen height

        Returns:
            List of ACT_* constants (usually 0 or 1 element)
        """
        self._layout(map_w, map_h)
        actions = []

        if event.type == pygame.MOUSEMOTION:
            mx, my = event.pos
            self._hover_idx = -1
            for i, btn in enumerate(self._buttons):
                if btn.hit(mx, my):
                    self._hover_idx = i
                    break

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            for btn in self._buttons:
                if btn.hit(mx, my):
                    actions.append(btn.action)
                    break

        return actions

    def draw(self, screen: pygame.Surface,
             map_w: int, map_h: int,
             paused: bool, sim_speed: float, tick: int = 1) -> None:
        """
        Draw the button bar at the bottom of the map.

        Args:
            screen:    pygame surface
            map_w:     map area width
            map_h:     total screen height
            paused:    if True, shows RESUME label on first button
            sim_speed: current sim speed (shown as tooltip info)
        """
        if self._font is None:
            self._init_fonts()

        self._layout(map_w, map_h)
        bar_y = map_h - BAR_H

        # Bar background
        pygame.draw.rect(screen, _BG, (0, bar_y, map_w, BAR_H))
        pygame.draw.line(screen, _BORDER, (0, bar_y), (map_w, bar_y), 1)

        for i, btn in enumerate(self._buttons):
            is_hover = (i == self._hover_idx)
            color    = btn.hover_color if is_hover else btn.color

            # Button background
            pygame.draw.rect(screen, color, btn.rect, border_radius=BTN_RADIUS)
            pygame.draw.rect(screen, _BORDER, btn.rect, 1, border_radius=BTN_RADIUS)

            # Label
            label_surf = self._font.render(btn.label, True, _TEXT)
            lx = btn.rect.centerx - label_surf.get_width() // 2
            ly = btn.rect.centery - label_surf.get_height() // 2
            screen.blit(label_surf, (lx, ly))

            # Tooltip on hover
            if is_hover and self._tip_font and btn.tooltip:
                tip = self._tip_font.render(btn.tooltip, True, (255, 240, 150))
                tx  = btn.rect.left
                ty  = bar_y - 20
                # Keep tooltip within screen
                if tx + tip.get_width() > map_w:
                    tx = map_w - tip.get_width() - 4
                bg  = pygame.Surface((tip.get_width() + 6, tip.get_height() + 4), pygame.SRCALPHA)
                bg.fill((0, 0, 0, 160))
                screen.blit(bg, (tx - 3, ty - 2))
                screen.blit(tip, (tx, ty))

        # Speed indicator
        speed_txt = self._tip_font.render(f"Speed: {sim_speed:.1f}x", True, _TEXT_DIM)
        screen.blit(speed_txt, (map_w - speed_txt.get_width() - 8, bar_y + 14))


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

button_bar = ButtonBar()
