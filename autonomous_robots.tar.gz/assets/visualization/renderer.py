"""
visualization/renderer.py — Pygame Map and Vehicle Renderer

PURPOSE:
    Draws everything on the left portion of the screen (the map area):
        - Road network with dual lanes and direction arrows
        - Intersection markers
        - Station buffer zones (semi-transparent)
        - Pickup (green) and drop (blue) stations
        - Parking zones and gates
        - All vehicles (color-coded by state, with visual effects)
        - Route previews for active vehicles
        - Congestion heatmap overlay (toggle with H key)
        - Failure overlay for broken vehicles

VEHICLE COLORS (from config.py):
    IDLE             → light grey
    WAITING_FOR_START → purple (pulsing ring)
    MOVING_TO_PICKUP  → cyan
    MOVING_TO_DEST    → yellow (filled — "carrying cargo")
    MOVING_TO_PARKING → light blue
    PARKED           → dark blue
    FAILED           → red (X mark + warning ring)
    REPAIRING        → orange (pulsing)

PERFORMANCE:
    Buffer zones use a cached surface (only redrawn on resize).
    Heatmap uses a surface with alpha blending.
    The main draw sequence is: background → roads → stations → vehicles → overlays.
"""

from __future__ import annotations
import math
import pygame
from config import (
    LANE_WIDTH, LANE_GAP, STATION_SIZE, BUFFER_RADIUS, VEHICLE_RADIUS,
    BG, LANE_COLOR, MEDIAN_COLOR, INTERSECTION_COL,
    PICKUP_COLOR, DROP_COLOR, PARKING_BG,
    GATE_ENTRY_COLOR, GATE_EXIT_COLOR,
    ARROW_COLOR, BUFFER_ALPHA,
    ROUTE_COLOR, HEATMAP_HIGH, HEATMAP_LOW, CONFLICT_COLOR,
    COLOR_IDLE, COLOR_WAITING_FOR_START, COLOR_MOVING_TO_PICKUP,
    COLOR_MOVING_TO_DEST, COLOR_MOVING_TO_PARKING, COLOR_PARKED,
    COLOR_FAILED, COLOR_REPAIRING, WHITE
)
from core.models import VehicleState
from vehicle.vehicle_registry import registry
from brain.road_graph import graph


# Lane offset constant (mirrors vehicle.py)
_LANE_OFFSET = LANE_WIDTH / 2 + LANE_GAP / 2

# State → color mapping
STATE_COLORS = {
    VehicleState.IDLE:              COLOR_IDLE,
    VehicleState.WAITING_FOR_START: COLOR_WAITING_FOR_START,
    VehicleState.MOVING_TO_PICKUP:  COLOR_MOVING_TO_PICKUP,
    VehicleState.MOVING_TO_DEST:    COLOR_MOVING_TO_DEST,
    VehicleState.MOVING_TO_PARKING: COLOR_MOVING_TO_PARKING,
    VehicleState.PARKED:            COLOR_PARKED,
    VehicleState.FAILED:            COLOR_FAILED,
    VehicleState.REPAIRING:         COLOR_REPAIRING,
}


class Renderer:
    """
    Stateful renderer that caches surfaces and handles all drawing.
    """

    def __init__(self):
        self._buffer_surf: pygame.Surface = None   # cached buffer zone surface
        self._map_size: tuple = (0, 0)             # cached map dimensions
        self.show_heatmap: bool = False            # toggle with H key
        self.show_routes: bool = True              # toggle with R key

        # Map geometry (set by setup())
        self._vertical_x: list = []
        self._horizontal_y: list = []
        self._intersections: list = []    # list of (x, y) tuples
        self._pickups: list = []          # list of (x, y, node_id) tuples
        self._drops: list = []
        self._parking_zones: list = []    # list of pygame.Rect
        self._parking_gates: list = []    # list of (pygame.Rect, "entry"|"exit")
        self._map_w: int = 0
        self._map_h: int = 0

    def setup(self, vertical_x, horizontal_y, intersections,
              pickups, drops, parking_zones, parking_gates,
              map_w, map_h) -> None:
        """
        Set map geometry. Called from main.py after map load / resize.
        Invalidates cached surfaces.
        """
        self._vertical_x    = vertical_x
        self._horizontal_y  = horizontal_y
        self._intersections = intersections
        self._pickups       = pickups
        self._drops         = drops
        self._parking_zones = parking_zones
        self._parking_gates = parking_gates
        self._map_w         = map_w
        self._map_h         = map_h
        self._buffer_surf   = None   # force rebuild

    # ─────────────────────────────────────────────────────
    # MAIN DRAW CALL
    # ─────────────────────────────────────────────────────

    def draw(self, screen: pygame.Surface, current_tick: int) -> None:
        """
        Draw everything on the map area.

        Args:
            screen:       pygame display surface
            current_tick: for animations
        """
        # 1. Background
        pygame.draw.rect(screen, BG, (0, 0, self._map_w, self._map_h))

        # 2. Roads
        self._draw_roads(screen)

        # 3. Intersection markers
        self._draw_intersections(screen)

        # 4. Buffer zones (semi-transparent)
        self._draw_buffers(screen)

        # 5. Stations
        self._draw_stations(screen)

        # 6. Parking zones and gates
        self._draw_parking(screen)

        # 7. Heatmap overlay
        if self.show_heatmap:
            self._draw_heatmap(screen, current_tick)

        # 8. Route previews
        if self.show_routes:
            self._draw_routes(screen)

        # 9. Vehicles (drawn last — on top of everything)
        self._draw_vehicles(screen, current_tick)

    # ─────────────────────────────────────────────────────
    # ROADS
    # ─────────────────────────────────────────────────────

    def _draw_roads(self, screen: pygame.Surface) -> None:
        """Draw all road lanes with direction arrows."""

        for cx in self._vertical_x:
            # Left lane (northbound) and right lane (southbound)
            lx = cx - _LANE_OFFSET
            rx = cx + _LANE_OFFSET

            pygame.draw.rect(screen, LANE_COLOR,
                             (lx - LANE_WIDTH / 2, 0, LANE_WIDTH, self._map_h))
            pygame.draw.rect(screen, LANE_COLOR,
                             (rx - LANE_WIDTH / 2, 0, LANE_WIDTH, self._map_h))
            # Median
            pygame.draw.rect(screen, MEDIAN_COLOR,
                             (lx + LANE_WIDTH / 2, 0, LANE_GAP, self._map_h))

            # Direction arrows every 100 px
            for y in range(80, self._map_h, 100):
                self._draw_arrow_up(screen, lx, y)
                self._draw_arrow_down(screen, rx, y)

        for cy in self._horizontal_y:
            # Top lane (eastbound) and bottom lane (westbound)
            ty = cy - _LANE_OFFSET
            by = cy + _LANE_OFFSET

            pygame.draw.rect(screen, LANE_COLOR,
                             (0, ty - LANE_WIDTH / 2, self._map_w, LANE_WIDTH))
            pygame.draw.rect(screen, LANE_COLOR,
                             (0, by - LANE_WIDTH / 2, self._map_w, LANE_WIDTH))
            # Median
            pygame.draw.rect(screen, MEDIAN_COLOR,
                             (0, ty + LANE_WIDTH / 2, self._map_w, LANE_GAP))

            # Direction arrows every 100 px
            for x in range(80, self._map_w, 100):
                self._draw_arrow_right(screen, x, ty)
                self._draw_arrow_left(screen, x, by)

    def _draw_arrow_up(self, screen, x, y):
        s = 4
        pygame.draw.polygon(screen, ARROW_COLOR, [
            (x, y - s - 2), (x - s, y + s), (x + s, y + s)
        ])

    def _draw_arrow_down(self, screen, x, y):
        s = 4
        pygame.draw.polygon(screen, ARROW_COLOR, [
            (x, y + s + 2), (x - s, y - s), (x + s, y - s)
        ])

    def _draw_arrow_right(self, screen, x, y):
        s = 4
        pygame.draw.polygon(screen, ARROW_COLOR, [
            (x + s + 2, y), (x - s, y - s), (x - s, y + s)
        ])

    def _draw_arrow_left(self, screen, x, y):
        s = 4
        pygame.draw.polygon(screen, ARROW_COLOR, [
            (x - s - 2, y), (x + s, y - s), (x + s, y + s)
        ])

    # ─────────────────────────────────────────────────────
    # INTERSECTIONS
    # ─────────────────────────────────────────────────────

    def _draw_intersections(self, screen: pygame.Surface) -> None:
        for x, y in self._intersections:
            pygame.draw.circle(screen, INTERSECTION_COL, (int(x), int(y)), 6)

    # ─────────────────────────────────────────────────────
    # STATION BUFFERS
    # ─────────────────────────────────────────────────────

    def _draw_buffers(self, screen: pygame.Surface) -> None:
        """Draw semi-transparent buffer circles around all stations."""
        size = (self._map_w, self._map_h)
        if self._buffer_surf is None or self._buffer_surf.get_size() != size:
            self._buffer_surf = pygame.Surface(size, pygame.SRCALPHA)
            for x, y, _ in self._pickups + self._drops:
                pygame.draw.circle(
                    self._buffer_surf,
                    (100, 150, 200, BUFFER_ALPHA),
                    (int(x), int(y)), BUFFER_RADIUS
                )
        screen.blit(self._buffer_surf, (0, 0))

    # ─────────────────────────────────────────────────────
    # STATIONS
    # ─────────────────────────────────────────────────────

    def _draw_stations(self, screen: pygame.Surface) -> None:
        half = STATION_SIZE // 2
        for x, y, _ in self._pickups:
            pygame.draw.rect(screen, PICKUP_COLOR,
                             (x - half, y - half, STATION_SIZE, STATION_SIZE))
            pygame.draw.rect(screen, WHITE,
                             (x - half, y - half, STATION_SIZE, STATION_SIZE), 1)

        for x, y, _ in self._drops:
            pygame.draw.rect(screen, DROP_COLOR,
                             (x - half, y - half, STATION_SIZE, STATION_SIZE))
            pygame.draw.rect(screen, WHITE,
                             (x - half, y - half, STATION_SIZE, STATION_SIZE), 1)

    # ─────────────────────────────────────────────────────
    # PARKING
    # ─────────────────────────────────────────────────────

    def _draw_parking(self, screen: pygame.Surface) -> None:
        for zone in self._parking_zones:
            pygame.draw.rect(screen, PARKING_BG, zone, border_radius=4)
            pygame.draw.rect(screen, (60, 60, 80), zone, 2, border_radius=4)

        for gate_rect, gtype in self._parking_gates:
            color = GATE_ENTRY_COLOR if gtype == "entry" else GATE_EXIT_COLOR
            pygame.draw.rect(screen, color, gate_rect)

    # ─────────────────────────────────────────────────────
    # VEHICLES
    # ─────────────────────────────────────────────────────

    def _draw_vehicles(self, screen: pygame.Surface, current_tick: int) -> None:
        """Draw all vehicles with state-based colors and animations."""
        all_records = registry.snapshot()

        for rec in all_records:
            x, y = int(rec.x_px), int(rec.y_px)
            color = STATE_COLORS.get(rec.state, COLOR_IDLE)

            # Pulse animation for special states (period = 60 ticks)
            pulse = 0.5 + 0.5 * math.sin(current_tick * 0.15 + hash(rec.vehicle_id) % 10)

            if rec.state == VehicleState.FAILED:
                # Red pulsing ring + X mark
                ring_r = int(VEHICLE_RADIUS + 4 + 3 * pulse)
                pygame.draw.circle(screen, (255, 0, 0), (x, y), ring_r, 2)
                pygame.draw.circle(screen, color, (x, y), VEHICLE_RADIUS)
                # X mark
                d = VEHICLE_RADIUS - 2
                pygame.draw.line(screen, WHITE, (x - d, y - d), (x + d, y + d), 2)
                pygame.draw.line(screen, WHITE, (x + d, y - d), (x - d, y + d), 2)

            elif rec.state == VehicleState.REPAIRING:
                # Orange pulsing ring
                ring_r = int(VEHICLE_RADIUS + 3 + 2 * pulse)
                pygame.draw.circle(screen, COLOR_REPAIRING, (x, y), ring_r, 2)
                pygame.draw.circle(screen, color, (x, y), VEHICLE_RADIUS)

            elif rec.state == VehicleState.WAITING_FOR_START:
                # Purple pulsing outer ring
                ring_r = int(VEHICLE_RADIUS + 2 + 3 * pulse)
                pygame.draw.circle(screen, COLOR_WAITING_FOR_START, (x, y), ring_r, 1)
                pygame.draw.circle(screen, color, (x, y), VEHICLE_RADIUS)

            elif rec.state == VehicleState.MOVING_TO_DEST:
                # Yellow filled (carrying cargo) — slightly larger
                pygame.draw.circle(screen, color, (x, y), VEHICLE_RADIUS + 1)
                pygame.draw.circle(screen, WHITE, (x, y), VEHICLE_RADIUS + 1, 1)

            elif rec.state == VehicleState.PARKED:
                # Dark blue + P label
                pygame.draw.circle(screen, color, (x, y), VEHICLE_RADIUS)
                pygame.draw.circle(screen, (100, 130, 255), (x, y), VEHICLE_RADIUS, 1)

            else:
                pygame.draw.circle(screen, color, (x, y), VEHICLE_RADIUS)
                pygame.draw.circle(screen, WHITE, (x, y), VEHICLE_RADIUS, 1)

            # Vehicle ID label
            try:
                font = pygame.font.SysFont("Arial", 9)
                label = font.render(rec.vehicle_id, True, WHITE)
                screen.blit(label, (x - label.get_width() // 2, y - VEHICLE_RADIUS - 12))
            except Exception:
                pass

    # ─────────────────────────────────────────────────────
    # ROUTE PREVIEWS
    # ─────────────────────────────────────────────────────

    def _draw_routes(self, screen: pygame.Surface) -> None:
        """Draw thin route lines for all active vehicles."""
        all_records = registry.snapshot()
        for rec in all_records:
            if not rec.instruction or not rec.instruction.schedule:
                continue
            if rec.state not in (VehicleState.MOVING_TO_PICKUP,
                                 VehicleState.MOVING_TO_DEST,
                                 VehicleState.WAITING_FOR_START):
                continue

            pts = []
            sched = rec.instruction.schedule
            for entry in sched:
                pos = graph.node_pos(entry.from_node)
                pts.append((int(pos[0]), int(pos[1])))
            if sched:
                last = graph.node_pos(sched[-1].to_node)
                pts.append((int(last[0]), int(last[1])))

            if len(pts) >= 2:
                pygame.draw.lines(screen, ROUTE_COLOR, False, pts, 1)

    # ─────────────────────────────────────────────────────
    # HEATMAP
    # ─────────────────────────────────────────────────────

    def _draw_heatmap(self, screen: pygame.Surface, current_tick: int) -> None:
        """
        Draw a congestion heatmap overlay.
        High-density segments glow red; low-density glow blue.
        """
        from brain.traffic_snapshot import traffic_snap
        busy = traffic_snap.busy_segments(current_tick, max_count=20)
        if not busy:
            return

        max_density = max((d for _, d in busy), default=1)

        heat_surf = pygame.Surface((self._map_w, self._map_h), pygame.SRCALPHA)
        for seg_id, density in busy:
            parts = seg_id.split("__")
            if len(parts) != 2:
                continue
            from_pos = graph.node_pos(parts[0])
            to_pos   = graph.node_pos(parts[1])

            intensity = density / max(1, max_density)
            # Lerp between HEATMAP_LOW and HEATMAP_HIGH
            r = int(HEATMAP_LOW[0] + intensity * (HEATMAP_HIGH[0] - HEATMAP_LOW[0]))
            g = int(HEATMAP_LOW[1] + intensity * (HEATMAP_HIGH[1] - HEATMAP_LOW[1]))
            b = int(HEATMAP_LOW[2] + intensity * (HEATMAP_HIGH[2] - HEATMAP_LOW[2]))
            alpha = int(40 + intensity * 100)

            pygame.draw.line(
                heat_surf, (r, g, b, alpha),
                (int(from_pos[0]), int(from_pos[1])),
                (int(to_pos[0]), int(to_pos[1])),
                6
            )

        screen.blit(heat_surf, (0, 0))


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

renderer = Renderer()
