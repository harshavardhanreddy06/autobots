"""
visualization/__init__.py

PURPOSE:
    Marks the 'visualization' directory as a Python package.
    Contains the renderer (map + vehicles) and UI panels (metrics).
    Depends on core/, brain/, and vehicle/ but is never imported by them —
    visualization is a pure leaf layer (no other module imports from here).
"""
