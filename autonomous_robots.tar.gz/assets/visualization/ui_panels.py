"""
visualization/ui_panels.py — Right-Side Metrics Dashboard

PURPOSE:
    Draws the metrics panel on the right side of the screen (width = METRIC_PANEL_W).
    Shows a comprehensive, real-time view of the system state in 8 sections:

    Section 1: Header — System title, tick, speed multiplier
    Section 2: Safety Banner — SAFE (green) or COLLISION DETECTED (red)
    Section 3: Fleet Status — bar chart of vehicle state distribution
    Section 4: Task Counters — pending, assigned, completed, failed, expired
    Section 5: Resolution Histogram — bar chart L1–L6 usage counts
    Section 6: Performance — throughput/min, avg task time, utilisation %
    Section 7: Brain Log — last N decision log entries (ring buffer display)
    Section 8: Key Hints — keyboard shortcuts

DESIGN:
    Uses pygame.draw (no external libraries).
    Dark panel with gradient section headers.
    Color-coded text: green = good, red = bad, white = info, yellow = warning.
"""

from __future__ import annotations
import pygame
from config import (METRIC_PANEL_W, WINDOW_W, PANEL_BG, WHITE,
                    COLOR_IDLE, COLOR_WAITING_FOR_START, COLOR_MOVING_TO_PICKUP,
                    COLOR_MOVING_TO_DEST, COLOR_MOVING_TO_PARKING,
                    COLOR_PARKED, COLOR_FAILED, COLOR_REPAIRING)
from brain.metrics_tracker import metrics
from brain.brain_logger import get_brain_log


# Colors
GREEN  = (0, 220, 100)
RED    = (255, 60, 60)
YELLOW = (255, 220, 0)
CYAN   = (0, 220, 220)
ORANGE = (255, 140, 0)
GREY   = (120, 120, 120)
PURPLE = (160, 32, 240)
DARK_PANEL = (22, 22, 30)
SECTION_BG = (35, 35, 48)


def _init_fonts():
    """Initialize fonts. Called once."""
    try:
        f_title = pygame.font.SysFont("Arial", 18, bold=True)
        f_big   = pygame.font.SysFont("Arial", 22, bold=True)
        f_mid   = pygame.font.SysFont("Arial", 14)
        f_small = pygame.font.SysFont("Arial", 12)
        f_tiny  = pygame.font.SysFont("Arial", 10)
    except Exception:
        f_title = f_big = f_mid = f_small = f_tiny = pygame.font.Font(None, 16)
    return f_title, f_big, f_mid, f_small, f_tiny


_fonts = None


class UIPanel:
    """
    Right-side metrics dashboard. Stateless drawing — reads from singletons.
    """

    def __init__(self):
        self._panel_x: int = 0   # set by draw()

    def draw(self, screen: pygame.Surface, map_w: int, map_h: int,
             current_tick: int, sim_speed: float, paused: bool) -> None:
        """
        Draw the full metrics panel.

        Args:
            screen:       pygame display surface
            map_w:        width of map area (panel starts here)
            map_h:        total screen height
            current_tick: current simulation tick
            sim_speed:    current speed multiplier
            paused:       whether simulation is paused
        """
        global _fonts
        if _fonts is None:
            _fonts = _init_fonts()

        f_title, f_big, f_mid, f_small, f_tiny = _fonts
        px = map_w   # panel left edge
        self._panel_x = px

        # Panel background
        pygame.draw.rect(screen, DARK_PANEL, (px, 0, METRIC_PANEL_W, map_h))
        pygame.draw.line(screen, (60, 60, 80), (px, 0), (px, map_h), 2)

        y = 10
        W = METRIC_PANEL_W - 16  # usable width inside panel

        # ── Section 1: Header ─────────────────────────────
        y = self._section_header(screen, px + 8, y, "⚡ CENTRAL BRAIN", f_big, W)

        sub = f"Tick: {current_tick:,}   Speed: {sim_speed:.1f}x"
        if paused:
            sub += "  [PAUSED]"
        self._text(screen, px + 8, y, sub, f_small, YELLOW)
        y += 20

        # ── Section 2: Safety Banner ──────────────────────
        y += 6
        confirmed = metrics.confirmed_collisions
        if confirmed == 0:
            banner_col = (0, 80, 0)
            txt_col    = GREEN
            banner_txt = "✓  ZERO COLLISIONS CONFIRMED"
        else:
            banner_col = (100, 0, 0)
            txt_col    = RED
            banner_txt = f"⚠  COLLISIONS: {confirmed}"

        pygame.draw.rect(screen, banner_col, (px + 6, y, W + 4, 22), border_radius=4)
        surf = f_small.render(banner_txt, True, txt_col)
        screen.blit(surf, (px + 8, y + 3))
        y += 30

        # ── Section 3: Fleet Status ───────────────────────
        y = self._section_header(screen, px + 8, y, "Fleet Status", f_title, W)

        state_data = [
            ("IDLE",     metrics.vehicles_idle,        COLOR_IDLE),
            ("WAITING",  metrics.vehicles_waiting,     COLOR_WAITING_FOR_START),
            ("→PICKUP",  metrics.vehicles_to_pickup,   COLOR_MOVING_TO_PICKUP),
            ("→DEST",    metrics.vehicles_to_dest,     COLOR_MOVING_TO_DEST),
            ("→PARK",    metrics.vehicles_to_parking,  COLOR_MOVING_TO_PARKING),
            ("PARKED",   metrics.vehicles_parked,      COLOR_PARKED),
            ("FAILED",   metrics.vehicles_failed,      COLOR_FAILED),
            ("REPAIR",   metrics.vehicles_repairing,   COLOR_REPAIRING),
        ]
        total_v = max(1, sum(v for _, v, _ in state_data))

        for label, count, color in state_data:
            bar_w = int((count / total_v) * (W - 70))
            pygame.draw.rect(screen, color, (px + 70, y + 1, max(2, bar_w), 10), border_radius=2)
            self._text(screen, px + 8, y, f"{label}", f_tiny, GREY)
            self._text(screen, px + 52, y, f"{count}", f_tiny, WHITE)
            y += 13

        util_pct = int(metrics.fleet_utilisation * 100)
        self._text(screen, px + 8, y, f"Utilisation: {util_pct}%", f_small,
                   GREEN if util_pct > 60 else YELLOW)
        y += 18

        # ── Section 4: Task Counters ──────────────────
        y = self._section_header(screen, px + 8, y, "Tasks", f_title, W)

        from brain.task_manager import task_mgr as _task_mgr
        from core.models import TaskState

        # Count every live task state directly from task_mgr
        _pending    = 0
        _assigned   = 0
        _in_transit = 0
        for t in _task_mgr.all_tasks():
            if   t.state == TaskState.PENDING:              _pending    += 1
            elif t.state == TaskState.ASSIGNED:             _assigned   += 1
            elif t.state in (TaskState.MOVING_TO_PICKUP,
                             TaskState.MOVING_TO_DESTINATION): _in_transit += 1

        task_rows = [
            ("Generated",  metrics.tasks_generated,   WHITE),
            ("Pending",    _pending,                   YELLOW if _pending > 0 else WHITE),
            ("Assigned",   _assigned,                  CYAN   if _assigned > 0 else WHITE),
            ("In-Transit", _in_transit,                (150, 220, 255) if _in_transit > 0 else WHITE),
            ("Completed",  metrics.tasks_completed,    GREEN),
            ("Failed",     metrics.tasks_failed,       RED    if metrics.tasks_failed > 0 else GREY),
            ("Expired",    metrics.tasks_expired,      ORANGE if metrics.tasks_expired > 0 else GREY),
            ("Reassigned", metrics.tasks_reassigned,   CYAN),
        ]
        for label, val, col in task_rows:
            self._text(screen, px + 8, y, f"{label}:", f_tiny, GREY)
            self._text(screen, px + 105, y, str(val), f_tiny, col)
            y += 13

        # ── Section 5: Resolution Histogram ───────────────
        y = self._section_header(screen, px + 8, y, "Resolution", f_title, W)

        levels = [
            ("L1 Departure",  metrics.level_1_departures, (100, 200, 255)),
            ("L2 Speed",      metrics.level_2_speed,      (100, 255, 180)),
            ("L3 Propagation",metrics.level_3_propagation,(200, 255, 100)),
            ("L4 Optimizer",  metrics.level_4_optimiser,  (255, 220, 60)),
            ("L5 Reroute",    metrics.level_5_reroutes,   (255, 140, 60)),
            ("L6 Emergency",  metrics.level_6_emergency,  (255, 60, 60)),
        ]
        max_level = max((v for _, v, _ in levels), default=1) or 1

        for label, val, col in levels:
            bar_w = int((val / max_level) * (W - 80))
            pygame.draw.rect(screen, col, (px + 80, y + 1, max(2, bar_w), 8), border_radius=2)
            self._text(screen, px + 8, y, label, f_tiny, GREY)
            self._text(screen, px + 62, y, str(val), f_tiny, WHITE)
            y += 12

        # ── Section 6: Performance ────────────────────────
        y = self._section_header(screen, px + 8, y, "Performance", f_title, W)

        perf_rows = [
            ("Throughput/min", f"{metrics.throughput_per_min:.1f}", GREEN),
            ("Avg task ticks", f"{metrics.avg_task_time:.0f}", WHITE),
            ("Predicted conf.", str(metrics.predicted_collisions), YELLOW),
            ("Prevented conf.", str(metrics.prevented_collisions), GREEN),
            ("Deadlocks",       str(metrics.deadlocks_detected), ORANGE),
            ("Failures",        str(metrics.failures), RED if metrics.failures > 0 else GREY),
        ]
        for label, val, col in perf_rows:
            self._text(screen, px + 8, y, f"{label}:", f_tiny, GREY)
            self._text(screen, px + 118, y, val, f_tiny, col)
            y += 13

        # ── Section 6b: ML Model Status ───────────────────
        y = self._section_header(screen, px + 8, y, "ML Models", f_title, W)

        try:
            from brain.ml.allocator_model import ml_allocator
            alloc_ready   = ml_allocator.is_ready()
            alloc_samples = ml_allocator.sample_count
            alloc_trains  = ml_allocator.train_count
            alloc_mae     = ml_allocator.last_mae
        except Exception:
            alloc_ready = False
            alloc_samples = alloc_trains = 0
            alloc_mae = 0.0

        try:
            from brain.ml.speed_model import ml_speed
            speed_ready   = ml_speed.is_ready()
            speed_samples = ml_speed.sample_count
            speed_trains  = ml_speed.train_count
            speed_loss    = ml_speed.last_loss
        except Exception:
            speed_ready = False
            speed_samples = speed_trains = 0
            speed_loss = 0.0

        # Allocator row
        alloc_status = "✓ ACTIVE" if alloc_ready else f"Collecting ({alloc_samples}/50)"
        alloc_col    = GREEN if alloc_ready else YELLOW
        self._text(screen, px + 8, y, "Allocator:", f_tiny, GREY)
        self._text(screen, px + 75, y, alloc_status, f_tiny, alloc_col)
        y += 13
        if alloc_ready:
            self._text(screen, px + 8, y, f"  Trains:{alloc_trains}  MAE:{alloc_mae:.0f}t", f_tiny, CYAN)
            y += 13

        # Speed model row
        speed_status = "✓ ACTIVE" if speed_ready else f"Collecting ({speed_samples}/100)"
        speed_col    = GREEN if speed_ready else YELLOW
        self._text(screen, px + 8, y, "Speed MLP:", f_tiny, GREY)
        self._text(screen, px + 75, y, speed_status, f_tiny, speed_col)
        y += 13
        if speed_ready:
            self._text(screen, px + 8, y, f"  Trains:{speed_trains}  Loss:{speed_loss:.4f}", f_tiny, CYAN)
            y += 13


        # ── Section 7: Brain Log ──────────────────────────
        y = self._section_header(screen, px + 8, y, "Brain Log", f_title, W)

        log_entries = get_brain_log()
        # Show newest last, max 8 lines
        shown = log_entries[-8:]
        for i, entry in enumerate(shown):
            alpha = 150 + int(105 * i / max(1, len(shown) - 1))
            col = (alpha, alpha, alpha)
            # Truncate to fit panel
            txt = entry[:34] + "…" if len(entry) > 35 else entry
            self._text(screen, px + 8, y, txt, f_tiny, col)
            y += 12

        # ── Section 8: Key Hints ──────────────────────────
        y = max(y + 5, map_h - 95)
        pygame.draw.line(screen, (50, 50, 70), (px + 6, y), (px + METRIC_PANEL_W - 6, y))
        y += 6

        hints = [
            "SPACE Pause/Resume",
            "B     Add Bot (max 20)",
            "T     Force Task",
            "H     Heatmap",
            "F     Fail vehicle",
            "+/-   Speed",
            "F11   Fullscreen",
            "ESC   Quit",
        ]
        for hint in hints:
            self._text(screen, px + 8, y, hint, f_tiny, GREY)
            y += 13

    # ─── Helpers ──────────────────────────────────────────

    def _section_header(self, screen, x, y, title, font, w) -> int:
        """Draw a section header bar and return new y position."""
        pygame.draw.rect(screen, SECTION_BG, (x - 2, y, w + 4, 18), border_radius=3)
        surf = font.render(title, True, (180, 200, 255))
        screen.blit(surf, (x + 4, y + 1))
        return y + 22

    def _text(self, screen, x, y, text, font, color):
        """Render text at position."""
        surf = font.render(str(text), True, color)
        screen.blit(surf, (x, y))

    def pending_count(self) -> int:
        """Helper: returns pending task count for layout decisions."""
        from brain.task_manager import task_mgr
        return task_mgr.pending_count()


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

ui_panel = UIPanel()
