"""
web_main.py — Pygbag-Compatible Async Entry Point

PURPOSE:
    Pygbag (pygame → WebAssembly) requires the main game loop to use
    `async def main()` with `await asyncio.sleep(0)` at the end of each
    frame. This file is the web-compatible version of main.py.

    Run locally:  python -m pygbag web_main.py
    Produces:     build/web/  folder → deploy to GitHub Pages

DIFFERENCES FROM main.py:
    1. `async def main()` instead of `def main()`
    2. `await asyncio.sleep(0)` at end of each frame (yields to browser)
    3. XGBoost disabled (not available in WASM — Speed MLP still works)
    4. No F11 fullscreen (browser controls fullscreen in WASM)

DEPLOY STEPS:
    python -m pygbag --width 1330 --height 982 --template noctx.tmpl web_main.py
    # Open http://localhost:8000 to test locally
    # Then copy build/web/ to GitHub Pages
"""

import asyncio
import json
import os
import sys
import random
import pygame
import math

# ── Disable XGBoost in web — numpy ML still works ────────
os.environ["AUTONOMOUS_ROBOTS_NO_XGBOOST"] = "1"

import config
from config import (
    WINDOW_W, WINDOW_H, METRIC_PANEL_W, FPS,
    VEHICLE_COUNT, VEHICLE_MAX,
    KEY_QUIT, KEY_HEATMAP, KEY_FAIL_VEHICLE,
    KEY_SPEED_UP, KEY_SPEED_DOWN, KEY_PAUSE, KEY_ADD_BOT,
    COLLISION_RADIUS,
)
from core.models import VehicleRecord, VehicleState, ParkingSlot
from core.event_bus import bus
from brain.road_graph import graph
from brain.speed_coordinator import speed_coordinator
from brain.task_generator import task_gen
from brain.parking_manager import parking_mgr
from brain.metrics_tracker import metrics
from brain.central_brain import brain
from brain.failure_manager import failure_mgr
from vehicle.vehicle_registry import registry
from vehicle.vehicle import Vehicle
from visualization.renderer import renderer
from visualization.ui_panels import ui_panel
from visualization.button_bar import (
    button_bar,
    ACT_PAUSE, ACT_SPEED_UP, ACT_SPEED_DOWN,
    ACT_ADD_BOT, ACT_FORCE_TASK, ACT_HEATMAP, ACT_FAIL_BOT,
    ACT_TEST_1, ACT_TEST_2, ACT_TEST_3,
)


def load_map(path):
    with open(path) as f:
        return json.load(f)

def build_geometry(map_data):
    roads = map_data["roads"]
    vertical_x   = roads["vertical_roads_px"]
    horizontal_y = roads["horizontal_roads_px"]
    intersections = [(i["x_px"], i["y_px"]) for i in map_data["intersections"]]
    pickups  = [(s["x_px"], s["y_px"], f"{s['grid_col']}_{s['grid_row']}")
                for s in map_data["stations"]["pickups"]]
    drops    = [(s["x_px"], s["y_px"], f"{s['grid_col']}_{s['grid_row']}")
                for s in map_data["stations"]["drops"]]
    parking_zones = [pygame.Rect(z["x_px"], z["y_px"], z["width_px"], z["height_px"])
                     for z in map_data["parking_zones"]]
    parking_gates = [(pygame.Rect(g["x_px"], g["y_px"], g["width_px"], g["height_px"]), g["type"])
                     for g in map_data["parking_gates"]]
    map_w = map_data["screen"]["width_px"] - map_data["screen"]["metric_panel_width_px"]
    map_h = map_data["screen"]["height_px"]
    return dict(vertical_x=vertical_x, horizontal_y=horizontal_y,
                intersections=intersections, pickups=pickups, drops=drops,
                parking_zones=parking_zones, parking_gates=parking_gates,
                map_w=map_w, map_h=map_h)

def make_parking_slots(map_data):
    node_map = {f"{i['col']}_{i['row']}": (i["x_px"], i["y_px"])
                for i in map_data["intersections"]}
    slots = []
    for nid in ["2_2", "2_3", "3_2", "3_3", "4_3", "4_4", "5_3", "5_4"]:
        if nid in node_map:
            slots.append(ParkingSlot(node_id=nid, zone_id=0,
                                     center_px=node_map[nid], occupied_by=None))
    return slots

def spawn_vehicles(map_data, count):
    node_map = {f"{i['col']}_{i['row']}": (i["x_px"], i["y_px"])
                for i in map_data["intersections"]}
    candidate_nodes = list(node_map.keys())
    random.shuffle(candidate_nodes)
    vehicles = []
    for i in range(min(count, len(candidate_nodes))):
        vid = f"V{i}"
        nid = candidate_nodes[i]
        px, py = node_map[nid]
        record = VehicleRecord(
            vehicle_id=vid, state=VehicleState.IDLE,
            x_px=float(px), y_px=float(py), node_id=nid,
        )
        registry.register(record)
        vehicles.append(Vehicle(vid))
    return vehicles

def spawn_one_vehicle(map_data, vehicles):
    if len(vehicles) >= VEHICLE_MAX:
        print(f"[main] Fleet at max ({VEHICLE_MAX}). Cannot add more bots.")
        return
    node_map = {f"{i['col']}_{i['row']}": (i["x_px"], i["y_px"])
                for i in map_data["intersections"]}
    used = {r.node_id for r in registry.snapshot()}
    free = [nid for nid in node_map if nid not in used]
    if not free:
        return
    nid = random.choice(free)
    px, py = node_map[nid]
    vid = f"V{len(vehicles)}"
    record = VehicleRecord(
        vehicle_id=vid, state=VehicleState.IDLE,
        x_px=float(px), y_px=float(py), node_id=nid,
    )
    registry.register(record)
    vehicles.append(Vehicle(vid))
    print(f"[main] Bot {vid} spawned at {nid} (fleet size: {len(vehicles)}/{VEHICLE_MAX})")

def check_physical_collisions():
    active_states = {VehicleState.MOVING_TO_PICKUP, VehicleState.MOVING_TO_DEST,
                     VehicleState.MOVING_TO_PARKING}
    active = [r for r in registry.snapshot() if r.state in active_states]
    for i in range(len(active)):
        for j in range(i+1, len(active)):
            a, b = active[i], active[j]
            if math.hypot(a.x_px - b.x_px, a.y_px - b.y_px) < COLLISION_RADIUS:
                metrics.confirmed_collisions += 1


async def main():
    pygame.init()
    pygame.font.init()
    screen = pygame.display.set_mode((WINDOW_W, WINDOW_H))
    pygame.display.set_caption("🤖 Autonomous Robot Space-Time Scheduler")
    clock = pygame.time.Clock()

    here     = os.path.dirname(os.path.abspath(__file__))
    map_data = load_map(os.path.join(here, "map_config.json"))
    geo      = build_geometry(map_data)

    graph.build(map_data["intersections"])
    all_station_px = ([(s["x_px"], s["y_px"]) for s in map_data["stations"]["pickups"]] +
                      [(s["x_px"], s["y_px"]) for s in map_data["stations"]["drops"]])
    speed_coordinator.set_stations(all_station_px)

    pickup_data = [{"node_id": f"{s['grid_col']}_{s['grid_row']}",
                    "x_px": s["x_px"], "y_px": s["y_px"]}
                   for s in map_data["stations"]["pickups"]]
    drop_data   = [{"node_id": f"{s['grid_col']}_{s['grid_row']}",
                    "x_px": s["x_px"], "y_px": s["y_px"]}
                   for s in map_data["stations"]["drops"]]
    task_gen.set_stations(pickup_data, drop_data)
    parking_mgr.set_slots(make_parking_slots(map_data))

    renderer.setup(
        vertical_x    = geo["vertical_x"],
        horizontal_y  = geo["horizontal_y"],
        intersections = geo["intersections"],
        pickups       = geo["pickups"],
        drops         = geo["drops"],
        parking_zones = geo["parking_zones"],
        parking_gates = geo["parking_gates"],
        map_w         = geo["map_w"],
        map_h         = geo["map_h"],
    )

    # Start with empty map for Free Roam until they click START
    vehicles  = []
    tick      = 0
    paused    = True
    sim_speed = 1.0
    speed_acc = 0.0
    running   = True
    map_w     = geo["map_w"]
    map_h     = geo["map_h"]
    
    current_mode = "FREE_ROAM"
    dispatched   = False
    transitioning = False
    transition_timer = 0
    node_map = {f"{i['col']}_{i['row']}": (i["x_px"], i["y_px"]) for i in map_data["intersections"]}

    while running:
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == KEY_QUIT:
                    running = False
                elif event.key == KEY_HEATMAP:
                    renderer.show_heatmap = not renderer.show_heatmap
                elif event.key == pygame.K_r:
                    renderer.show_routes = not renderer.show_routes
                elif event.key == KEY_PAUSE:
                    paused = not paused
                elif event.key == KEY_FAIL_VEHICLE:
                    failure_mgr.trigger_random(tick)
                elif event.key == KEY_ADD_BOT:
                    spawn_one_vehicle(map_data, vehicles)
                elif event.key in (KEY_SPEED_UP, pygame.K_EQUALS):
                    sim_speed = min(8.0, sim_speed + 0.5)
                elif event.key == KEY_SPEED_DOWN:
                    sim_speed = max(0.25, sim_speed - 0.25)
                elif event.key == pygame.K_t:
                    task_gen.force_generate(tick)

            btn_actions = button_bar.handle_event(event, map_w, map_h)
            for act in btn_actions:
                if act == ACT_PAUSE:
                    if current_mode != "FREE_ROAM" or (current_mode == "FREE_ROAM" and tick == 0):
                        # Start Main Project with 2s delay
                        from test_runner import reset_simulation_state
                        reset_simulation_state()
                        vehicles = []
                        current_mode = "FREE_ROAM"
                        paused = True
                        transitioning = True
                        transition_timer = pygame.time.get_ticks() + 2000
                        dispatched = False
                    else:
                        paused = not paused
                elif act == ACT_SPEED_UP:
                    sim_speed = min(8.0, sim_speed + 0.5)
                elif act == ACT_SPEED_DOWN:
                    sim_speed = max(0.25, sim_speed - 0.25)
                elif act == ACT_ADD_BOT:
                    spawn_one_vehicle(map_data, vehicles)
                elif act == ACT_FORCE_TASK:
                    task_gen.force_generate(tick)
                elif act == ACT_HEATMAP:
                    renderer.show_heatmap = not renderer.show_heatmap
                elif act == ACT_FAIL_BOT:
                    failure_mgr.trigger_random(tick)
                elif act in [ACT_TEST_1, ACT_TEST_2, ACT_TEST_3]:
                    from test_runner import reset_simulation_state
                    test_num = 1 if act == ACT_TEST_1 else 2 if act == ACT_TEST_2 else 3
                    
                    reset_simulation_state()
                    vehicles = []
                    current_mode = f"TEST_{test_num}"
                    paused = True
                    transitioning = True
                    transition_timer = pygame.time.get_ticks() + 2000
                    dispatched = False

        if transitioning:
            if pygame.time.get_ticks() >= transition_timer:
                transitioning = False
                tick = 0
                paused = False
                if current_mode == "FREE_ROAM":
                    vehicles = spawn_vehicles(map_data, VEHICLE_COUNT)
                else:
                    from test_runner import spawn_bots, TESTS
                    test_num = int(current_mode.split('_')[1])
                    name, desc, bot_cfgs = TESTS[test_num]
                    vehicles = spawn_bots(bot_cfgs, node_map)

        if not paused and not transitioning:
            speed_acc += sim_speed
            steps = int(speed_acc)
            speed_acc -= steps
            for _ in range(steps):
                tick += 1
                
                if current_mode == "FREE_ROAM":
                    brain.tick(tick)
                else:
                    from test_runner import dispatch_bots, TESTS
                    if tick == 30 and not dispatched:
                        dispatched = True
                        test_num = int(current_mode.split('_')[1])
                        _, _, bot_cfgs = TESTS[test_num]
                        dispatch_bots(bot_cfgs, tick)
                    
                    parking_mgr.update(tick)
                    from brain.reservation_manager import reservations
                    if tick % 60 == 0:
                        reservations.gc(tick)
                
                for v in vehicles:
                    v.tick(tick)
                check_physical_collisions()

        screen.fill((20, 20, 20))
        renderer.draw(screen, tick)
        pygame.draw.rect(screen, (40, 40, 55), (map_w, 0, METRIC_PANEL_W, map_h))
        ui_panel.draw(screen, map_w, map_h, tick, sim_speed, paused)
        
        # Update button label before drawing
        if current_mode != "FREE_ROAM" or (current_mode == "FREE_ROAM" and tick == 0):
            button_bar._buttons[0].label = "▶ START"
        else:
            button_bar._buttons[0].label = "▶ RESUME" if paused else "⏸ PAUSE"
            
        button_bar.draw(screen, map_w, map_h, paused, sim_speed, tick)
        pygame.display.flip()

        # ← Required by Pygbag: yield control to browser each frame
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())
