"""
brain/lane_propagation.py — Level 3 Conflict Resolution: Cascade Speed Reduction

PURPOSE:
    When a vehicle slows down (due to speed coordination), the vehicles
    behind it on the same road segment must also slow down to prevent
    rear-end conflicts. This module propagates the speed change backward
    along the route up to PROPAGATION_MAX_HOPS followers.

HOW IT WORKS:
    1. Given a vehicle V whose speed was just reduced on segment S
    2. Find all vehicles whose schedule has S as an upcoming segment
       AND who will enter S BEFORE vehicle V exits S (i.e., followers)
    3. For each follower F:
        a. Check if F's schedule conflicts with V's new (slower) schedule
        b. If yes, rebuild F's schedule with a reduced speed multiplier
           (PROPAGATION_FACTOR applied to each segment)
        c. Release F's old reservations, commit new schedule
        d. Recurse: F's followers may also need adjustment
    4. Stop after PROPAGATION_MAX_HOPS recursion depth

WHY LIMIT TO 3 HOPS:
    Without a hop limit, a speed change at one node could cascade
    across the entire network — every vehicle slows down. The limit
    keeps the effect local while preventing the most immediate conflicts.

ATOMICITY:
    All schedule updates in a propagation cascade are collected first,
    then committed together. This prevents a follower's new schedule
    from conflicting with another follower's old schedule during the update.
"""

from __future__ import annotations
from config import PROPAGATION_FACTOR, PROPAGATION_MAX_HOPS, MIN_SPEED_MULT
from brain.schedule_builder import schedule_builder
from brain.reservation_manager import reservations
from brain.collision_predictor import collision_pred
from vehicle.vehicle_registry import registry
from core.models import VehicleState


class LanePropagation:
    """
    Cascade speed reduction for vehicles following a slower vehicle.

    Implements Level 3 of the conflict resolution hierarchy.
    Called by the Decision Engine after Speed Coordination (Level 2).
    """

    def propagate(self, trigger_vehicle_id: str, trigger_schedule: list,
                  depth: int = 0) -> int:
        """
        Propagate a speed reduction from the trigger vehicle to its followers.

        Args:
            trigger_vehicle_id: the vehicle whose schedule just changed (slower)
            trigger_schedule:   the trigger vehicle's new schedule
            depth:              current recursion depth (stops at PROPAGATION_MAX_HOPS)

        Returns:
            Number of vehicles whose schedules were updated
        """
        if depth >= PROPAGATION_MAX_HOPS:
            return 0
        if not trigger_schedule:
            return 0

        updated = 0
        all_records = registry.snapshot()

        # Find followers on each segment of the trigger vehicle's route
        followers_found: set = set()
        for entry in trigger_schedule:
            for rec in all_records:
                if rec.vehicle_id == trigger_vehicle_id:
                    continue
                if rec.vehicle_id in followers_found:
                    continue
                if rec.state not in (VehicleState.MOVING_TO_PICKUP,
                                     VehicleState.MOVING_TO_DEST,
                                     VehicleState.WAITING_FOR_START):
                    continue
                if not rec.instruction or not rec.instruction.schedule:
                    continue

                # Check if this follower uses the same segment
                for f_entry in rec.instruction.schedule:
                    if f_entry.segment_id == entry.segment_id:
                        # Check for conflict with trigger's new schedule
                        if f_entry.enter_tick < entry.exit_tick and \
                           f_entry.exit_tick > entry.enter_tick:
                            followers_found.add(rec.vehicle_id)
                        break

        # Update each follower's schedule
        for follower_id in followers_found:
            rec = registry.get(follower_id)
            if not rec or not rec.instruction or not rec.instruction.schedule:
                continue

            old_schedule = rec.instruction.schedule

            # Extract the route from the remaining schedule
            remaining_route = [old_schedule[0].from_node] + \
                              [e.to_node for e in old_schedule]

            # Apply PROPAGATION_FACTOR to each segment's speed
            # We approximate: rebuild with reduced-speed profile
            reduced_mult = PROPAGATION_FACTOR
            reduced_profile = [
                max(MIN_SPEED_MULT, reduced_mult)
            ] * (len(remaining_route) - 1)

            # Build new schedule from the follower's current start tick
            start = old_schedule[0].enter_tick
            new_schedule = schedule_builder.build(remaining_route, start, reduced_profile)

            # Check if new schedule still conflicts
            if collision_pred.has_conflict(new_schedule, exclude_vid=follower_id):
                continue  # can't resolve this follower — skip (will escalate above)

            # Commit: release old, commit new
            reservations.release(follower_id)
            if reservations.commit(follower_id, new_schedule):
                # Update instruction in registry with new schedule
                new_version = registry.increment_version(follower_id)
                from core.models import VehicleInstruction
                new_instr = VehicleInstruction(
                    vehicle_id       = follower_id,
                    schedule         = new_schedule,
                    schedule_version = new_version,
                    task_id          = rec.task_id,
                    destination_type = rec.instruction.destination_type,
                    start_tick       = new_schedule[0].enter_tick if new_schedule else start,
                    end_node         = rec.instruction.end_node
                )
                registry.update(follower_id, instruction=new_instr)
                updated += 1

                # Recurse: this follower's followers may need adjustment
                updated += self.propagate(follower_id, new_schedule, depth + 1)

        return updated


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

lane_propagation = LanePropagation()
