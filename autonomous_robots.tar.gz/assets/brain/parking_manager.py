"""
brain/parking_manager.py — Strategic Parking Assignment

PURPOSE:
    Decides where idle vehicles should park, when to recall parked vehicles
    for new tasks, and manages the grace period before parking is enforced.

PARKING STRATEGY:
    After a delivery, the vehicle enters a GRACE PERIOD. During this period
    (PARKING_GRACE_TICKS or adaptive based on task queue):

        If a new task arrives during grace period → Path A or B
            (task_allocator assigns immediately — no parking command issued)

        If no task arrives AND queue is empty → send to parking
        If queue is non-empty → reduce grace period to 0 (park immediately
            but only if another vehicle is closer to pickup)

SLOT SELECTION:
    Parking slots are pre-defined intersection nodes adjacent to parking zones.
    Selection priority:
        1. Nearest available slot to vehicle's current position
        2. Weighted by zone demand (more tasks near zone 2 → prefer zone 2 slots)
        3. Strategic: if vehicle is positioned to cover future pickups, prefer
           the zone closest to the demand centroid of pending tasks

RECALL:
    When a vehicle is PARKED and the task queue grows, the allocator may
    select it for a task (PARKED state is eligible). The parking manager
    then frees the slot.
"""

from __future__ import annotations
import math
from typing import Optional
from config import PARKING_GRACE_TICKS
from core.models import VehicleState, ParkingSlot
from brain.brain_logger import brain_log
from vehicle.vehicle_registry import registry


class ParkingManager:
    """
    Manages parking slot assignment and vehicle parking lifecycle.
    """

    def __init__(self):
        # Parking slots: list of ParkingSlot dataclasses
        # Populated by main.py after map loading
        self._slots: list = []

        # vehicle_id → ParkingSlot (currently assigned slot, awaiting arrival)
        self._assigned: dict = {}

    def set_slots(self, slots: list) -> None:
        """
        Initialize parking slots. Called once from main.py after map load.

        Args:
            slots: list of ParkingSlot objects
        """
        self._slots = slots

    # ─── Grace Period Management ──────────────────────────

    def start_grace(self, vehicle_id: str, current_tick: int) -> None:
        """
        Start the parking grace period for a vehicle that just completed delivery.

        The vehicle stays at its current position for PARKING_GRACE_TICKS.
        If no task is assigned during this window, send_to_parking is called.

        Args:
            vehicle_id:   vehicle that just completed delivery
            current_tick: current simulation tick
        """
        registry.update(vehicle_id, grace_since=current_tick)
        brain_log(f"{vehicle_id} grace started @{current_tick}")

    def update(self, current_tick: int) -> None:
        """
        Check all vehicles with active grace periods.
        If grace expired and no task assigned → send to parking.

        Called every tick from central_brain.tick().

        Args:
            current_tick: current simulation tick
        """
        from brain.task_manager import task_mgr

        all_records = registry.snapshot()
        for rec in all_records:
            if rec.grace_since < 0:
                continue   # not in grace period
            if rec.state != VehicleState.IDLE:
                registry.update(rec.vehicle_id, grace_since=-1)
                continue   # task was assigned — cancel grace

            grace_duration = current_tick - rec.grace_since
            pending_count = task_mgr.pending_count()

            # Adaptive grace: if tasks are waiting, reduce grace period
            effective_grace = PARKING_GRACE_TICKS
            if pending_count > 0:
                effective_grace = max(5, PARKING_GRACE_TICKS // 3)

            if grace_duration >= effective_grace:
                # Grace expired — send to parking
                registry.update(rec.vehicle_id, grace_since=-1)
                self.assign_slot(rec.vehicle_id, current_tick)

    # ─── Slot Assignment ──────────────────────────────────

    def assign_slot(self, vehicle_id: str, current_tick: int) -> Optional[str]:
        """
        Find the best available parking slot and assign the vehicle to it.

        Selection: nearest available slot to vehicle's current position.

        Args:
            vehicle_id:   vehicle to park
            current_tick: current simulation tick

        Returns:
            node_id of the assigned slot, or None if all slots full
        """
        rec = registry.get(vehicle_id)
        if not rec:
            return None

        # Find nearest available slot
        available = [s for s in self._slots if s.occupied_by is None]
        if not available:
            brain_log(f"{vehicle_id} no parking slots available!")
            return None

        # Sort by distance from vehicle's current position
        available.sort(key=lambda s: math.hypot(
            rec.x_px - s.center_px[0],
            rec.y_px - s.center_px[1]
        ))

        slot = available[0]
        slot.occupied_by = vehicle_id
        self._assigned[vehicle_id] = slot

        brain_log(f"{vehicle_id} → parking slot {slot.node_id}")
        return slot.node_id

    def free_slot(self, vehicle_id: str) -> None:
        """
        Free the parking slot occupied by this vehicle.
        Called when vehicle is recalled for a task or fails.

        Args:
            vehicle_id: vehicle vacating its slot
        """
        # Check assigned dict
        slot = self._assigned.pop(vehicle_id, None)
        if slot:
            slot.occupied_by = None
            return

        # Fallback: search slots
        for s in self._slots:
            if s.occupied_by == vehicle_id:
                s.occupied_by = None
                break

    def get_demand_centroid(self, pending_tasks: list) -> tuple:
        """
        Compute the centroid (average position) of all pending task pickups.

        Used for strategic parking: park vehicles near the centroid to
        minimise average response time to future tasks.

        Args:
            pending_tasks: list of Task objects in PENDING state

        Returns:
            (x_px, y_px) centroid, or (0, 0) if no pending tasks
        """
        if not pending_tasks:
            return (0, 0)
        cx = sum(t.pickup_px[0] for t in pending_tasks) / len(pending_tasks)
        cy = sum(t.pickup_px[1] for t in pending_tasks) / len(pending_tasks)
        return (cx, cy)

    def get_slots_snapshot(self) -> list:
        """Return all parking slots for rendering."""
        return list(self._slots)

    def occupied_nodes(self) -> set:
        """Return set of node_ids currently occupied by parked vehicles."""
        return {s.node_id for s in self._slots if s.occupied_by is not None}


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

parking_mgr = ParkingManager()
