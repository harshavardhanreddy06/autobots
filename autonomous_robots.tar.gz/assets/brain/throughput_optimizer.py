"""
brain/throughput_optimizer.py — Level 4 Conflict Resolution & Periodic Optimization

PURPOSE:
    Globally reviews all current vehicle schedules and attempts to improve
    throughput by detecting inefficient schedule patterns and reshuffling
    them for better overall fleet performance.

WHEN IT RUNS:
    1. Event-driven: when a conflict cannot be resolved at L1-L3
    2. Periodic: every OPTIMIZER_INTERVAL ticks unconditionally

WHAT IT DOES:
    1. Find WAITING_FOR_START vehicles with large departure delays
       → Try to find them an earlier departure slot
    2. Find IDLE vehicles near pending task pickups
       → Proactively pre-position them (send them toward demand centroid)
    3. Find vehicles going to parking while tasks exist
       → Interrupt and reassign to waiting task instead

SAFETY GUARD:
    Only reschedules vehicles in OPTIMIZABLE states:
        WAITING_FOR_START, IDLE, PARKED, MOVING_TO_PARKING
    Never reschedules vehicles in MOVING_TO_PICKUP or MOVING_TO_DEST
    (committed deliveries are never interrupted).
"""

from __future__ import annotations
from config import OPTIMIZER_INTERVAL
from core.models import VehicleState
from brain.brain_logger import brain_log
from brain.metrics_tracker import metrics
from vehicle.vehicle_registry import registry


# States that the optimizer is allowed to touch
OPTIMIZABLE = {
    VehicleState.WAITING_FOR_START,
    VehicleState.IDLE,
    VehicleState.PARKED,
    VehicleState.MOVING_TO_PARKING,
}


class ThroughputOptimizer:
    """
    Periodic and event-driven schedule optimization.

    Improves fleet throughput by:
        1. Reducing unnecessary wait times
        2. Interrupting parking runs when tasks exist
        3. Pre-positioning idle vehicles near demand
    """

    def __init__(self):
        self._last_run: int = 0

    def optimize(self, current_tick: int) -> int:
        """
        Run all optimization passes.

        Args:
            current_tick: current simulation tick

        Returns:
            Number of vehicles whose schedules were improved
        """
        if current_tick - self._last_run < OPTIMIZER_INTERVAL:
            return 0

        self._last_run = current_tick
        improved = 0

        improved += self._reduce_wait_times(current_tick)
        improved += self._interrupt_parking_for_tasks(current_tick)

        if improved:
            brain_log(f"Optimizer: improved {improved} schedules @{current_tick}")

        return improved

    def trigger(self, current_tick: int) -> int:
        """
        Force-run optimization immediately (Level 4 event-driven trigger).
        Called by Decision Engine when L1-L3 all fail.
        """
        self._last_run = current_tick - OPTIMIZER_INTERVAL  # Allow immediate run
        return self.optimize(current_tick)

    # ─── Optimization Passes ──────────────────────────────

    def _reduce_wait_times(self, current_tick: int) -> int:
        """
        Find WAITING_FOR_START vehicles with long departure delays.
        Try to find them an earlier departure slot.
        """
        from brain.departure_scheduler import departure_scheduler
        from brain.reservation_manager import reservations
        from brain.schedule_builder import schedule_builder
        from brain.collision_predictor import collision_pred

        improved = 0
        all_records = registry.snapshot()

        for rec in all_records:
            if rec.state != VehicleState.WAITING_FOR_START:
                continue
            if not rec.instruction or not rec.instruction.schedule:
                continue

            dep_tick = rec.instruction.schedule[0].enter_tick
            if dep_tick <= current_tick + 5:
                continue   # departure is imminent, not worth reshuffling

            # Extract route from schedule
            sched = rec.instruction.schedule
            route = [sched[0].from_node] + [e.to_node for e in sched]

            # Try earlier departure
            early_tick, new_sched = departure_scheduler.find_clean_departure(
                route=route,
                earliest_tick=current_tick,
                speed_profile=None,
                exclude_vid=rec.vehicle_id,
            )

            if early_tick and early_tick < dep_tick:
                # Found an earlier slot
                reservations.release(rec.vehicle_id)
                if reservations.commit(rec.vehicle_id, new_sched):
                    new_ver = registry.increment_version(rec.vehicle_id)
                    from core.models import VehicleInstruction
                    new_instr = VehicleInstruction(
                        vehicle_id       = rec.vehicle_id,
                        schedule         = new_sched,
                        schedule_version = new_ver,
                        task_id          = rec.task_id,
                        destination_type = rec.instruction.destination_type,
                        start_tick       = early_tick,
                        end_node         = rec.instruction.end_node,
                    )
                    registry.update(rec.vehicle_id, instruction=new_instr)
                    improved += 1

        return improved

    def _interrupt_parking_for_tasks(self, current_tick: int) -> int:
        """
        If a vehicle is heading to parking BUT tasks exist in the queue,
        signal CentralBrain to try reallocating this vehicle.

        We don't directly schedule here — just set state to IDLE
        so the allocator can pick it up in the next allocation cycle.
        """
        from brain.task_manager import task_mgr

        if task_mgr.pending_count() == 0:
            return 0

        interrupted = 0
        all_records = registry.snapshot()

        for rec in all_records:
            if rec.state != VehicleState.MOVING_TO_PARKING:
                continue

            # Interrupt parking run
            from brain.reservation_manager import reservations
            reservations.release(rec.vehicle_id)
            from brain.parking_manager import parking_mgr
            parking_mgr.free_slot(rec.vehicle_id)
            registry.update(
                rec.vehicle_id,
                state=VehicleState.IDLE,
                instruction=None,
                grace_since=-1
            )
            interrupted += 1
            brain_log(f"Optimizer: {rec.vehicle_id} parking interrupted — tasks exist")

        metrics.level_4_optimiser += interrupted
        return interrupted


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

throughput_opt = ThroughputOptimizer()
