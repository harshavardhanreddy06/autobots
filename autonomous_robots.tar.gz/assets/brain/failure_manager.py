"""
brain/failure_manager.py — Vehicle Failure and Recovery

PURPOSE:
    Handles vehicle breakdowns and recovery. When a vehicle fails, the
    system must: free its reservations, handle its current task, and
    bring it back into service after repair.

TWO FAILURE CASES:

    Case A — Failure BEFORE Pickup:
        Vehicle failed while going to pickup (no cargo).
        → Release all reservations
        → Requeue the task (state → PENDING, task reassigned to another vehicle)
        → Set vehicle state to FAILED

    Case B — Failure WHILE CARRYING CARGO:
        Vehicle failed while going to drop (cargo lost or held).
        → Release all reservations
        → Mark task as FAILED (cargo at unknown location — human intervention needed)
        → Set vehicle state to FAILED
        → Start repair timer

REPAIR:
    After REPAIR_TICKS, the vehicle returns to IDLE at its last position.
    It is then eligible for new task assignments.

TRIGGERING:
    Failures can be triggered:
        1. Automatically: probability-based (not implemented by default — set manually)
        2. Manually: user presses 'F' key → random vehicle fails
        3. System: CentralBrain detects a vehicle stuck for too long
"""

from __future__ import annotations
import random
from config import REPAIR_TICKS
from core.models import VehicleState
from core.event_bus import bus, EventType
from brain.brain_logger import brain_log
from brain.reservation_manager import reservations
from brain.metrics_tracker import metrics
from brain.task_manager import task_mgr
from vehicle.vehicle_registry import registry


class FailureManager:
    """
    Handles vehicle failure events and manages repair recovery.
    """

    def trigger(self, vehicle_id: str, current_tick: int) -> None:
        """
        Trigger a vehicle failure.

        Can be called:
            - Manually from main.py (F key press)
            - By CentralBrain on deadlock resolution (chosen victim)

        Args:
            vehicle_id:   vehicle to fail
            current_tick: current simulation tick
        """
        rec = registry.get(vehicle_id)
        if not rec:
            return
        if rec.state in (VehicleState.FAILED, VehicleState.REPAIRING):
            return   # already failed

        brain_log(f"FAILURE: {vehicle_id} in state {rec.state.name}")

        # Release all segment reservations immediately
        released = reservations.release(vehicle_id)

        # Handle the current task
        if rec.task_id:
            self._handle_task(rec.task_id, rec.state, current_tick)

        # Move vehicle to parking slot to clear road
        from brain.parking_manager import parking_mgr
        from brain.road_graph import graph
        slot_node = parking_mgr.assign_slot(vehicle_id, current_tick)
        if slot_node:
            slot_pos = graph.node_pos(slot_node)
            registry.update(
                vehicle_id,
                x_px=slot_pos[0],
                y_px=slot_pos[1],
                node_id=slot_node
            )
            brain_log(f"TOW: {vehicle_id} moved to parking {slot_node}")

        # Set vehicle state to FAILED, start repair timer
        registry.update(
            vehicle_id,
            state        = VehicleState.REPAIRING,
            task_id      = None,
            instruction  = None,
            repair_until = current_tick + REPAIR_TICKS,
            grace_since  = -1,
        )

        # Update metrics
        metrics.failures += 1

        # Broadcast failure event
        bus.emit_event(EventType.VEHICLE_FAILED, current_tick,
                       {"vehicle_id": vehicle_id})

    def _handle_task(self, task_id: str, state: VehicleState,
                     current_tick: int) -> None:
        """
        Decide what to do with the task based on the vehicle's state at failure.

        Args:
            task_id: the current task
            state:   vehicle state at time of failure
            current_tick: current tick
        """
        from core.models import TaskState
        task = task_mgr.get_task(task_id)
        if not task:
            return

        if state in (VehicleState.MOVING_TO_PICKUP,
                     VehicleState.WAITING_FOR_START):
            # Case A: Failure before pickup — task can be requeued
            task_mgr.requeue(task_id)
            metrics.tasks_reassigned += 1
            brain_log(f"Task {task_id} requeued (no cargo)")

        elif state == VehicleState.MOVING_TO_DEST:
            # Case B: Failure with cargo — task is lost
            task_mgr.fail(task_id, reason="vehicle_failure_with_cargo")
            metrics.tasks_failed += 1
            brain_log(f"Task {task_id} FAILED (cargo lost with vehicle)")

        # Handle pre-assigned tasks in the queue
        from vehicle.vehicle_registry import registry as reg
        # These are already in the queue — requeue them
        # (they'll be picked up by the allocator)

    def check_repair(self, vehicle_id: str, current_tick: int) -> bool:
        """
        Check if a vehicle's repair is complete.
        Called every tick from vehicle.py.

        Args:
            vehicle_id:   vehicle being checked
            current_tick: current simulation tick

        Returns:
            True if repair is complete and vehicle returned to IDLE
        """
        rec = registry.get(vehicle_id)
        if not rec or rec.state != VehicleState.REPAIRING:
            return False

        if current_tick >= rec.repair_until:
            # Repair complete — return to IDLE
            registry.update(
                vehicle_id,
                state        = VehicleState.IDLE,
                repair_until = 0,
            )
            brain_log(f"{vehicle_id} repair complete — returning to service")
            bus.emit_event(EventType.VEHICLE_REPAIRED, current_tick,
                           {"vehicle_id": vehicle_id})
            return True

        return False

    def trigger_random(self, current_tick: int) -> str:
        """
        Trigger a failure on a random active vehicle.
        Used by the 'F' key manual failure.

        Returns:
            vehicle_id of the failed vehicle, or "" if none available
        """
        from core.models import VehicleState
        eligible = registry.vehicles_in_state(
            VehicleState.MOVING_TO_PICKUP,
            VehicleState.MOVING_TO_DEST,
            VehicleState.IDLE,
        )
        if not eligible:
            return ""
        victim = random.choice(eligible)
        self.trigger(victim.vehicle_id, current_tick)
        return victim.vehicle_id


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

failure_mgr = FailureManager()
