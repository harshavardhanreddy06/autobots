"""
brain/task_generator.py — Continuous Task Stream Generator

PURPOSE:
    Creates new pickup-to-drop tasks at regular intervals and publishes
    them on the event bus. This simulates a real-world order stream
    (like a warehouse management system sending work orders).

DESIGN:
    Every TASK_INTERVAL ticks, generate one new task.
    Task priority is chosen by weighted random selection using PRIORITY_WEIGHTS.
    Pickup and drop nodes are chosen randomly from the station lists.

SETUP:
    After loading map_config.json, main.py calls:
        task_gen.set_stations(pickup_data, drop_data)
    This provides the node_ids and pixel positions for station selection.

EVENT:
    Emits EventType.TASK_CREATED on the bus after adding to task_mgr.
    CentralBrain listens and immediately triggers allocation.
"""

from __future__ import annotations
import random
from config import TASK_INTERVAL, PRIORITY_WEIGHTS
from core.models import Task, TaskState
from core.event_bus import bus, EventType
from brain.task_manager import task_mgr
from brain.metrics_tracker import metrics


class TaskGenerator:
    """
    Generates tasks at TASK_INTERVAL ticks with weighted priority selection.
    """

    def __init__(self):
        self._task_counter: int = 0
        self._pickup_nodes: list = []   # list of node_id strings
        self._pickup_px:    list = []   # list of (x, y) pixel tuples
        self._drop_nodes:   list = []
        self._drop_px:      list = []

        # Build priority pool once from weights
        self._priority_pool = []
        for priority, weight in PRIORITY_WEIGHTS.items():
            self._priority_pool.extend([priority] * weight)

    def set_stations(self, pickup_data: list, drop_data: list) -> None:
        """
        Configure pickup and drop station lists.
        Called once from main.py after loading map_config.json.

        Args:
            pickup_data: list of dicts with keys 'node_id', 'x_px', 'y_px'
            drop_data:   list of dicts with keys 'node_id', 'x_px', 'y_px'
        """
        self._pickup_nodes = [s["node_id"] for s in pickup_data]
        self._pickup_px    = [(s["x_px"], s["y_px"]) for s in pickup_data]
        self._drop_nodes   = [s["node_id"] for s in drop_data]
        self._drop_px      = [(s["x_px"], s["y_px"]) for s in drop_data]

    def tick(self, current_tick: int) -> bool:
        """
        Generate a new task if the interval has elapsed.

        Args:
            current_tick: current simulation tick

        Returns:
            True if a task was generated this tick, False otherwise
        """
        if not self._pickup_nodes or not self._drop_nodes:
            return False   # stations not set up yet

        if current_tick % TASK_INTERVAL != 0:
            return False

        return self._generate(current_tick)

    def force_generate(self, current_tick: int) -> bool:
        """
        Generate a task immediately regardless of interval.
        Used by tests and the UI (F key press for debugging).
        """
        return self._generate(current_tick)

    def _generate(self, current_tick: int) -> bool:
        """
        Internal: create one task with a random pickup, drop, and priority.

        Ensures pickup != drop (no zero-distance tasks).

        Returns:
            True if generated, False if no valid pickup/drop pair
        """
        if not self._pickup_nodes or not self._drop_nodes:
            return False

        # Random pickup
        idx = random.randrange(len(self._pickup_nodes))
        pickup_node = self._pickup_nodes[idx]
        pickup_px   = self._pickup_px[idx]

        # Random drop (ensure different from pickup)
        drop_idx  = random.randrange(len(self._drop_nodes))
        drop_node = self._drop_nodes[drop_idx]
        drop_px   = self._drop_px[drop_idx]

        if pickup_node == drop_node:
            return False   # skip zero-distance task

        # Random priority (weighted)
        priority = random.choice(self._priority_pool)

        # Create task
        task_id = f"T{self._task_counter}"
        self._task_counter += 1

        task = Task(
            task_id          = task_id,
            pickup_node      = pickup_node,
            drop_node        = drop_node,
            pickup_px        = pickup_px,
            drop_px          = drop_px,
            priority         = priority,
            created_tick     = current_tick,
            state            = TaskState.PENDING,
        )

        # Register with task manager
        task_mgr.add(task)
        metrics.tasks_generated += 1

        # Broadcast on event bus so CentralBrain can immediately allocate
        bus.emit_event(EventType.TASK_CREATED, current_tick,
                       {"task_id": task_id, "priority": priority})

        return True


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

task_gen = TaskGenerator()
