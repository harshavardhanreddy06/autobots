"""
brain/central_brain.py — Master Coordinator (The Central Brain)

PURPOSE:
    Orchestrates the complete scheduling pipeline for every vehicle.
    Wires together all brain modules into a coherent decision sequence.
    Runs the main tick loop for all brain-level periodic tasks.

PIPELINE (called for each new route request):
    1. Find start/end nodes from pixel positions
    2. Plan route via A* (Route Planner)
    3. Generate speed profile (Speed Coordinator)
    4. Build time-stamped schedule (Schedule Builder)
    5. Predict conflicts (Collision Predictor)
    6. If conflicts → resolve via Decision Engine (6 levels)
    7. Commit approved schedule to Reservation Manager
    8. Build and deliver VehicleInstruction to vehicle via Registry

TICK LOOP (called every tick from main.py):
    - Process pending task allocation
    - Update parking grace periods
    - Run periodic optimizer
    - Run periodic deadlock check
    - GC reservation table
    - Update metrics
    - Collect ML samples

WHO CALLS THIS:
    - main.py calls brain.tick(current_tick) once per frame
    - vehicle/comm_manager.py calls brain.schedule_* methods on events
"""

from __future__ import annotations
from typing import Optional
from config import (DEADLOCK_CHECK_INTERVAL, OPTIMIZER_INTERVAL,
                    ML_SAMPLE_INTERVAL, GC_KEEP_TICKS)
from core.models import (VehicleState, VehicleInstruction, Task)
from brain.brain_logger import brain_log, get_brain_log
from brain.road_graph import graph
from brain.route_planner import route_planner
from brain.schedule_builder import schedule_builder
from brain.speed_coordinator import speed_coordinator
from brain.collision_predictor import collision_pred
from brain.decision_engine import decision_engine
from brain.reservation_manager import reservations
from brain.task_manager import task_mgr
from brain.task_allocator import allocator
from brain.task_generator import task_gen
from brain.parking_manager import parking_mgr
from brain.throughput_optimizer import throughput_opt
from brain.failure_manager import failure_mgr
from brain.deadlock_detector import deadlock_detector
from brain.traffic_snapshot import traffic_snap
from brain.metrics_tracker import metrics
from vehicle.vehicle_registry import registry


class CentralBrain:
    """
    Master coordinator for the autonomous vehicle fleet.

    All scheduling decisions flow through this class.
    It is the only module that directly coordinates multiple brain
    modules in sequence — no other module reaches across module boundaries.
    """

    def __init__(self):
        self._tick: int = 0

    # ─────────────────────────────────────────────────────
    # MAIN TICK — called every frame from main.py
    # ─────────────────────────────────────────────────────

    def tick(self, current_tick: int) -> None:
        """
        Run all periodic brain operations for this simulation tick.

        Args:
            current_tick: simulation tick counter
        """
        self._tick = current_tick

        # 1. Generate new task if interval elapsed
        task_gen.tick(current_tick)

        # 2. Allocate all pending tasks that haven't been assigned
        self._allocate_pending(current_tick)

        # 3. Update parking grace periods
        parking_mgr.update(current_tick)

        # 4. Task lifecycle maintenance (escalation, expiry)
        task_mgr.tick_update(current_tick)

        # 5. Deadlock detector: stuck-vehicle tracking every tick
        deadlock_detector.update(current_tick)

        # 6. Periodic deadlock check
        if current_tick % DEADLOCK_CHECK_INTERVAL == 0:
            deadlock_detector.check(current_tick)

        # 7. Periodic throughput optimization
        if current_tick % OPTIMIZER_INTERVAL == 0:
            throughput_opt.optimize(current_tick)

        # 8. Reservation GC
        if current_tick % 60 == 0:
            reservations.gc(current_tick)

        # 9. Metrics update
        snap = registry.snapshot()
        metrics.update(current_tick, snap)
        metrics.peak_queue_size = max(
            metrics.peak_queue_size, task_mgr.pending_count()
        )

        # 10. ML sample collection
        if current_tick % ML_SAMPLE_INTERVAL == 0:
            traffic_snap.collect(current_tick)

        # 11. ML model training — fires automatically every TRAIN_INTERVAL ticks
        #     when enough samples have been collected.
        #     Both models are imported lazily; if not installed they no-op silently.
        try:
            from brain.ml.allocator_model import ml_allocator
            ml_allocator.maybe_train(current_tick)
        except Exception:
            pass
        try:
            from brain.ml.speed_model import ml_speed
            ml_speed.maybe_train(current_tick)
        except Exception:
            pass

    def _allocate_pending(self, current_tick: int) -> None:
        """
        Attempt to allocate each pending task to a vehicle.
        Called every tick — allocator is fast enough.
        """
        pending = task_mgr.get_pending()
        for task in pending:
            vid = allocator.allocate(task, current_tick)
            if not vid:
                continue

            # Is this a pre-assignment (vehicle already delivering)?
            if allocator.is_preassign(vid):
                # Queue the task; will be routed when vehicle delivers
                task_mgr.assign(task.task_id, vid, current_tick)
                rec = registry.get(vid)
                if rec and task.task_id not in rec.pending_task_ids:
                    rec.pending_task_ids.append(task.task_id)
                metrics.tasks_assigned += 1
                brain_log(f"PRE-ASSIGN {task.task_id} → {vid}")
            else:
                # Immediate assignment — run full scheduling pipeline
                success = self.schedule_to_pickup(vid, task, current_tick)
                if success:
                    task_mgr.assign(task.task_id, vid, current_tick)
                    task_mgr.mark_pickup_enroute(task.task_id)
                    metrics.tasks_assigned += 1

    # ─────────────────────────────────────────────────────
    # SCHEDULING PIPELINE
    # ─────────────────────────────────────────────────────

    def schedule_to_pickup(self, vehicle_id: str, task: Task,
                           current_tick: int) -> bool:
        """
        Full pipeline: plan route to pickup, resolve conflicts, commit.

        Args:
            vehicle_id:   vehicle to schedule
            task:         the task to execute
            current_tick: current tick

        Returns:
            True if instruction was successfully issued, False on failure
        """
        rec = registry.get(vehicle_id)
        if not rec:
            return False

        start_node = graph.nearest_node(rec.x_px, rec.y_px)
        end_node   = task.pickup_node

        return self._run_pipeline(
            vehicle_id      = vehicle_id,
            start_node      = start_node,
            end_node        = end_node,
            current_tick    = current_tick,
            task_id         = task.task_id,
            destination_type= "TO_PICKUP",
            task_priority   = task.priority,
        )

    def schedule_to_drop(self, vehicle_id: str, task: Task,
                         current_tick: int) -> bool:
        """
        Plan route from pickup to drop location.

        Args:
            vehicle_id:   vehicle that just reached pickup
            task:         the task being executed
            current_tick: current tick

        Returns:
            True if instruction successfully issued
        """
        return self._run_pipeline(
            vehicle_id       = vehicle_id,
            start_node       = task.pickup_node,
            end_node         = task.drop_node,
            current_tick     = current_tick,
            task_id          = task.task_id,
            destination_type = "TO_DROP",
            task_priority    = task.priority,
        )

    def schedule_to_parking(self, vehicle_id: str,
                            current_tick: int) -> bool:
        """
        Plan route from current position to nearest parking slot.

        Args:
            vehicle_id:   vehicle to send to parking
            current_tick: current tick

        Returns:
            True if instruction successfully issued
        """
        rec = registry.get(vehicle_id)
        if not rec:
            return False

        start_node  = graph.nearest_node(rec.x_px, rec.y_px)
        parking_node = parking_mgr.assign_slot(vehicle_id, current_tick)
        if not parking_node:
            return False   # no slots available

        return self._run_pipeline(
            vehicle_id       = vehicle_id,
            start_node       = start_node,
            end_node         = parking_node,
            current_tick     = current_tick,
            task_id          = None,
            destination_type = "TO_PARKING",
            task_priority    = "LOW",
        )

    def _run_pipeline(self, vehicle_id: str, start_node: str, end_node: str,
                      current_tick: int, task_id: Optional[str],
                      destination_type: str,
                      task_priority: str = "NORMAL") -> bool:
        """
        Core scheduling pipeline:
        Route Plan → Speed Profile → Schedule → Conflict Check → Resolve → Commit

        ATOMIC COMMIT FIX:
            Old code: release() first → commit() → if commit fails, vehicle loses
                      all reservations but keeps old instruction → invisible ghost on road.
            New code: do a FINAL conflict re-check BEFORE releasing.
                      Only release if the new schedule is verified clean.
                      If still in conflict, retry with a later departure tick.
                      Vehicle stays frozen safely until a clean slot is confirmed.

        Returns:
            True if a valid schedule was committed
        """
        # 1. Handle same-node case (already at destination)
        if start_node == end_node:
            self._issue_instruction(vehicle_id, [], current_tick,
                                    task_id, destination_type, end_node)
            return True

        # 2. Plan route
        route = route_planner.plan(start_node, end_node, current_tick)
        if not route:
            brain_log(f"No route {start_node}→{end_node} for {vehicle_id}")
            return False

        # 3. Generate speed profile
        speed_profile = speed_coordinator.generate(route, current_tick)

        # 4. Build initial schedule
        schedule = schedule_builder.build(route, current_tick, speed_profile)

        # 5. Predict conflicts (excludes this vehicle's own old reservations)
        conflicts = collision_pred.predict(schedule, exclude_vid=vehicle_id)

        level = 0
        if conflicts:
            metrics.predicted_collisions += len(conflicts)
            # 6. Resolve via Decision Engine (6-level cascade)
            schedule, level = decision_engine.resolve(
                vehicle_id       = vehicle_id,
                route            = route,
                initial_schedule = schedule,
                conflicts        = conflicts,
                current_tick     = current_tick,
                task_priority    = task_priority,
                task_manager     = task_mgr,
            )
            if level < 6 and schedule:
                metrics.prevented_collisions += len(conflicts)
            elif level == 6 or not schedule:
                # L6 emergency: stop in place, keep old reservations intact
                throughput_opt.trigger(current_tick)
                metrics.level_6_emergency += 1
                self._issue_instruction(vehicle_id, [], current_tick,
                                        task_id, destination_type, end_node)
                return False

        # 7. FINAL SAFETY RE-CHECK — other vehicles may have committed new schedules
        #    between step 5 and now within the same tick. Re-verify before releasing.
        final_conflicts = collision_pred.predict(schedule, exclude_vid=vehicle_id)
        if final_conflicts:
            from brain.departure_scheduler import departure_scheduler
            start_search = schedule[0].enter_tick + 1 if schedule else current_tick + 1
            dep_tick, retry_schedule = departure_scheduler.find_clean_departure(
                route          = route,
                earliest_tick  = start_search,
                speed_profile  = speed_profile,
                exclude_vid    = vehicle_id,
                task_manager   = task_mgr,
                task_priority  = task_priority,
            )
            if retry_schedule:
                schedule = retry_schedule
                level = max(level, 1)
                metrics.prevented_collisions += 1
            else:
                # No clean slot — emergency stop, old reservations stay intact
                brain_log(f"No clean slot for {vehicle_id}, emergency stop")
                metrics.level_6_emergency += 1
                self._issue_instruction(vehicle_id, [], current_tick,
                                        task_id, destination_type, end_node)
                return False

        # 8. Atomically release old reservations then commit new verified-clean schedule
        reservations.release(vehicle_id)
        committed = reservations.commit(vehicle_id, schedule)

        if not committed:
            # Should never happen after double-check. Safety: halt vehicle.
            brain_log(f"UNEXPECTED commit fail {vehicle_id} — halting vehicle")
            self._issue_instruction(vehicle_id, [], current_tick,
                                    task_id, destination_type, end_node)
            return False

        # 9. Issue movement instruction to vehicle
        self._issue_instruction(vehicle_id, schedule, current_tick,
                                task_id, destination_type, end_node)

        if level > 0:
            brain_log(f"L{level}: {vehicle_id} → {end_node}")

        return True

    def _issue_instruction(self, vehicle_id: str, schedule: list,
                           current_tick: int, task_id: Optional[str],
                           destination_type: str, end_node: str) -> None:
        """
        Build and deliver a VehicleInstruction to the vehicle via the Registry.

        Also sets the vehicle state based on:
            - Empty schedule → state matches destination_type immediately
            - Future departure → WAITING_FOR_START
            - Immediate departure → MOVING_* state
        """
        new_version = registry.increment_version(vehicle_id)

        start_tick = schedule[0].enter_tick if schedule else current_tick

        instr = VehicleInstruction(
            vehicle_id       = vehicle_id,
            schedule         = schedule,
            schedule_version = new_version,
            task_id          = task_id,
            destination_type = destination_type,
            start_tick       = start_tick,
            end_node         = end_node,
        )

        # Determine state
        if not schedule:
            new_state = self._arrival_state(destination_type)
        elif start_tick > current_tick:
            new_state = VehicleState.WAITING_FOR_START
        else:
            new_state = self._moving_state(destination_type)

        registry.update(
            vehicle_id,
            instruction      = instr,
            schedule_version = new_version,
            state            = new_state,
            task_id          = task_id,
        )

    def _moving_state(self, destination_type: str) -> VehicleState:
        """Map destination_type to the corresponding MOVING state."""
        return {
            "TO_PICKUP":  VehicleState.MOVING_TO_PICKUP,
            "TO_DROP":    VehicleState.MOVING_TO_DEST,
            "TO_PARKING": VehicleState.MOVING_TO_PARKING,
        }.get(destination_type, VehicleState.IDLE)

    def _arrival_state(self, destination_type: str) -> VehicleState:
        """State to set when schedule is empty (already at destination)."""
        return {
            "TO_PICKUP":  VehicleState.MOVING_TO_PICKUP,  # handled by vehicle.py
            "TO_DROP":    VehicleState.MOVING_TO_DEST,
            "TO_PARKING": VehicleState.PARKED,
        }.get(destination_type, VehicleState.IDLE)


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

brain = CentralBrain()
