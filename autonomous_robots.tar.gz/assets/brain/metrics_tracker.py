"""
brain/metrics_tracker.py — System-Wide Metrics and Statistics

PURPOSE:
    Tracks every measurable quantity in the simulation in real time.
    The UI panel reads from this module to display fleet statistics,
    safety counters, resolution level usage, and throughput numbers.

WHY A DEDICATED METRICS MODULE:
    Without centralized tracking, each module would maintain its own
    counters and the UI would need to import from 15 different places.
    Here, one module owns all counters and the UI imports just this one.

DESIGN:
    Simple dataclass of integer/float counters. No logic.
    update() is called once per tick from main.py to compute
    derived metrics (throughput per minute, utilisation percentage).
    ML sample buffers are capped to prevent unbounded memory growth.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from collections import deque


@dataclass
class MetricsTracker:
    """
    All operational counters for the simulation.

    Categories:
        Task metrics     — how many tasks at each lifecycle stage
        Fleet metrics    — vehicle state distribution
        Safety metrics   — collision prevention statistics
        Resolution       — how often each conflict level was used
        Deadlock         — detection and resolution counts
        Performance      — throughput and timing
        ML buffers       — training sample collections
    """

    # ── Task Metrics ──────────────────────────────────────
    tasks_generated:        int = 0   # total tasks ever created
    tasks_completed:        int = 0   # successfully delivered
    tasks_failed:           int = 0   # vehicle failure with cargo, or timeout
    tasks_reassigned:       int = 0   # requeued after vehicle failure before pickup
    tasks_expired:          int = 0   # timed out in PENDING state
    tasks_assigned:         int = 0   # total assignment events
    immediate_reassignments: int = 0  # Path B: assigned from drop location
    pre_assignment_hits:    int = 0   # Path A: pre-assigned task executed on delivery

    # ── Fleet Metrics ─────────────────────────────────────
    vehicles_idle:          int = 0
    vehicles_waiting:       int = 0   # WAITING_FOR_START
    vehicles_to_pickup:     int = 0   # MOVING_TO_PICKUP
    vehicles_to_dest:       int = 0   # MOVING_TO_DEST
    vehicles_to_parking:    int = 0   # MOVING_TO_PARKING
    vehicles_parked:        int = 0
    vehicles_failed:        int = 0
    vehicles_repairing:     int = 0
    fleet_utilisation:      float = 0.0  # active / total (0.0 – 1.0)

    # ── Safety Metrics ────────────────────────────────────
    predicted_collisions:   int = 0   # conflicts detected before committing
    prevented_collisions:   int = 0   # conflicts resolved (L1-L5)
    confirmed_collisions:   int = 0   # physical collisions detected in-loop
    near_misses:            int = 0   # escalated to L5 or L6

    # ── Resolution Level Usage ────────────────────────────
    level_1_departures:     int = 0   # departure delay used
    level_2_speed:          int = 0   # speed adjustment used
    level_3_propagation:    int = 0   # lane propagation used
    level_4_optimiser:      int = 0   # throughput optimiser triggered
    level_5_reroutes:       int = 0   # reroute used
    level_6_emergency:      int = 0   # emergency stop used

    # ── Deadlock ──────────────────────────────────────────
    deadlocks_detected:     int = 0
    deadlocks_resolved:     int = 0

    # ── Performance ───────────────────────────────────────
    failures:               int = 0
    avg_task_time:          float = 0.0   # ticks from assign to complete
    throughput_per_min:     float = 0.0   # tasks completed per simulated minute
    peak_queue_size:        int = 0       # largest pending queue ever seen

    # ── Fleet Scaling Signals ─────────────────────────────
    underprovision_streak:  int = 0   # consecutive ticks of queue > 2x fleet
    overprovision_streak:   int = 0   # consecutive ticks of idle > 50% fleet
    underprovision_events:  int = 0
    overprovision_events:   int = 0

    # ── ML Sample Buffers ─────────────────────────────────
    # Capped deques — oldest samples are dropped automatically
    route_samples:          deque = field(default_factory=lambda: deque(maxlen=500))
    allocation_samples:     deque = field(default_factory=lambda: deque(maxlen=500))
    congestion_samples:     deque = field(default_factory=lambda: deque(maxlen=1000))
    training_samples_collected: int = 0

    # ── Internal ──────────────────────────────────────────
    _task_times:            list = field(default_factory=list)  # for avg calc
    _completed_60s:         list = field(default_factory=list)  # ticks of completions

    def update(self, current_tick: int, registry_snapshot: list) -> None:
        """
        Recompute derived metrics. Called once per tick from main.py.

        Args:
            current_tick:      simulation tick counter
            registry_snapshot: list of VehicleRecord from vehicle registry
        """
        from core.models import VehicleState

        # Count vehicles in each state
        self.vehicles_idle        = sum(1 for r in registry_snapshot if r.state == VehicleState.IDLE)
        self.vehicles_waiting     = sum(1 for r in registry_snapshot if r.state == VehicleState.WAITING_FOR_START)
        self.vehicles_to_pickup   = sum(1 for r in registry_snapshot if r.state == VehicleState.MOVING_TO_PICKUP)
        self.vehicles_to_dest     = sum(1 for r in registry_snapshot if r.state == VehicleState.MOVING_TO_DEST)
        self.vehicles_to_parking  = sum(1 for r in registry_snapshot if r.state == VehicleState.MOVING_TO_PARKING)
        self.vehicles_parked      = sum(1 for r in registry_snapshot if r.state == VehicleState.PARKED)
        self.vehicles_failed      = sum(1 for r in registry_snapshot if r.state == VehicleState.FAILED)
        self.vehicles_repairing   = sum(1 for r in registry_snapshot if r.state == VehicleState.REPAIRING)

        total = len(registry_snapshot)
        active = self.vehicles_to_pickup + self.vehicles_to_dest
        self.fleet_utilisation = active / max(1, total)

        # Throughput: tasks completed in last 3600 ticks (1 simulated minute at 60fps)
        window = 3600
        self._completed_60s = [t for t in self._completed_60s if current_tick - t <= window]
        self.throughput_per_min = len(self._completed_60s)

        # Average task time
        if self._task_times:
            self.avg_task_time = sum(self._task_times) / len(self._task_times)

    def record_completion(self, assign_tick: int, complete_tick: int) -> None:
        """Record a task completion for avg_time and throughput calculation."""
        duration = complete_tick - assign_tick
        self._task_times.append(duration)
        if len(self._task_times) > 200:
            self._task_times = self._task_times[-200:]
        self._completed_60s.append(complete_tick)
        self.tasks_completed += 1

    def add_route_sample(self, sample: dict) -> None:
        """Add an ML training sample for route prediction."""
        self.route_samples.append(sample)
        self.training_samples_collected += 1

    def add_allocation_sample(self, sample: dict) -> None:
        """Add an ML training sample for allocation decisions."""
        self.allocation_samples.append(sample)
        self.training_samples_collected += 1

    def add_congestion_sample(self, sample: dict) -> None:
        """Add an ML training sample for congestion prediction."""
        self.congestion_samples.append(sample)
        self.training_samples_collected += 1


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

metrics = MetricsTracker()
