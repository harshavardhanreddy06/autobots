"""
brain/deadlock_detector.py — Wait-For Graph Cycle Detection

PURPOSE:
    Detects circular wait dependencies between vehicles.
    A deadlock occurs when: Vehicle A is waiting for B's segment,
    B is waiting for C's segment, and C is waiting for A's segment.
    None of them can proceed → permanent gridlock.

HOW IT WORKS:
    1. Build a "wait-for graph": directed graph where edge A→B means
       "vehicle A is waiting for a segment currently owned by vehicle B"
    2. Run DFS cycle detection on this graph
    3. If a cycle is found → deadlock exists
    4. Select a victim (lowest-priority vehicle in the cycle)
    5. Trigger victim's failure → breaks the cycle → others can proceed

WHEN IT RUNS:
    Periodic: every DEADLOCK_CHECK_INTERVAL ticks from central_brain
    Reactive: triggered immediately when a vehicle waits > DEADLOCK_WAIT_THRESHOLD ticks

BUILD GRAPH LOGIC:
    For each vehicle V in WAITING_FOR_START or MOVING states:
        If V has been waiting at the same node for too long:
            Find the segment V wants to enter next
            Find who owns that segment in the reservation table
            Add edge V → owner

VICTIM SELECTION:
    From the cycle, pick the vehicle with the lowest task priority.
    Tie-break: pick the vehicle whose failure causes the least disruption
    (fewest pre-assigned tasks in its queue).
"""

from __future__ import annotations
from config import DEADLOCK_CHECK_INTERVAL, DEADLOCK_WAIT_THRESHOLD
from core.models import VehicleState
from brain.brain_logger import brain_log
from brain.reservation_manager import reservations
from brain.metrics_tracker import metrics
from vehicle.vehicle_registry import registry


class DeadlockDetector:
    """
    Wait-for graph builder and cycle detector.

    Periodic + reactive deadlock detection with priority-based victim selection.
    """

    def __init__(self):
        self._last_check: int = 0
        # Track how long each vehicle has been "stuck" (not advancing)
        self._stuck_since: dict = {}   # vehicle_id → tick when stuck started
        self._last_node: dict = {}     # vehicle_id → node_id last frame

    def update(self, current_tick: int) -> None:
        """
        Update stuck-tracking for all vehicles.
        Called every tick from central_brain.

        Vehicles that haven't moved to a new node for DEADLOCK_WAIT_THRESHOLD ticks
        are considered "stuck" and trigger a reactive deadlock check.
        """
        all_records = registry.snapshot()

        for rec in all_records:
            if rec.state not in (VehicleState.WAITING_FOR_START,
                                 VehicleState.MOVING_TO_PICKUP,
                                 VehicleState.MOVING_TO_DEST):
                self._stuck_since.pop(rec.vehicle_id, None)
                self._last_node.pop(rec.vehicle_id, None)
                continue

            last = self._last_node.get(rec.vehicle_id)
            if last != rec.node_id:
                # Vehicle moved — reset stuck timer
                self._last_node[rec.vehicle_id] = rec.node_id
                self._stuck_since[rec.vehicle_id] = current_tick
            else:
                stuck_for = current_tick - self._stuck_since.get(
                    rec.vehicle_id, current_tick
                )
                if stuck_for >= DEADLOCK_WAIT_THRESHOLD:
                    # Reactive trigger
                    self.check(current_tick, reactive_for=rec.vehicle_id)
                    return

    def check(self, current_tick: int,
              reactive_for: str = None) -> bool:
        """
        Run a full wait-for graph cycle check.

        Args:
            current_tick:  current simulation tick
            reactive_for:  if set, triggered reactively for this vehicle

        Returns:
            True if a deadlock was found and resolved
        """
        if not reactive_for:
            if current_tick - self._last_check < DEADLOCK_CHECK_INTERVAL:
                return False
        self._last_check = current_tick

        wait_graph = self._build_wait_graph(current_tick)
        if not wait_graph:
            return False

        cycle = self._find_cycle(wait_graph)
        if not cycle:
            return False

        # Deadlock found
        metrics.deadlocks_detected += 1
        brain_log(f"DEADLOCK detected: {cycle}")

        # Select victim and trigger failure
        victim = self._select_victim(cycle)
        if victim:
            from brain.failure_manager import failure_mgr
            failure_mgr.trigger(victim, current_tick)
            metrics.deadlocks_resolved += 1
            brain_log(f"DEADLOCK resolved: {victim} sacrificed")

        return True

    # ─── Wait-For Graph ───────────────────────────────────

    def _build_wait_graph(self, current_tick: int) -> dict:
        """
        Build the wait-for graph.

        Returns:
            dict: vehicle_id → set of vehicle_ids it is waiting for
        """
        graph: dict = {}
        all_records = registry.snapshot()

        for rec in all_records:
            if rec.state not in (VehicleState.WAITING_FOR_START,
                                 VehicleState.MOVING_TO_PICKUP,
                                 VehicleState.MOVING_TO_DEST):
                continue
            if not rec.instruction or not rec.instruction.schedule:
                continue

            # Find next segment this vehicle wants to enter
            next_seg = None
            for entry in rec.instruction.schedule:
                if entry.enter_tick > current_tick:
                    next_seg = entry
                    break

            if next_seg is None:
                continue

            # Who owns that segment right now?
            owner = reservations.get_owner(next_seg.segment_id, current_tick)
            if owner and owner != rec.vehicle_id:
                if rec.vehicle_id not in graph:
                    graph[rec.vehicle_id] = set()
                graph[rec.vehicle_id].add(owner)

        return graph

    def _find_cycle(self, graph: dict) -> list:
        """
        DFS-based cycle detection on the wait-for graph.

        Returns:
            List of vehicle_ids in a cycle, or empty list if no cycle.
        """
        visited = set()
        path = []

        def dfs(node: str) -> bool:
            if node in path:
                # Cycle detected — extract the cycle
                idx = path.index(node)
                cycle_nodes = path[idx:]
                path.clear()
                path.extend(cycle_nodes)
                return True
            if node in visited:
                return False
            visited.add(node)
            path.append(node)
            for neighbor in graph.get(node, []):
                if dfs(neighbor):
                    return True
            path.pop()
            return False

        for node in list(graph.keys()):
            if node not in visited:
                if dfs(node):
                    return list(path)

        return []

    def _select_victim(self, cycle: list) -> str:
        """
        Choose which vehicle in the cycle to fail.

        Criteria:
            1. Lowest task priority (LOW > NORMAL > HIGH to fail)
            2. Tie-break: fewest pre-assigned tasks (least disruption)

        Returns:
            vehicle_id of chosen victim
        """
        from config import PRIORITY_WEIGHT
        from brain.task_manager import task_mgr

        best = None
        best_score = float("inf")

        for vid in cycle:
            rec = registry.get(vid)
            if not rec:
                continue

            # Task priority score (lower weight = better victim)
            priority = "NORMAL"
            if rec.task_id:
                task = task_mgr.get_task(rec.task_id)
                if task:
                    priority = task.priority
            p_weight = PRIORITY_WEIGHT.get(priority, 2)

            # Pre-assigned queue size (fewer = better victim)
            queue_size = len(rec.pending_task_ids)

            score = p_weight * 10 + queue_size
            if score < best_score:
                best_score = score
                best = vid

        return best or (cycle[0] if cycle else "")


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

deadlock_detector = DeadlockDetector()
