"""
brain/road_graph.py — Road Network Graph

PURPOSE:
    Builds and maintains the directed road graph that the Route Planner
    uses for A* pathfinding. Every intersection is a node. Every directed
    road connection between adjacent intersections is an edge.

WHY DIRECTED:
    Roads are dual-lane with opposite directions. A vehicle going right
    uses the top lane; going left uses the bottom lane. The graph models
    this as two directed edges between each adjacent pair — one each way.
    Both edges share the same road but are distinct segments for scheduling.

NODE ID FORMAT:
    f"{col}_{row}" — e.g., "0_0" is top-left, "7_6" is bottom-right.

SEGMENT ID FORMAT:
    f"{from_col}_{from_row}__{to_col}_{to_row}" — double underscore separates nodes.
    e.g., "1_0__2_0" is the segment from (col=1,row=0) to (col=2,row=0).

GRAPH STRUCTURE:
    8 columns (0–7), 7 rows (0–6) = 56 nodes total.
    Each node connects to up to 4 neighbors (up/down/left/right).
    All connections are bidirectional → up to 212 directed edges.

BUILDING:
    graph.build(intersections_data) is called once from main.py after
    loading map_config.json. It stores node positions and builds adjacency.
"""

from __future__ import annotations
import math
from typing import Optional


class RoadGraph:
    """
    Directed grid road graph.

    Provides:
        - Node position lookup (pixel coordinates)
        - Adjacency list for A* traversal
        - Segment ID generation
        - Node enabling/disabling for rerouting scenarios
        - Nearest node lookup for any pixel position
    """

    def __init__(self):
        # node_id → (x_px, y_px)
        self._positions: dict[str, tuple] = {}

        # node_id → list of neighbor node_ids (directed outgoing edges)
        self._adjacency: dict[str, list] = {}

        # Disabled node ids — excluded from routing
        self._disabled: set = set()

        # Grid dimensions (set during build)
        self._cols: int = 0
        self._rows: int = 0

    # ─── Build ────────────────────────────────────────────

    def build(self, intersections_data: list) -> None:
        """
        Build the graph from the map configuration intersections list.

        Each entry in intersections_data has:
            col, row  — grid coordinates
            x_px, y_px — pixel position

        This is called once at startup from main.py.

        Args:
            intersections_data: list of dicts from map_config.json["intersections"]
        """
        self._positions.clear()
        self._adjacency.clear()

        # Store positions
        max_col = max_row = 0
        for item in intersections_data:
            col, row = item["col"], item["row"]
            nid = f"{col}_{row}"
            self._positions[nid] = (item["x_px"], item["y_px"])
            self._adjacency[nid] = []
            max_col = max(max_col, col)
            max_row = max(max_row, row)

        self._cols = max_col
        self._rows = max_row

        # Build adjacency: connect each node to its 4 grid neighbors
        for nid in self._positions:
            col, row = self._parse(nid)
            for dc, dr in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
                nc, nr = col + dc, row + dr
                neighbor = f"{nc}_{nr}"
                if neighbor in self._positions:
                    self._adjacency[nid].append(neighbor)

    # ─── Query ────────────────────────────────────────────

    def node_pos(self, node_id: str) -> tuple:
        """
        Return the pixel (x, y) position of a node.

        Args:
            node_id: e.g., "2_3"

        Returns:
            (x_px, y_px) tuple, or (0, 0) if node not found
        """
        return self._positions.get(node_id, (0, 0))

    def neighbors(self, node_id: str) -> list:
        """
        Return list of neighbor node_ids for A* traversal.
        Disabled nodes are excluded.

        Args:
            node_id: source node

        Returns:
            List of reachable neighbor node_ids
        """
        return [
            n for n in self._adjacency.get(node_id, [])
            if n not in self._disabled
        ]

    def segment_id(self, from_node: str, to_node: str) -> str:
        """Generate the canonical segment ID for a directed edge."""
        return f"{from_node}__{to_node}"

    def nearest_node(self, x_px: float, y_px: float) -> str:
        """
        Find the road graph node closest to the given pixel position.
        Used to find a vehicle's start node for route planning.

        Uses Euclidean distance. O(n) over all nodes, acceptable for 56 nodes.

        Args:
            x_px, y_px: pixel position

        Returns:
            Closest node_id string
        """
        best_id = None
        best_dist = float("inf")
        for nid, (nx, ny) in self._positions.items():
            d = math.hypot(x_px - nx, y_px - ny)
            if d < best_dist:
                best_dist = d
                best_id = nid
        return best_id or "0_0"

    def heuristic(self, node_a: str, node_b: str) -> float:
        """
        Manhattan distance heuristic for A*.
        Uses grid coordinates, not pixel coordinates,
        so the cost is in 'hops' matching the edge cost units.

        Args:
            node_a, node_b: node ids to measure between

        Returns:
            Estimated number of hops between the two nodes
        """
        ca, ra = self._parse(node_a)
        cb, rb = self._parse(node_b)
        return abs(ca - cb) + abs(ra - rb)

    def pixel_distance(self, node_a: str, node_b: str) -> float:
        """
        Euclidean pixel distance between two nodes.
        Used by Schedule Builder to compute travel ticks.
        """
        ax, ay = self._positions.get(node_a, (0, 0))
        bx, by = self._positions.get(node_b, (0, 0))
        return math.hypot(bx - ax, by - ay)

    def all_nodes(self) -> list:
        """Return all node ids in the graph."""
        return list(self._positions.keys())

    def all_positions(self) -> dict:
        """Return the full node_id → (x, y) mapping."""
        return dict(self._positions)

    # ─── Enable / Disable ─────────────────────────────────

    def disable_node(self, node_id: str) -> None:
        """
        Temporarily remove a node from routing.
        Used by the Decision Engine (Level 5 reroute) to force
        a vehicle around a specific congested zone.
        """
        self._disabled.add(node_id)

    def enable_node(self, node_id: str) -> None:
        """Re-enable a previously disabled node."""
        self._disabled.discard(node_id)

    def is_disabled(self, node_id: str) -> bool:
        """Check if a node is currently disabled."""
        return node_id in self._disabled

    # ─── Helpers ──────────────────────────────────────────

    def _parse(self, node_id: str) -> tuple:
        """
        Parse a node_id string into (col, row) integers.
        e.g., "3_2" → (3, 2)
        """
        parts = node_id.split("_")
        return int(parts[0]), int(parts[1])

    def node_count(self) -> int:
        """Total number of nodes in the graph."""
        return len(self._positions)


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# Built once by main.py after loading map_config.json.
# ─────────────────────────────────────────────────────────

graph = RoadGraph()
