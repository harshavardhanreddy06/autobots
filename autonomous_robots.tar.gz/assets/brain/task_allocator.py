"""
brain/task_allocator.py — Predictive Vehicle-Task Assignment

PURPOSE:
    Given a task, find the best vehicle to assign it to using an
    'effective distance' score that accounts for:
        1. Current vehicle position
        2. Vehicle's future position when it will become available
        3. Distance from that future position to the pickup

    This is the core of the throughput optimization strategy.

WHY NOT JUST 'NEAREST IDLE'?
    Nearest-idle misses a huge opportunity: a vehicle 2 blocks from the pickup
    that's currently delivering (will finish in 3 ticks) is MUCH better than
    an idle vehicle 10 blocks away. Predictive scoring captures this.

EFFECTIVE DISTANCE FORMULA:
    For IDLE / PARKED vehicle:
        effective_dist = euclidean(vehicle.pos, pickup.pos)

    For MOVING_TO_DEST vehicle (carrying cargo):
        effective_dist = euclidean(vehicle.drop_pos, pickup.pos)
        (distance from where the vehicle will be after delivery)

    For WAITING_FOR_START vehicle:
        effective_dist = euclidean(vehicle.future_start_pos, pickup.pos)
        (vehicle hasn't started yet, so use the start position of its route)

    Lower score = better match.

ELIGIBILITY RULES:
    ELIGIBLE (can accept task immediately):
        - IDLE
        - PARKED
        - MOVING_TO_PARKING (interrupt and redirect)
    PRE-ASSIGNABLE (queues task for after current delivery):
        - MOVING_TO_DEST (if pending_task_ids queue not full)
    NOT ELIGIBLE:
        - MOVING_TO_PICKUP (committed, cannot change pickup)
        - WAITING_FOR_START (its route is in the reservation table)
        - FAILED, REPAIRING
"""

from __future__ import annotations
import math
from typing import Optional
from config import MAX_PENDING_TASKS, PRIORITY_WEIGHT
from core.models import Task, VehicleState, VehicleRecord
from vehicle.vehicle_registry import registry
from brain.road_graph import graph

# ML Smart Allocator — imported lazily to avoid circular import at module load
# is_ready() is False until enough training samples are collected
_ml_ready: bool = False
try:
    from brain.ml.allocator_model import ml_allocator
    from brain.ml.allocator_features import build_features as _build_alloc_features
    _ml_ready = True
except Exception as _e:
    print(f"[TaskAllocator] ML import skipped: {_e}")
    ml_allocator = None         # type: ignore
    _build_alloc_features = None  # type: ignore


class TaskAllocator:
    """
    Predictive task allocation using effective-distance scoring.

    Considers all eligible vehicles simultaneously and picks the one
    with the lowest effective distance to the pickup, weighted by priority.
    """

    # States eligible for immediate assignment
    IMMEDIATE_STATES = {
        VehicleState.IDLE,
        VehicleState.PARKED,
        VehicleState.MOVING_TO_PARKING,
    }

    # States eligible for pre-assignment (task queued for after delivery)
    PRE_ASSIGN_STATES = {
        VehicleState.MOVING_TO_DEST,
    }

    def allocate(self, task: Task, current_tick: int) -> Optional[str]:
        """
        Find the best vehicle for a task.

        Considers all immediately eligible vehicles AND vehicles that can
        be pre-assigned (currently delivering).

        Args:
            task:         the Task to allocate
            current_tick: current simulation tick

        Returns:
            vehicle_id of best match, or None if no vehicle available
        """
        all_records = registry.snapshot()
        best_vid  = None
        best_score = float("inf")
        best_is_preassign = True   # prefer immediate over pre-assign

        pickup_x, pickup_y = task.pickup_px

        for rec in all_records:
            # ── Immediate eligible ────────────────────────
            if rec.state in self.IMMEDIATE_STATES:
                score = self._effective_dist_immediate(
                    rec, pickup_x, pickup_y, current_tick, task
                )
                is_pre = False
                # Priority weight bonus: higher priority = lower (better) score
                priority_bonus = 1.0 / max(1, PRIORITY_WEIGHT.get(task.priority, 2))
                score *= priority_bonus

                # Prefer immediate over pre-assign
                if not best_is_preassign or score < best_score:
                    best_score = score
                    best_vid = rec.vehicle_id
                    best_is_preassign = False

            # ── Pre-assignable ────────────────────────────
            elif rec.state in self.PRE_ASSIGN_STATES:
                # Check queue capacity
                if len(rec.pending_task_ids) >= MAX_PENDING_TASKS:
                    continue

                score = self._effective_dist_preassign(rec, pickup_x, pickup_y)
                priority_bonus = 1.0 / max(1, PRIORITY_WEIGHT.get(task.priority, 2))
                score *= priority_bonus

                # Only use pre-assign if no immediate vehicle found
                if best_is_preassign and score < best_score:
                    best_score = score
                    best_vid = rec.vehicle_id
                    best_is_preassign = True


        return best_vid

    def is_preassign(self, vehicle_id: str) -> bool:
        """
        Check if the selected vehicle is in a pre-assignable state.
        Used by CommManager to decide whether to start routing immediately
        or add to the vehicle's pending queue.
        """
        rec = registry.get(vehicle_id)
        if not rec:
            return False
        return rec.state in self.PRE_ASSIGN_STATES

    # ─── Scoring ──────────────────────────────────────────

    def _effective_dist_immediate(self, rec: VehicleRecord,
                                  pickup_x: float, pickup_y: float,
                                  current_tick: int = 0,
                                  task: Optional[Task] = None) -> float:
        """
        Score a bot for immediate assignment.

        When the ML model is trained and ready, returns the PREDICTED ticks
        for this bot to physically reach the pickup — traffic-aware score.

        When the model is not yet ready (early in simulation), falls back
        to Euclidean distance (original behaviour, zero impact).
        """
        euclid = math.hypot(rec.x_px - pickup_x, rec.y_px - pickup_y)

        # ── ML path ─────────────────────────────────────────
        if _ml_ready and ml_allocator is not None and ml_allocator.is_ready():
            try:
                from brain.task_manager import task_mgr
                from brain.metrics_tracker import metrics
                # Compute average segment density on the bot→pickup path
                route_density = self._route_density(rec.node_id, pickup_x, pickup_y, current_tick)
                features = _build_alloc_features(
                    rec             = rec,
                    pickup_x        = pickup_x,
                    pickup_y        = pickup_y,
                    current_tick    = current_tick,
                    task            = task,
                    route_density   = route_density,
                    fleet_queue_size = task_mgr.pending_count(),
                    fleet_utilisation = metrics.fleet_utilisation,
                )
                predicted_ticks = ml_allocator.predict(features)
                if predicted_ticks > 0:
                    return predicted_ticks   # ML score — lower = this bot gets task
            except Exception:
                pass  # fallthrough to Euclidean

        # ── Fallback: original Euclidean distance ────────────
        return euclid

    def _effective_dist_preassign(self, rec: VehicleRecord,
                                   pickup_x: float, pickup_y: float) -> float:
        """
        Effective distance for a vehicle in MOVING_TO_DEST state.
        Uses the vehicle's DROP POSITION (where it will be when available).
        We add the distance from current to drop, then drop to pickup.
        """
        if rec.instruction and rec.instruction.end_node:
            drop_px = graph.node_pos(rec.instruction.end_node)
            # Total effective: current → drop + drop → pickup
            current_to_drop = math.hypot(
                rec.x_px - drop_px[0], rec.y_px - drop_px[1]
            )
            drop_to_pickup = math.hypot(
                drop_px[0] - pickup_x, drop_px[1] - pickup_y
            )
            return current_to_drop + drop_to_pickup

        # Fallback: use current position
        return math.hypot(rec.x_px - pickup_x, rec.y_px - pickup_y)

    def _route_density(self, start_node: Optional[str],
                       pickup_x: float, pickup_y: float,
                       current_tick: int) -> float:
        """
        Estimate average road density between a bot's current node and a pickup.
        Uses the graph's nearest node to pickup_px, then queries the
        reservation manager for each segment along the heuristic path.

        Returns 0.0 if any lookup fails (safe fallback).
        """
        try:
            from brain.reservation_manager import reservations
            from config import LOOKAHEAD_TICKS
            if not start_node:
                return 0.0
            pickup_node = graph.nearest_node(pickup_x, pickup_y)
            if not pickup_node or start_node == pickup_node:
                return 0.0
            # A* path (no density weight to avoid recursion)
            from brain.route_planner import route_planner
            route = route_planner.plan(start_node, pickup_node, 0, use_cache=True)
            if not route or len(route) < 2:
                return 0.0
            densities = []
            for i in range(len(route) - 1):
                seg = f"{route[i]}__{route[i+1]}"
                d = reservations.density(seg, current_tick, current_tick + LOOKAHEAD_TICKS)
                densities.append(d)
            return sum(densities) / max(1, len(densities))
        except Exception:
            return 0.0

    def record_allocation_outcome(self, vehicle_id: str,
                                  pickup_x: float, pickup_y: float,
                                  assign_tick: int,
                                  arrival_tick: int,
                                  task=None) -> None:
        """
        Record a completed assignment for ML training.
        Called by comm_manager when a bot reaches pickup.

        Args:
            vehicle_id:   the bot that was assigned
            pickup_x/y:   pickup pixel coordinates
            assign_tick:  tick the task was assigned
            arrival_tick: tick the bot arrived at pickup
            task:         the Task object
        """
        if not _ml_ready or ml_allocator is None:
            return
        try:
            from brain.task_manager import task_mgr
            from brain.metrics_tracker import metrics
            rec = registry.get(vehicle_id)
            if not rec:
                return
            actual_ticks = float(arrival_tick - assign_tick)
            if actual_ticks <= 0:
                return
            route_density = self._route_density(rec.node_id, pickup_x, pickup_y, arrival_tick)
            features = _build_alloc_features(
                rec              = rec,
                pickup_x         = pickup_x,
                pickup_y         = pickup_y,
                current_tick     = assign_tick,
                task             = task,
                route_density    = route_density,
                fleet_queue_size = task_mgr.pending_count(),
                fleet_utilisation = metrics.fleet_utilisation,
            )
            ml_allocator.record_sample(features, actual_ticks)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

allocator = TaskAllocator()
