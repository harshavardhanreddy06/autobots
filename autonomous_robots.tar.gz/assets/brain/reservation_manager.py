"""
brain/reservation_manager.py — Space-Time Segment AND Node Ownership

PURPOSE:
    The Reservation Manager is the final authority on who owns which road
    segment AND which intersection node during which time window.

    TWO LAYERS OF PROTECTION:
        1. Segment reservations  — no two vehicles share an edge at the same time
        2. Node reservations     — no two vehicles are at the same intersection
                                   point within INTERSECTION_CLEAR_TICKS of each other

    The node layer is the critical fix for visible collisions. Even if two vehicles
    traverse different segments, if both segments arrive at the same intersection node
    at the same tick they will appear to collide visually. The node reservation enforces
    a minimum tick gap between any two arrivals/departures at every node.

HOW NODE RESERVATIONS WORK:
    When vehicle A is scheduled to pass through node N at tick T:
        → Node N is reserved from tick T-INTERSECTION_CLEAR_TICKS to T+INTERSECTION_CLEAR_TICKS
        → Any other vehicle that tries to enter/exit node N in that window gets a conflict
        → The departure scheduler finds a later departure that avoids that window
        → Result: vehicles pass through intersections one-at-a-time with a visible gap

    For a 4-way intersection with 4 bots all arriving at the same tick:
        Bot 1: passes at tick 100 → node locked [92, 108]
        Bot 2: earliest at tick 108 → node locked [100, 116]
        Bot 3: earliest at tick 116 → node locked [108, 124]
        Bot 4: earliest at tick 124 → node locked [116, 132]

    Each bot departs with an 8-tick delay relative to the previous — they pass
    through one-by-one, visibly separate.

SEGMENT RESERVATIONS (unchanged):
    Key:   segment_id (e.g., "1_0__2_0")
    Value: list of (enter_tick, exit_tick, vehicle_id) tuples
    Overlap condition: A.enter < B.exit AND A.exit > B.enter

NODE RESERVATIONS:
    Key:   node_id (e.g., "3_2")
    Value: list of (arrive_tick, clear_tick, vehicle_id) tuples
    Where: clear_tick = arrive_tick + INTERSECTION_CLEAR_TICKS
"""

from __future__ import annotations
from collections import defaultdict
from typing import Optional
from config import GC_KEEP_TICKS, INTERSECTION_CLEAR_TICKS
from core.models import ScheduleEntry


class ReservationManager:
    """
    Manages space-time occupancy of all road segments AND intersection nodes.

    Internal structure:
        _table[segment_id] = [(enter_tick, exit_tick, vehicle_id), ...]
        _nodes[node_id]    = [(arrive_tick, clear_tick, vehicle_id), ...]
    """

    def __init__(self):
        # Segment reservations
        self._table: dict = defaultdict(list)
        # Node reservations — the key new layer
        self._nodes: dict = defaultdict(list)

    # ─── Commit ───────────────────────────────────────────

    def commit(self, vehicle_id: str, schedule: list) -> bool:
        """
        Commit a vehicle's approved schedule to the reservation table.

        Commits BOTH segment reservations AND node reservations.
        Node reservations are derived from each segment's to_node arrival tick.

        IMPORTANT: Call AFTER collision predictor confirms schedule is clean.

        Args:
            vehicle_id: the vehicle claiming these segments
            schedule:   list of ScheduleEntry

        Returns:
            True if committed successfully, False if conflict detected
        """
        # Final safety check on segments
        for entry in schedule:
            owner = self._check_segment_overlap(
                entry.segment_id,
                entry.enter_tick,
                entry.exit_tick,
                exclude_vid=vehicle_id
            )
            if owner:
                print(f"[Reservation] SAFETY VIOLATION (seg): {vehicle_id} conflicts with "
                      f"{owner} on {entry.segment_id} [{entry.enter_tick}-{entry.exit_tick}]")
                return False

        # Final safety check on nodes
        for entry in schedule:
            node_owner = self._check_node_overlap(
                entry.to_node,
                entry.exit_tick,
                exclude_vid=vehicle_id
            )
            if node_owner:
                print(f"[Reservation] SAFETY VIOLATION (node): {vehicle_id} conflicts with "
                      f"{node_owner} at node {entry.to_node} @tick {entry.exit_tick}")
                return False

        # Commit all segment reservations
        for entry in schedule:
            self._table[entry.segment_id].append(
                (entry.enter_tick, entry.exit_tick, vehicle_id)
            )

        # Commit node reservations for every node touched in the schedule
        # First node: from_node of first segment (departure node)
        if schedule:
            first = schedule[0]
            self._nodes[first.from_node].append((
                first.enter_tick - INTERSECTION_CLEAR_TICKS,
                first.enter_tick + INTERSECTION_CLEAR_TICKS,
                vehicle_id
            ))
        # All subsequent nodes: to_node of each segment (arrival nodes)
        for entry in schedule:
            arrive = entry.exit_tick
            self._nodes[entry.to_node].append((
                arrive - INTERSECTION_CLEAR_TICKS,
                arrive + INTERSECTION_CLEAR_TICKS,
                vehicle_id
            ))

        return True

    # ─── Release ──────────────────────────────────────────

    def release(self, vehicle_id: str) -> int:
        """
        Remove ALL reservations (segment + node) owned by this vehicle.

        Args:
            vehicle_id: the vehicle whose reservations to remove

        Returns:
            Total number of entries removed
        """
        count = 0

        # Release segment reservations
        for seg in self._table:
            before = len(self._table[seg])
            self._table[seg] = [
                (e, x, v) for e, x, v in self._table[seg] if v != vehicle_id
            ]
            count += before - len(self._table[seg])

        # Release node reservations
        for node in self._nodes:
            before = len(self._nodes[node])
            self._nodes[node] = [
                (a, c, v) for a, c, v in self._nodes[node] if v != vehicle_id
            ]
            count += before - len(self._nodes[node])

        return count

    # ─── Query — Segment ──────────────────────────────────

    def check_conflict(self, segment_id: str, enter_tick: int,
                       exit_tick: int, exclude_vid: str = None) -> Optional[str]:
        """
        Check if a proposed segment occupancy conflicts with any existing reservation.

        Args:
            segment_id:   the segment to check
            enter_tick:   proposed entry time
            exit_tick:    proposed exit time
            exclude_vid:  ignore this vehicle's own reservations

        Returns:
            vehicle_id of conflicting vehicle, or None if clear
        """
        return self._check_segment_overlap(segment_id, enter_tick, exit_tick, exclude_vid)

    def check_node_conflict(self, node_id: str, arrive_tick: int,
                            exclude_vid: str = None) -> Optional[str]:
        """
        Check if a vehicle arriving at node_id at arrive_tick would conflict
        with any existing node reservation within INTERSECTION_CLEAR_TICKS.

        Args:
            node_id:     the intersection node being checked
            arrive_tick: tick when the vehicle reaches this node
            exclude_vid: ignore this vehicle's own reservations

        Returns:
            vehicle_id of conflicting vehicle, or None if clear
        """
        return self._check_node_overlap(node_id, arrive_tick, exclude_vid)

    def density(self, segment_id: str, from_tick: int, to_tick: int) -> int:
        """
        Count how many vehicles have reservations on this segment within time window.
        Used by Route Planner (density-weighted A*) and Speed Coordinator.
        """
        count = 0
        for e, x, v in self._table.get(segment_id, []):
            if e < to_tick and x > from_tick:
                count += 1
        return count

    def get_owner(self, segment_id: str, at_tick: int) -> Optional[str]:
        """
        Return the vehicle_id that owns this segment at the given tick.
        Used by the deadlock detector.
        """
        for e, x, v in self._table.get(segment_id, []):
            if e <= at_tick < x:
                return v
        return None

    def segments_for_vehicle(self, vehicle_id: str) -> list:
        """Return all segment_ids currently reserved by this vehicle."""
        result = []
        for seg, entries in self._table.items():
            for e, x, v in entries:
                if v == vehicle_id:
                    result.append(seg)
                    break
        return result

    # ─── Garbage Collection ───────────────────────────────

    def gc(self, current_tick: int) -> int:
        """
        Delete all stale reservations (segment + node) past their exit/clear tick.

        Args:
            current_tick: current simulation tick

        Returns:
            Number of entries deleted
        """
        cutoff = current_tick - GC_KEEP_TICKS
        count = 0

        # GC segments
        for seg in list(self._table.keys()):
            before = len(self._table[seg])
            self._table[seg] = [
                (e, x, v) for e, x, v in self._table[seg] if x > cutoff
            ]
            count += before - len(self._table[seg])
            if not self._table[seg]:
                del self._table[seg]

        # GC nodes
        for node in list(self._nodes.keys()):
            before = len(self._nodes[node])
            self._nodes[node] = [
                (a, c, v) for a, c, v in self._nodes[node] if c > cutoff
            ]
            count += before - len(self._nodes[node])
            if not self._nodes[node]:
                del self._nodes[node]

        return count

    def total_entries(self) -> int:
        """Total reservation entries (segments + nodes) for diagnostics."""
        seg_count  = sum(len(v) for v in self._table.values())
        node_count = sum(len(v) for v in self._nodes.values())
        return seg_count + node_count

    # ─── Internal ─────────────────────────────────────────

    def _check_segment_overlap(self, segment_id: str, enter: int,
                               exit_: int, exclude_vid: str) -> Optional[str]:
        """Standard interval overlap check for segment reservations."""
        for e, x, v in self._table.get(segment_id, []):
            if v == exclude_vid:
                continue
            if enter < x and exit_ > e:
                return v
        return None

    def _check_node_overlap(self, node_id: str, arrive_tick: int,
                            exclude_vid: str) -> Optional[str]:
        """
        Check if arriving at node_id at arrive_tick conflicts with any
        existing node reservation within the INTERSECTION_CLEAR_TICKS window.

        Conflict condition: another vehicle's [arrive-CLEAR, arrive+CLEAR] window
        overlaps with this vehicle's arrive_tick.
        """
        for a, c, v in self._nodes.get(node_id, []):
            if v == exclude_vid:
                continue
            # Our arrival tick falls inside their locked window [a, c]
            if a <= arrive_tick <= c:
                return v
        return None


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

reservations = ReservationManager()
