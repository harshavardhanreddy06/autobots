"""
brain/decision_engine.py — 6-Level Conflict Resolution Hierarchy

PURPOSE:
    This is the intelligence core of the Central Brain. When a vehicle
    needs a route and conflicts exist, the Decision Engine tries 6
    resolution strategies in escalating order:

    Level 1 — Departure Delay:
        Search for a later departure tick where the same route is conflict-free.
        Cheapest resolution. Works for most conflicts.

    Level 2 — Speed Adjustment:
        Generate a density-weighted speed profile that shifts the vehicle's
        time-range on each segment, potentially eliminating overlaps.

    Level 3 — Lane Propagation:
        If the new speed profile still conflicts, cascade the adjustment
        to following vehicles on the same road segments.

    Level 4 — Throughput Optimizer:
        Ask the optimizer to reshuffle existing schedules globally.
        Expensive but can unlock deadlocked situations.

    Level 5 — Reroute:
        Plan a completely new route that avoids the conflicting segments.
        Always finds a solution unless the graph is completely blocked.

    Level 6 — Emergency Stop:
        If levels 1-5 all fail, issue a temporary stop instruction.
        Vehicle waits for MAX_DEPARTURE_DELAY ticks and retries.
        This should almost never happen in normal operation.

DESIGN:
    The engine tries each level in order and returns the FIRST successful
    schedule. This minimizes disruption — a departure delay is far
    less disruptive than a full reroute.

    Returns (schedule, level_used) where level_used ∈ {1,2,3,4,5,6}.
    The metrics tracker counts how often each level is used.
"""

from __future__ import annotations
from typing import Optional
from config import MAX_DEPARTURE_DELAY
from core.models import ConflictEvent
from brain.brain_logger import brain_log
from brain.schedule_builder import schedule_builder
from brain.collision_predictor import collision_pred
from brain.departure_scheduler import departure_scheduler
from brain.speed_coordinator import speed_coordinator
from brain.lane_propagation import lane_propagation
from brain.route_planner import route_planner
from brain.reservation_manager import reservations
from brain.metrics_tracker import metrics


class DecisionEngine:
    """
    6-level conflict resolution hierarchy.

    Called by CentralBrain after initial collision detection.
    Tries each level in order, returning the first conflict-free schedule.
    """

    def resolve(self, vehicle_id: str, route: list, initial_schedule: list,
                conflicts: list, current_tick: int,
                task_priority: str = "NORMAL",
                task_manager=None) -> tuple:
        """
        Attempt conflict resolution using 6-level hierarchy.

        Args:
            vehicle_id:      the vehicle needing a schedule
            route:           the planned route (list of node_ids)
            initial_schedule: schedule that has conflicts
            conflicts:       list of ConflictEvent from collision predictor
            current_tick:    current simulation tick
            task_priority:   task priority ("HIGH" | "NORMAL" | "LOW")
            task_manager:    TaskManager reference for priority filtering

        Returns:
            (resolved_schedule, level_used) where:
                - resolved_schedule is a conflict-free list of ScheduleEntry, or None
                - level_used is an int 1-6 indicating which level resolved it
            Returns (None, 6) if all levels failed (emergency stop).
        """

        # ─────────────────────────────────────────────────
        # LEVEL 1a: SHORT Departure Delay (max 10 ticks)
        # Try a tiny nudge first — the cheapest fix for near-miss timing.
        # Small window so we quickly escalate to speed adjustment.
        # ─────────────────────────────────────────────────
        import itertools
        SHORT_DELAY = 10
        for delay in range(SHORT_DELAY + 1):
            candidate_tick = current_tick + delay
            sched_try = schedule_builder.build(route, candidate_tick, None)
            if task_manager:
                cf = collision_pred.predict_with_priority(
                    sched_try, vehicle_id, task_priority, task_manager)
            else:
                cf = collision_pred.predict(sched_try, vehicle_id)
            if not cf:
                metrics.level_1_departures += 1
                brain_log(f"L1: {vehicle_id} departs +{delay}t")
                return sched_try, 1

        # ─────────────────────────────────────────────────
        # LEVEL 2: Speed Adjustment
        # Build a density-weighted speed profile — this changes the time
        # each segment occupies, potentially avoiding all conflicts without
        # any departure delay at all.
        # ─────────────────────────────────────────────────
        speed_profile = speed_coordinator.generate(route, current_tick)
        sched_l2 = schedule_builder.build(route, current_tick, speed_profile)
        remaining_conflicts = collision_pred.predict(sched_l2, exclude_vid=vehicle_id)

        if not remaining_conflicts:
            metrics.level_2_speed += 1
            brain_log(f"L2: {vehicle_id} speed-adjusted — no delay")
            return sched_l2, 2

        # Try speed-adjusted schedule with a small departure nudge (up to 10 ticks)
        for delay in range(1, SHORT_DELAY + 1):
            candidate_tick = current_tick + delay
            sched_try = schedule_builder.build(route, candidate_tick, speed_profile)
            cf = collision_pred.predict(sched_try, exclude_vid=vehicle_id)
            if not cf:
                metrics.level_2_speed += 1
                brain_log(f"L2: {vehicle_id} speed+delay +{delay}t")
                return sched_try, 2

        # ─────────────────────────────────────────────────
        # LEVEL 3: Lane Propagation + Speed
        # Try propagating speed slowdown to followers.
        # ─────────────────────────────────────────────────
        propagated = lane_propagation.propagate(vehicle_id, sched_l2, depth=0)
        if propagated > 0:
            remaining = collision_pred.predict(sched_l2, exclude_vid=vehicle_id)
            if not remaining:
                metrics.level_3_propagation += 1
                brain_log(f"L3: {vehicle_id} propagated to {propagated} followers")
                return sched_l2, 3

        # ─────────────────────────────────────────────────
        # LEVEL 4: Extended Departure Delay (up to MAX_DEPARTURE_DELAY)
        # Speed adjustment didn't work. Now allow a longer wait window.
        # ─────────────────────────────────────────────────
        dep_tick2, sched_l4 = departure_scheduler.find_clean_departure(
            route=route,
            earliest_tick=current_tick + SHORT_DELAY + 1,
            speed_profile=speed_profile,
            exclude_vid=vehicle_id,
        )
        if dep_tick2 is not None and sched_l4 is not None:
            metrics.level_4_optimiser += 1
            brain_log(f"L4: {vehicle_id} extended delay @+{dep_tick2 - current_tick}t")
            return sched_l4, 4

        # ─────────────────────────────────────────────────
        # LEVEL 5: Reroute
        # Plan a new route that avoids the conflicting segments entirely.
        # ─────────────────────────────────────────────────
        blocked_segs = {c.segment_id for c in conflicts}
        if route and len(route) >= 2:
            new_route = route_planner.plan_around_segments(
                start_node=route[0],
                end_node=route[-1],
                blocked_segs=blocked_segs,
                current_tick=current_tick
            )
            if new_route and new_route != route:
                alt_profile = speed_coordinator.generate(new_route, current_tick)
                dep_tick3, sched_l5 = departure_scheduler.find_clean_departure(
                    route=new_route,
                    earliest_tick=current_tick,
                    speed_profile=alt_profile,
                    exclude_vid=vehicle_id,
                )
                if dep_tick3 is not None and sched_l5 is not None:
                    metrics.level_5_reroutes += 1
                    brain_log(f"L5: {vehicle_id} rerouted via {new_route}")
                    return sched_l5, 5

        # ─────────────────────────────────────────────────
        # LEVEL 6: Emergency Stop
        # ─────────────────────────────────────────────────
        metrics.level_6_emergency += 1
        metrics.near_misses += 1
        brain_log(f"L6: {vehicle_id} EMERGENCY STOP — will retry")
        return None, 6


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

decision_engine = DecisionEngine()
