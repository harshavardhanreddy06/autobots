"""
brain/departure_scheduler.py — Level 1 Conflict Resolution: Departure Delay

PURPOSE:
    The cheapest conflict resolution strategy: delay the vehicle's departure
    by a few ticks so its path no longer overlaps with existing reservations.

    This resolves the majority of conflicts because most conflicts are
    temporal — two vehicles want to use the same segment at the same time,
    but if one departs a few ticks later, the segment is clear.

HOW IT WORKS:
    1. Start with the current tick (no delay)
    2. Build the schedule starting at that tick
    3. Check for conflicts
    4. If conflicts found, try current_tick + 1, then + 2, ... up to MAX_DEPARTURE_DELAY
    5. Return the first departure tick that produces a conflict-free schedule

    This is O(MAX_DEPARTURE_DELAY × schedule_length) worst case.
    With MAX_DEPARTURE_DELAY=120 and typical schedule_length=5, that's 600 ops —
    trivially fast for a 60fps simulation.

WHEN THIS IS USED:
    Level 1 of the Decision Engine.
    If no clean slot found within MAX_DEPARTURE_DELAY, escalate to Level 2.

METRICS:
    Every successful departure delay increments metrics.level_1_departures.
    The UI shows how often each level is used as a histogram bar.
"""

from __future__ import annotations
from typing import Optional
from config import MAX_DEPARTURE_DELAY
from brain.schedule_builder import schedule_builder
from brain.collision_predictor import collision_pred


class DepartureScheduler:
    """
    Finds the earliest departure tick that produces a conflict-free schedule.

    Works by building the schedule at each candidate departure tick and
    checking it against the Reservation Manager. First clean tick wins.
    """

    def find_clean_departure(self, route: list, earliest_tick: int,
                             speed_profile: Optional[list],
                             exclude_vid: str = None,
                             task_manager=None,
                             task_priority: str = "NORMAL") -> tuple:
        """
        Search for the first conflict-free departure time.

        Tries departure at earliest_tick, earliest_tick+1, ..., earliest_tick+MAX_DEPARTURE_DELAY.
        Returns the first one that produces a schedule with no conflicts.

        Args:
            route:          ordered list of node_ids (the path to check)
            earliest_tick:  first candidate departure tick (usually current_tick)
            speed_profile:  speed multipliers for each segment (or None for 1.0)
            exclude_vid:    vehicle being scheduled (ignore its own reservations)
            task_manager:   for priority-filtered conflict checking (can be None)
            task_priority:  priority of the task ("HIGH" | "NORMAL" | "LOW")

        Returns:
            (departure_tick, schedule) if clean slot found
            (None, None) if no clean slot found within MAX_DEPARTURE_DELAY
        """
        for delay in range(MAX_DEPARTURE_DELAY + 1):
            candidate_tick = earliest_tick + delay

            # Build schedule starting at this candidate tick
            schedule = schedule_builder.build(route, candidate_tick, speed_profile)

            # Check for conflicts (with priority filtering if task_manager provided)
            if task_manager:
                conflicts = collision_pred.predict_with_priority(
                    schedule, exclude_vid, task_priority, task_manager
                )
            else:
                conflicts = collision_pred.predict(schedule, exclude_vid)

            if not conflicts:
                # Found a clean departure time
                return candidate_tick, schedule

        # No clean slot within the window
        return None, None

    def earliest_possible(self, route: list, earliest_tick: int,
                          exclude_vid: str = None) -> int:
        """
        Quick scan: return the first tick with no conflicts.
        Simpler version for the throughput optimizer.

        Returns earliest_tick if clear, otherwise searches up to MAX_DEPARTURE_DELAY.
        Returns -1 if no clear slot found.
        """
        for delay in range(MAX_DEPARTURE_DELAY + 1):
            t = earliest_tick + delay
            schedule = schedule_builder.build(route, t)
            if not collision_pred.has_conflict(schedule, exclude_vid):
                return t
        return -1


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

departure_scheduler = DepartureScheduler()
