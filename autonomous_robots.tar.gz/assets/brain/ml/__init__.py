"""
brain/ml/__init__.py — ML Models Package

Exports the two live ML model singletons used by the brain:
    - ml_allocator  : Smart Task Allocator (XGBoost regression)
    - ml_speed      : Adaptive Speed Coordinator (numpy MLP)

Both are imported as singletons so that the brain modules only need:
    from brain.ml import ml_allocator, ml_speed
"""

from brain.ml.allocator_model import ml_allocator
from brain.ml.speed_model import ml_speed

__all__ = ["ml_allocator", "ml_speed"]
