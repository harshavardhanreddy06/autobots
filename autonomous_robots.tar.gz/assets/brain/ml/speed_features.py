"""
brain/ml/speed_features.py — Feature Extraction for Adaptive Speed Coordinator

PURPOSE:
    Converts raw segment state into a numeric feature vector for the
    neural network that predicts the optimal speed multiplier.

FEATURE VECTOR (8 features, in fixed order):
    [0]  density_now    — reservation density: current tick → tick+LOOKAHEAD
    [1]  density_near   — reservation density: tick+50 → tick+150
    [2]  density_far    — reservation density: tick+150 → tick+400
    [3]  is_near_station — 1.0 if to_node is within BUFFER_RADIUS of a station
    [4]  is_junction    — 1.0 if to_node has 3 or more outgoing edges (intersection)
    [5]  utilisation    — fleet utilisation at time of query (0.0–1.0)
    [6]  queue_size_norm — pending tasks normalised by VEHICLE_MAX
    [7]  tick_cycle_norm — (current_tick % 300) / 300.0

LABEL (what the model is trained to predict):
    speed_mult — the optimal multiplier in [MIN_SPEED_MULT, 1.0]
    Initially bootstrapped from the formula output; refined over time.
"""

from __future__ import annotations
from config import LOOKAHEAD_TICKS, VEHICLE_MAX


def build_features(segment_id: str,
                   to_node: str,
                   current_tick: int,
                   is_near_station: bool,
                   fleet_utilisation: float,
                   fleet_queue_size: int) -> list:
    """
    Build the 8-element feature vector for one segment.

    Args:
        segment_id:        e.g. "2_0__3_0"
        to_node:           destination node of this segment
        current_tick:      simulation tick
        is_near_station:   True if to_node is close to a pickup/drop station
        fleet_utilisation: fraction of fleet currently active
        fleet_queue_size:  number of pending tasks

    Returns:
        List of 8 floats.
    """
    from brain.reservation_manager import reservations
    from brain.road_graph import graph

    # [0] Current density
    density_now = float(reservations.density(
        segment_id, current_tick, current_tick + LOOKAHEAD_TICKS
    ))

    # [1] Near-future density (50–150 ticks out)
    density_near = float(reservations.density(
        segment_id, current_tick + 50, current_tick + 150
    ))

    # [2] Far-future density (150–400 ticks out)
    density_far = float(reservations.density(
        segment_id, current_tick + 150, current_tick + 400
    ))

    # [3] Station proximity
    near_station = 1.0 if is_near_station else 0.0

    # [4] Junction entry: to_node has 3+ neighbours → intersection
    try:
        is_junction = 1.0 if len(graph.neighbors(to_node)) >= 3 else 0.0
    except Exception:
        is_junction = 0.0

    # [5] Fleet utilisation
    util = float(fleet_utilisation)

    # [6] Queue size normalised
    queue_norm = float(fleet_queue_size) / max(1, VEHICLE_MAX)

    # [7] Tick cycle normalised
    tick_norm = float(current_tick % 300) / 300.0

    return [
        density_now,
        density_near,
        density_far,
        near_station,
        is_junction,
        util,
        queue_norm,
        tick_norm,
    ]
