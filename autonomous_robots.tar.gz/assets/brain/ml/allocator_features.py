"""
brain/ml/allocator_features.py — Feature Extraction for Smart Task Allocator

PURPOSE:
    Converts raw simulation state into a numeric feature vector that the
    XGBoost model can use to predict 'actual_ticks_to_reach_pickup'.

FEATURE VECTOR (10 features, in fixed order):
    [0]  euclidean_dist_px       — straight-line pixels between bot and pickup
    [1]  road_density_on_path    — avg reservation density on the connecting path
    [2]  bot_state_encoded       — 0=IDLE, 1=PARKED, 2=MOVING_TO_PARKING
    [3]  bot_pending_count       — number of tasks already queued on this bot
    [4]  fleet_queue_size        — total pending tasks in system
    [5]  fleet_utilisation       — fraction of fleet currently moving (0.0–1.0)
    [6]  task_priority_weight    — HIGH=3, NORMAL=2, LOW=1
    [7]  tick_cycle              — current_tick % 300 (captures traffic patterns)
    [8]  bot_x_norm              — bot x position normalised to [0,1]
    [9]  bot_y_norm              — bot y position normalised to [0,1]

LABEL (what the model predicts):
    actual_ticks — ticks from assignment until the bot physically reaches pickup

NOTE:
    Feature order is fixed. Adding features requires retraining the model.
    Any change here must be reflected in allocator_model.FEATURE_NAMES.
"""

from __future__ import annotations
import math
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from core.models import VehicleRecord, Task

# Map state names → numeric code
_STATE_CODES = {
    "IDLE":              0,
    "PARKED":            1,
    "MOVING_TO_PARKING": 2,
}

# Map/screen dimensions for normalisation (loaded from config)
_MAP_W_PX: float = 1330.0
_MAP_H_PX: float = 982.0


def set_map_dimensions(w_px: float, h_px: float) -> None:
    """Call once from main.py after loading map_config to set normalisation bounds."""
    global _MAP_W_PX, _MAP_H_PX
    _MAP_W_PX = float(w_px)
    _MAP_H_PX = float(h_px)


def build_features(rec: "VehicleRecord",
                   pickup_x: float,
                   pickup_y: float,
                   current_tick: int,
                   task: Optional["Task"],
                   route_density: float = 0.0,
                   fleet_queue_size: int = 0,
                   fleet_utilisation: float = 0.0) -> list:
    """
    Build a 10-element feature vector for one (bot, task) candidate pair.

    Args:
        rec:               VehicleRecord of the candidate bot
        pickup_x/y:        pixel coords of the task pickup station
        current_tick:      current simulation tick
        task:              the Task object (for priority)
        route_density:     average segment density on the bot→pickup path
                           (computed by allocator_model before calling this)
        fleet_queue_size:  number of tasks currently PENDING
        fleet_utilisation: fraction of fleet actively moving

    Returns:
        List of 10 floats, in the fixed order above.
    """
    from config import PRIORITY_WEIGHT

    # [0] Euclidean distance
    euclid = math.hypot(rec.x_px - pickup_x, rec.y_px - pickup_y)

    # [1] Road density (caller queries reservation manager across route)
    density = float(route_density)

    # [2] Bot state encoded
    state_code = _STATE_CODES.get(rec.state.name, 0)

    # [3] Bot pending queue length
    pending_count = len(rec.pending_task_ids) if rec.pending_task_ids else 0

    # [4] Fleet queue size
    queue_size = float(fleet_queue_size)

    # [5] Fleet utilisation
    utilisation = float(fleet_utilisation)

    # [6] Task priority
    priority = float(PRIORITY_WEIGHT.get(task.priority, 2)) if task else 2.0

    # [7] Tick cycle (captures repeating traffic patterns)
    tick_cycle = float(current_tick % 300)

    # [8-9] Normalised bot position
    bot_x_norm = rec.x_px / _MAP_W_PX
    bot_y_norm = rec.y_px / _MAP_H_PX

    return [
        euclid,
        density,
        float(state_code),
        float(pending_count),
        queue_size,
        utilisation,
        priority,
        tick_cycle,
        bot_x_norm,
        bot_y_norm,
    ]
