"""
brain/ml/speed_model.py — Adaptive Speed Coordinator (Pure Numpy MLP)

PURPOSE:
    A lightweight 2-layer neural network that replaces the fixed formula
        mult = max(MIN_SPEED_MULT, 1.0 - density * DENSITY_WEIGHT)
    with a learned function that accounts for near/far future density,
    junction proximity, station zones, and global fleet state.

ARCHITECTURE:
    Input  (8)  →  Dense(16, ReLU)  →  Dense(8, ReLU)  →  Dense(1, Sigmoid)
    Output is scaled to [MIN_SPEED_MULT, 1.0]:
        mult = MIN_SPEED_MULT + sigmoid(out) * (1.0 - MIN_SPEED_MULT)

WHY NUMPY (not PyTorch/TensorFlow):
    - Called up to 80 times per tick (4 segments × 20 bots)
    - Must complete in < 16ms total (60fps budget)
    - Numpy matrix multiply is < 0.1ms per call
    - No heavy framework startup, no GPU needed
    - Zero external dependencies beyond numpy

TRAINING:
    - Bootstrapped with labels from the formula (first 100 ticks)
    - Labels are refined over time: segments that had collisions get
      lower target multipliers; collision-free segments stay as-is
    - Mini-batch gradient descent (SGD), batch_size=32, lr=0.01
    - Trains in < 50ms on 500 samples — fully within a single frame pause

LIFECYCLE:
    Same as allocator_model: collect → maybe_train → predict (or fallback)
"""

from __future__ import annotations
import os
import sys
from collections import deque
from typing import Optional

# Detect browser / WASM environment — no filesystem in the browser sandbox
_IS_WEB = sys.platform in ("emscripten", "wasi") or os.environ.get("PYGBAG") == "1"

# ── Numpy with graceful fallback ──────────────────────────
try:
    import numpy as np
    _NUMPY_AVAILABLE = True
except ImportError:
    _NUMPY_AVAILABLE = False
    print("[ML] numpy not installed — Adaptive Speed Model disabled.")

from config import MIN_SPEED_MULT

# ── Constants ─────────────────────────────────────────────
N_FEATURES     = 8
HIDDEN1        = 16
HIDDEN2        = 8
MIN_SAMPLES    = 100    # samples before first train
TRAIN_INTERVAL = 300    # retrain every N ticks
BUFFER_SIZE    = 1000   # rolling sample window
LR             = 0.01   # learning rate
EPOCHS         = 20     # epochs per training run
BATCH_SIZE     = 32

MODEL_PATH = os.path.join(
    os.path.dirname(__file__), "model_data", "speed_v1.npz"
)


class AdaptiveSpeedModel:
    """
    2-layer MLP predicting per-segment speed multiplier.

    Usage:
        ml_speed.record_sample(features, formula_mult, had_collision)
        ml_speed.maybe_train(current_tick)
        mult = ml_speed.predict(features)   # returns float in [MIN_SPEED_MULT, 1.0]
        if not ml_speed.is_ready(): fallback_formula()
    """

    def __init__(self):
        self._ready: bool = False
        self._buffer: deque = deque(maxlen=BUFFER_SIZE)
        self._last_train_tick: int = -TRAIN_INTERVAL
        self._train_count: int = 0
        self._last_loss: float = 0.0

        # Network weights — initialised with He initialisation
        if _NUMPY_AVAILABLE:
            self._init_weights()
            # Try loading saved weights (desktop only)
            if not _IS_WEB and os.path.exists(MODEL_PATH):
                try:
                    data = np.load(MODEL_PATH)
                    self.W1 = data["W1"]
                    self.b1 = data["b1"]
                    self.W2 = data["W2"]
                    self.b2 = data["b2"]
                    self.W3 = data["W3"]
                    self.b3 = data["b3"]
                    self._ready = True
                    print(f"[ML Speed] Loaded saved weights from {MODEL_PATH}")
                except Exception as e:
                    print(f"[ML Speed] Could not load weights: {e}")
                    self._init_weights()

    def _init_weights(self) -> None:
        """He initialisation for ReLU layers."""
        rng = np.random.default_rng(42)
        self.W1 = rng.standard_normal((N_FEATURES, HIDDEN1)).astype(np.float32) * np.sqrt(2.0 / N_FEATURES)
        self.b1 = np.zeros(HIDDEN1, dtype=np.float32)
        self.W2 = rng.standard_normal((HIDDEN1, HIDDEN2)).astype(np.float32) * np.sqrt(2.0 / HIDDEN1)
        self.b2 = np.zeros(HIDDEN2, dtype=np.float32)
        self.W3 = rng.standard_normal((HIDDEN2, 1)).astype(np.float32) * np.sqrt(2.0 / HIDDEN2)
        self.b3 = np.zeros(1, dtype=np.float32)

    # ── Public API ────────────────────────────────────────

    def is_ready(self) -> bool:
        return self._ready and _NUMPY_AVAILABLE

    def record_sample(self, features: list,
                      formula_mult: float,
                      had_collision: bool = False) -> None:
        """
        Record one training sample.

        Label logic:
          - If this segment had a confirmed collision → push label lower
            (the formula was too fast — we should have been slower)
          - Otherwise → use the formula output as the label
            (bootstrap from rule-based knowledge)

        As the model trains more, actual outcomes replace formula labels.

        Args:
            features:      8-element feature list
            formula_mult:  the value the formula would have returned
            had_collision: True if a collision was detected on this segment
        """
        if not _NUMPY_AVAILABLE:
            return
        # Adjust label: collision → reduce target by 0.1 (floor at MIN_SPEED_MULT)
        label = formula_mult
        if had_collision:
            label = max(MIN_SPEED_MULT, formula_mult - 0.1)

        if len(features) == N_FEATURES:
            self._buffer.append((features, label))

    def maybe_train(self, current_tick: int) -> None:
        """
        Trigger a training run if conditions are met. Called from brain tick.
        """
        if not _NUMPY_AVAILABLE:
            return
        if len(self._buffer) < MIN_SAMPLES:
            return
        if current_tick - self._last_train_tick < TRAIN_INTERVAL:
            return
        self._train(current_tick)

    def predict(self, features: list) -> float:
        """
        Forward pass: predict speed multiplier for one segment.

        Args:
            features: 8-element list

        Returns:
            Float in [MIN_SPEED_MULT, 1.0]
        """
        if not self.is_ready():
            return 0.0
        try:
            x = np.array(features, dtype=np.float32).reshape(1, -1)
            out = self._forward(x)
            # Scale sigmoid output to [MIN_SPEED_MULT, 1.0]
            mult = MIN_SPEED_MULT + float(out[0, 0]) * (1.0 - MIN_SPEED_MULT)
            return float(np.clip(mult, MIN_SPEED_MULT, 1.0))
        except Exception:
            return 0.0

    @property
    def train_count(self) -> int:
        return self._train_count

    @property
    def sample_count(self) -> int:
        return len(self._buffer)

    @property
    def last_loss(self) -> float:
        return self._last_loss

    # ── Internal forward / backward ───────────────────────

    def _relu(self, x: "np.ndarray") -> "np.ndarray":
        return np.maximum(0.0, x)

    def _sigmoid(self, x: "np.ndarray") -> "np.ndarray":
        return 1.0 / (1.0 + np.exp(-np.clip(x, -20, 20)))

    def _forward(self, x: "np.ndarray") -> "np.ndarray":
        """Forward pass — returns sigmoid output in (0, 1)."""
        h1 = self._relu(x @ self.W1 + self.b1)
        h2 = self._relu(h1 @ self.W2 + self.b2)
        return self._sigmoid(h2 @ self.W3 + self.b3)

    def _train(self, current_tick: int) -> None:
        """
        Mini-batch SGD training loop.
        Labels are in [MIN_SPEED_MULT, 1.0] — normalise to [0, 1] for sigmoid.
        """
        try:
            samples = list(self._buffer)
            X = np.array([s[0] for s in samples], dtype=np.float32)
            y_raw = np.array([s[1] for s in samples], dtype=np.float32).reshape(-1, 1)

            # Normalise labels from [MIN, 1.0] → [0, 1] for sigmoid output
            y = (y_raw - MIN_SPEED_MULT) / (1.0 - MIN_SPEED_MULT)
            y = np.clip(y, 0.0, 1.0)

            n = len(X)
            losses = []

            for epoch in range(EPOCHS):
                idx = np.random.permutation(n)
                X_s, y_s = X[idx], y[idx]

                for i in range(0, n, BATCH_SIZE):
                    xb = X_s[i:i + BATCH_SIZE]
                    yb = y_s[i:i + BATCH_SIZE]

                    # Forward
                    h1     = self._relu(xb @ self.W1 + self.b1)
                    h2     = self._relu(h1 @ self.W2 + self.b2)
                    logits = h2 @ self.W3 + self.b3
                    out    = self._sigmoid(logits)

                    # MSE loss
                    diff = out - yb
                    loss = np.mean(diff ** 2)
                    losses.append(float(loss))

                    # Backward (MSE + sigmoid derivative)
                    d_out  = 2 * diff / len(xb)
                    d_sig  = out * (1 - out) * d_out

                    dW3 = h2.T @ d_sig
                    db3 = d_sig.sum(axis=0)

                    d_h2   = d_sig @ self.W3.T
                    d_h2  *= (h2 > 0)  # ReLU gradient

                    dW2 = h1.T @ d_h2
                    db2 = d_h2.sum(axis=0)

                    d_h1   = d_h2 @ self.W2.T
                    d_h1  *= (h1 > 0)

                    dW1 = xb.T @ d_h1
                    db1 = d_h1.sum(axis=0)

                    # Update weights
                    self.W3 -= LR * dW3
                    self.b3 -= LR * db3
                    self.W2 -= LR * dW2
                    self.b2 -= LR * db2
                    self.W1 -= LR * dW1
                    self.b1 -= LR * db1

            self._last_loss = float(np.mean(losses[-10:])) if losses else 0.0
            self._ready = True
            self._train_count += 1
            self._last_train_tick = current_tick

            # Save weights (desktop only)
            if not _IS_WEB:
                os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
                np.savez(MODEL_PATH,
                         W1=self.W1, b1=self.b1,
                         W2=self.W2, b2=self.b2,
                         W3=self.W3, b3=self.b3)

            print(f"[ML Speed] Train #{self._train_count} @ tick {current_tick}: "
                  f"samples={n}, loss={self._last_loss:.5f}")

        except Exception as e:
            print(f"[ML Speed] Training failed: {e}")


# ── Global singleton ───────────────────────────────────────
ml_speed = AdaptiveSpeedModel()
