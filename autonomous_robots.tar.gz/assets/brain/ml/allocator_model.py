"""
brain/ml/allocator_model.py — Smart Task Allocator (XGBoost Regression)

PURPOSE:
    Replaces the Euclidean distance score in task_allocator.py with a
    prediction of 'actual_ticks_to_reach_pickup'. The bot with the lowest
    predicted ticks wins the task — traffic-aware, not just geometry-aware.

LIFECYCLE:
    1. Simulation starts — model is NOT ready (is_ready() = False)
       task_allocator falls back to Euclidean distance (no change to behaviour)

    2. Every tick, comm_manager records training samples in self._buffer
       when a bot reaches pickup (we know the actual travel ticks)

    3. Every TRAIN_INTERVAL ticks, train() is called automatically
       from central_brain.tick() when MIN_SAMPLES samples have been collected

    4. After first training (needs MIN_SAMPLES=50), is_ready() = True
       task_allocator now uses ML predictions

    5. Model retrains every TRAIN_INTERVAL ticks on rolling window of
       BUFFER_SIZE newest samples (continuous improvement)

FEATURE NAMES (must match allocator_features.build_features() order):
    euclidean_dist, road_density, bot_state, bot_pending, queue_size,
    utilisation, priority, tick_cycle, bot_x_norm, bot_y_norm

FALLBACK:
    If XGBoost is not installed, model silently falls back to disabled mode.
    task_allocator continues using Euclidean distance with zero impact.
"""

from __future__ import annotations
import os
import sys
import pickle
from collections import deque
from typing import Optional

# Detect browser / WASM environment — no filesystem in the browser sandbox
_IS_WEB = sys.platform in ("emscripten", "wasi") or os.environ.get("PYGBAG") == "1"

# ── XGBoost import with graceful fallback ─────────────────
try:
    if _IS_WEB:
        raise ImportError("XGBoost disabled in web/WASM environment")
    import xgboost as xgb
    import numpy as np
    _XGBOOST_AVAILABLE = True
except ImportError:
    _XGBOOST_AVAILABLE = False
    if not _IS_WEB:
        print("[ML] xgboost not installed — Smart Allocator disabled. "
              "Run: pip install xgboost numpy")

# ── Constants ─────────────────────────────────────────────
MIN_SAMPLES    = 50     # minimum samples before first training run
TRAIN_INTERVAL = 300    # retrain every N ticks
BUFFER_SIZE    = 500    # rolling window — keep this many newest samples
MODEL_PATH     = os.path.join(
    os.path.dirname(__file__), "model_data", "allocator_v1.pkl"
)

FEATURE_NAMES = [
    "euclidean_dist",
    "road_density",
    "bot_state",
    "bot_pending",
    "queue_size",
    "utilisation",
    "priority",
    "tick_cycle",
    "bot_x_norm",
    "bot_y_norm",
]


class SmartAllocatorModel:
    """
    XGBoost regression model that predicts actual ticks for a bot to reach pickup.

    Usage:
        ml_allocator.record_sample(features, actual_ticks)  ← called on arrival
        ml_allocator.maybe_train(current_tick)               ← called from brain tick
        predicted = ml_allocator.predict(features)           ← called in allocator
        ready = ml_allocator.is_ready()                      ← fallback guard
    """

    def __init__(self):
        self._model = None           # XGBoost Booster
        self._buffer: deque = deque(maxlen=BUFFER_SIZE)  # (features_list, label)
        self._ready: bool = False
        self._last_train_tick: int = -TRAIN_INTERVAL  # ensures first train at MIN_SAMPLES
        self._train_count: int = 0
        self._last_mae: float = 0.0  # Mean Absolute Error of last training run

        # Try loading a previously saved model (desktop only)
        if _XGBOOST_AVAILABLE and not _IS_WEB and os.path.exists(MODEL_PATH):
            try:
                with open(MODEL_PATH, "rb") as f:
                    self._model = pickle.load(f)
                self._ready = True
                print(f"[ML Allocator] Loaded saved model from {MODEL_PATH}")
            except Exception as e:
                print(f"[ML Allocator] Could not load saved model: {e}")

    # ── Public API ────────────────────────────────────────

    def is_ready(self) -> bool:
        """Returns True if the model has been trained and can make predictions."""
        return self._ready and self._model is not None

    def record_sample(self, features: list, actual_ticks: float) -> None:
        """
        Record one training sample. Called by comm_manager when a bot
        arrives at pickup — we now know the actual ticks it took.

        Args:
            features:     10-element list from allocator_features.build_features()
            actual_ticks: actual ticks from assignment until pickup arrival
        """
        if not _XGBOOST_AVAILABLE:
            return
        if len(features) == len(FEATURE_NAMES) and actual_ticks > 0:
            self._buffer.append((features, actual_ticks))

    def maybe_train(self, current_tick: int) -> None:
        """
        Trigger a training run if conditions are met:
            - XGBoost is available
            - At least MIN_SAMPLES samples collected
            - TRAIN_INTERVAL ticks since last training

        Called from central_brain.tick() every tick.
        """
        if not _XGBOOST_AVAILABLE:
            return
        if len(self._buffer) < MIN_SAMPLES:
            return
        if current_tick - self._last_train_tick < TRAIN_INTERVAL:
            return

        self._train(current_tick)

    def predict(self, features: list) -> float:
        """
        Predict actual_ticks for one (bot, task) candidate.

        Args:
            features: 10-element list from allocator_features.build_features()

        Returns:
            Predicted ticks (positive float), or 0.0 if model not ready.
        """
        if not self.is_ready():
            return 0.0
        try:
            x = np.array([features], dtype=np.float32)
            dm = xgb.DMatrix(x, feature_names=FEATURE_NAMES)
            pred = float(self._model.predict(dm)[0])
            return max(1.0, pred)  # ticks must be positive
        except Exception:
            return 0.0

    def feature_importance(self) -> dict:
        """Return feature importance scores (for UI display). Empty if not trained."""
        if not self.is_ready():
            return {}
        try:
            return self._model.get_score(importance_type="gain")
        except Exception:
            return {}

    @property
    def train_count(self) -> int:
        return self._train_count

    @property
    def sample_count(self) -> int:
        return len(self._buffer)

    @property
    def last_mae(self) -> float:
        return self._last_mae

    # ── Internal ──────────────────────────────────────────

    def _train(self, current_tick: int) -> None:
        """Run XGBoost training on current buffer. Saves model to disk."""
        try:
            samples = list(self._buffer)
            X = np.array([s[0] for s in samples], dtype=np.float32)
            y = np.array([s[1] for s in samples], dtype=np.float32)

            # 80/20 train/validation split
            split = max(1, int(len(X) * 0.8))
            X_train, X_val = X[:split], X[split:]
            y_train, y_val = y[:split], y[split:]

            dtrain = xgb.DMatrix(X_train, label=y_train, feature_names=FEATURE_NAMES)
            dval   = xgb.DMatrix(X_val,   label=y_val,   feature_names=FEATURE_NAMES)

            params = {
                "objective":        "reg:squarederror",
                "eval_metric":      "mae",
                "max_depth":        4,
                "learning_rate":    0.1,
                "n_estimators":     100,
                "subsample":        0.8,
                "colsample_bytree": 0.8,
                "min_child_weight": 3,
                "verbosity":        0,
            }

            self._model = xgb.train(
                params,
                dtrain,
                num_boost_round = 100,
                evals           = [(dval, "val")],
                verbose_eval    = False,
                early_stopping_rounds = 10,
            )

            # Compute MAE on validation set
            preds = self._model.predict(dval)
            self._last_mae = float(np.mean(np.abs(preds - y_val)))

            self._ready = True
            self._train_count += 1
            self._last_train_tick = current_tick

            # Save model to disk (desktop only)
            if not _IS_WEB:
                os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
                with open(MODEL_PATH, "wb") as f:
                    pickle.dump(self._model, f)

            print(f"[ML Allocator] Train #{self._train_count} @ tick {current_tick}: "
                  f"samples={len(samples)}, MAE={self._last_mae:.1f} ticks")

        except Exception as e:
            print(f"[ML Allocator] Training failed: {e}")


# ── Global singleton ───────────────────────────────────────
ml_allocator = SmartAllocatorModel()
