"""
brain/schedule_builder.py — Route to Time-Stamped Schedule Converter

PURPOSE:
    THE single canonical place where a list of node_ids is converted into
    a list of ScheduleEntry objects with precise enter/exit ticks.

    No other module may perform this conversion. The Collision Predictor,
    Reservation Manager, Vehicle Executor, and Decision Engine all use
    schedules produced here. This guarantees consistency — same route +
    same speed profile + same start_tick = same schedule, always.

HOW IT WORKS:
    For each consecutive pair of nodes in the route:
        1. Compute pixel distance between the two node positions
        2. Apply the speed multiplier for that segment
        3. Compute ticks = max(1, round(distance / (BASE_SPEED * speed_mult)))
        4. Create ScheduleEntry(segment_id, from_node, to_node, enter, exit)
        5. Advance tick counter by 'ticks'

SPEED PROFILE:
    A list of floats, one per segment (edge). Each float is a multiplier
    applied to BASE_SPEED for that segment. If not provided, all segments
    use 1.0 (full speed). Speed coordinator generates these profiles.

SEGMENT TIMING EXAMPLE:
    Route: ["1_0", "2_0", "3_0"]
    Segment "1_0__2_0": distance=175px, speed=1.0 → ticks=88, enter=100, exit=188
    Segment "2_0__3_0": distance=175px, speed=0.7 → ticks=125, enter=188, exit=313
"""

from __future__ import annotations
import math
from typing import Optional
from config import BASE_SPEED, MIN_SPEED_MULT
from core.models import ScheduleEntry
from brain.road_graph import graph


class ScheduleBuilder:
    """
    Converts a node route into a time-stamped ScheduleEntry list.

    This is the canonical schedule creation function. Call build() to
    convert any route + speed profile into a complete vehicle schedule.
    """

    def build(self, route: list, start_tick: int,
              speed_profile: Optional[list] = None) -> list:
        """
        Build a complete ScheduleEntry list for a route.

        Args:
            route:         ordered list of node_ids from source to destination
                           e.g., ["1_0", "2_0", "3_0", "3_1"]
            start_tick:    the simulation tick at which the vehicle departs
            speed_profile: optional list of speed multipliers, one per segment.
                           If shorter than route, remaining segments use 1.0.
                           If None, all segments use 1.0.

        Returns:
            List of ScheduleEntry, one per consecutive node pair.
            Empty list if route has fewer than 2 nodes.
        """
        if len(route) < 2:
            return []

        schedule = []
        tick = start_tick

        for i in range(len(route) - 1):
            from_node = route[i]
            to_node   = route[i + 1]

            # Segment identifier (canonical format: "from__to")
            seg_id = f"{from_node}__{to_node}"

            # Speed multiplier for this segment
            mult = 1.0
            if speed_profile and i < len(speed_profile):
                mult = speed_profile[i]
            mult = max(MIN_SPEED_MULT, mult)

            # Pixel distance between the two nodes
            from_px = graph.node_pos(from_node)
            to_px   = graph.node_pos(to_node)
            dist    = math.hypot(to_px[0] - from_px[0], to_px[1] - from_px[1])

            # Ticks to traverse this segment at this speed
            # max(1) ensures no zero-tick segments (would cause division by zero in vehicle)
            ticks = max(1, round(dist / (BASE_SPEED * mult)))

            schedule.append(ScheduleEntry(
                segment_id = seg_id,
                from_node  = from_node,
                to_node    = to_node,
                enter_tick = tick,
                exit_tick  = tick + ticks
            ))

            tick += ticks

        return schedule

    def rebuild_with_delay(self, schedule: list, delay: int) -> list:
        """
        Shift an entire schedule forward by 'delay' ticks.
        Used by Departure Scheduler when searching for a clean departure time.

        Args:
            schedule: original ScheduleEntry list
            delay:    number of ticks to shift forward

        Returns:
            New ScheduleEntry list with all ticks shifted by delay
        """
        if delay == 0:
            return schedule
        return [
            ScheduleEntry(
                segment_id = e.segment_id,
                from_node  = e.from_node,
                to_node    = e.to_node,
                enter_tick = e.enter_tick + delay,
                exit_tick  = e.exit_tick  + delay
            )
            for e in schedule
        ]

    def total_ticks(self, schedule: list) -> int:
        """
        Return the total number of ticks from departure to arrival.

        Args:
            schedule: ScheduleEntry list

        Returns:
            Total duration in ticks, or 0 if schedule is empty
        """
        if not schedule:
            return 0
        return schedule[-1].exit_tick - schedule[0].enter_tick

    def end_tick(self, schedule: list) -> int:
        """Return the exit_tick of the last segment. 0 if empty."""
        if not schedule:
            return 0
        return schedule[-1].exit_tick

    def route_key(self, route: list) -> str:
        """
        Convert a route to a compact string for use as a cache key.
        e.g., ["1_0", "2_0", "3_0"] → "1_0-2_0-3_0"
        """
        return "-".join(route)


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

schedule_builder = ScheduleBuilder()
