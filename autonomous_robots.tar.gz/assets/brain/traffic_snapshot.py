"""
brain/traffic_snapshot.py — System State Snapshot for Analysis

PURPOSE:
    Captures a snapshot of the current simulation state — vehicle positions,
    reservation densities, task queues — for use by the throughput optimizer,
    deadlock detector, and ML data collection.

WHY A SNAPSHOT:
    Modules that need to analyse the system state shouldn't each query
    the Registry and ReservationManager directly. The snapshot provides
    a consistent, single point-in-time view that all analysis modules
    can use without their queries interfering with each other.

CONTENTS:
    busy_segments:   list of (segment_id, density) sorted by congestion
    future_density:  dict of segment_id → expected density for next 200 ticks
    vehicle_states:  dict of vehicle_id → (state, x, y, node_id)
    pending_count:   number of tasks in PENDING state
    active_count:    number of vehicles in MOVING state
"""

from __future__ import annotations
from config import LOOKAHEAD_TICKS, ML_SAMPLE_INTERVAL
from vehicle.vehicle_registry import registry
from brain.reservation_manager import reservations
from brain.metrics_tracker import metrics


class TrafficSnapshot:
    """
    Builds and caches a periodic system-state snapshot.

    collect() is called every ML_SAMPLE_INTERVAL ticks from central_brain.
    The snapshot is cached until the next collection.
    """

    def __init__(self):
        self._last_tick: int = -1
        self._cache: dict = {}

    def collect(self, current_tick: int) -> dict:
        """
        Build a fresh snapshot of system state.

        Args:
            current_tick: current simulation tick

        Returns:
            Dict containing system state summary
        """
        from brain.task_manager import task_mgr

        all_records = registry.snapshot()

        # Vehicle state summary
        vehicle_states = {
            rec.vehicle_id: (rec.state.name, rec.x_px, rec.y_px, rec.node_id)
            for rec in all_records
        }

        # Pending task count
        pending_count = task_mgr.pending_count()
        active_count = sum(
            1 for rec in all_records
            if rec.state.name in ("MOVING_TO_PICKUP", "MOVING_TO_DEST")
        )

        # Segment density for planning horizon
        # We query a representative set of segments
        segment_densities = {}
        # Collect all currently reserved segments
        all_segments = set()
        for rec in all_records:
            if rec.instruction and rec.instruction.schedule:
                for entry in rec.instruction.schedule:
                    all_segments.add(entry.segment_id)

        for seg_id in all_segments:
            density = reservations.density(
                seg_id, current_tick, current_tick + LOOKAHEAD_TICKS
            )
            if density > 0:
                segment_densities[seg_id] = density

        # Top congested segments (for heatmap rendering)
        busy_segments = sorted(
            segment_densities.items(),
            key=lambda x: x[1],
            reverse=True
        )[:20]   # keep top 20

        snap = {
            "tick":           current_tick,
            "vehicle_states": vehicle_states,
            "pending_count":  pending_count,
            "active_count":   active_count,
            "busy_segments":  busy_segments,
            "utilisation":    metrics.fleet_utilisation,
        }

        self._cache = snap
        self._last_tick = current_tick

        # Store ML training sample
        ml_sample = {
            "tick":          current_tick,
            "pending":       pending_count,
            "active":        active_count,
            "utilisation":   metrics.fleet_utilisation,
            "busy_count":    len(busy_segments),
            "top_density":   busy_segments[0][1] if busy_segments else 0,
        }
        metrics.add_congestion_sample(ml_sample)

        return snap

    def get_cached(self) -> dict:
        """Return the most recent snapshot without rebuilding."""
        return self._cache

    def busy_segments(self, current_tick: int, max_count: int = 10) -> list:
        """
        Return list of (segment_id, density) for the most congested segments.
        Used by renderer for heatmap overlay.
        """
        if self._cache:
            return self._cache.get("busy_segments", [])[:max_count]
        return []


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

traffic_snap = TrafficSnapshot()
