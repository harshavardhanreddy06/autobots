"""
brain/collision_predictor.py — Schedule Conflict Detector (Segment + Node)

PURPOSE:
    Given a proposed schedule for vehicle A, checks it against all existing
    reservations for BOTH road segments AND intersection nodes.

    TWO CHECKS RUN FOR EVERY SCHEDULE ENTRY:
        1. Segment check  — does any other vehicle own this edge during [enter, exit]?
        2. Node check     — does any other vehicle arrive at the destination node
                           within INTERSECTION_CLEAR_TICKS of this vehicle?

    WHY NODE CHECKS ARE CRITICAL:
        Without node checks, two vehicles heading toward the same intersection from
        different directions will have non-overlapping segment reservations and pass
        all segment checks — yet visually they collide at the node point.

        The node check catches exactly this: "will two bots be at the same intersection
        at nearly the same time?" If yes → conflict → departure scheduler shifts one
        by INTERSECTION_CLEAR_TICKS ticks → they cross one after another with a gap.

    RESULT:
        4 bots converging on one intersection → each waits its turn → pass
        one-by-one with a clean 8-tick gap between each crossing.

DEBUG ASSERTION:
    If DEBUG_COLLISION_ASSERT is True, a physical distance check runs every tick
    in the main loop. Any pair of vehicles within COLLISION_RADIUS pixels triggers
    metrics.confirmed_collisions += 1 and turns the UI banner red.
    This should always remain 0 if the pipeline is correct.
"""

from __future__ import annotations
from typing import Optional
from config import PRIORITY_WEIGHT
from core.models import ScheduleEntry, ConflictEvent
from brain.reservation_manager import reservations


class CollisionPredictor:
    """
    Checks proposed schedules against existing reservations.
    Now checks BOTH segment conflicts AND node conflicts.
    """

    def predict(self, schedule: list, exclude_vid: str = None,
                task_priority: str = "NORMAL") -> list:
        """
        Check a proposed schedule for segment AND node conflicts.

        Args:
            schedule:       list of ScheduleEntry (the proposed vehicle path)
            exclude_vid:    vehicle_id to ignore (own reservations)
            task_priority:  priority of this task (for future priority filtering)

        Returns:
            List of ConflictEvent. Empty list = conflict-free.
        """
        conflicts = []
        seen_segs = set()   # deduplicate per-segment conflicts

        for entry in schedule:
            # ── 1. Segment conflict check ──────────────────
            if entry.segment_id not in seen_segs:
                blocker_vid = reservations.check_conflict(
                    entry.segment_id,
                    entry.enter_tick,
                    entry.exit_tick,
                    exclude_vid=exclude_vid
                )
                if blocker_vid is not None:
                    conflicts.append(ConflictEvent(
                        segment_id = entry.segment_id,
                        enter_a    = entry.enter_tick,
                        exit_a     = entry.exit_tick,
                        vehicle_b  = blocker_vid,
                        enter_b    = entry.enter_tick,
                        exit_b     = entry.exit_tick,
                        priority_b = "NORMAL"
                    ))
                    seen_segs.add(entry.segment_id)

            # ── 2. Node conflict check (intersection safety) ──
            # Check the destination node at the tick this vehicle arrives there
            node_blocker = reservations.check_node_conflict(
                entry.to_node,
                entry.exit_tick,
                exclude_vid=exclude_vid
            )
            if node_blocker is not None:
                # Use a fake segment_id keyed to the node so the departure
                # scheduler treats it as a genuine conflict
                node_seg_id = f"NODE__{entry.to_node}"
                conflicts.append(ConflictEvent(
                    segment_id = node_seg_id,
                    enter_a    = entry.exit_tick,
                    exit_a     = entry.exit_tick + 1,
                    vehicle_b  = node_blocker,
                    enter_b    = entry.exit_tick,
                    exit_b     = entry.exit_tick + 1,
                    priority_b = "NORMAL"
                ))

        return conflicts

    def predict_with_priority(self, schedule: list, exclude_vid: str,
                              task_priority: str,
                              task_manager) -> list:
        """
        Check schedule for conflicts with full priority information.
        Returns only conflicts where the blocker has EQUAL OR HIGHER priority.

        Checks BOTH segments AND nodes — same as predict() but with priority filtering.

        Args:
            schedule:      proposed ScheduleEntry list
            exclude_vid:   vehicle being scheduled (ignore its own reservations)
            task_priority: priority of this vehicle's task
            task_manager:  TaskManager instance to look up blocker's priority

        Returns:
            Filtered list of ConflictEvent
        """
        from vehicle.vehicle_registry import registry
        our_weight = PRIORITY_WEIGHT.get(task_priority, 2)
        conflicts = []
        seen_segs = set()

        for entry in schedule:
            # ── 1. Segment conflict with priority ──────────
            if entry.segment_id not in seen_segs:
                blocker_vid = reservations.check_conflict(
                    entry.segment_id,
                    entry.enter_tick,
                    entry.exit_tick,
                    exclude_vid=exclude_vid
                )
                if blocker_vid is not None:
                    blocker_rec = registry.get(blocker_vid)
                    blocker_priority = "NORMAL"
                    if blocker_rec and blocker_rec.task_id:
                        blocker_task = task_manager.get_task(blocker_rec.task_id)
                        if blocker_task:
                            blocker_priority = blocker_task.priority

                    blocker_weight = PRIORITY_WEIGHT.get(blocker_priority, 2)
                    if blocker_weight >= our_weight:
                        conflicts.append(ConflictEvent(
                            segment_id = entry.segment_id,
                            enter_a    = entry.enter_tick,
                            exit_a     = entry.exit_tick,
                            vehicle_b  = blocker_vid,
                            enter_b    = entry.enter_tick,
                            exit_b     = entry.exit_tick,
                            priority_b = blocker_priority
                        ))
                        seen_segs.add(entry.segment_id)

            # ── 2. Node conflict (always enforced regardless of priority) ──
            # Node safety is a hard constraint — no priority override allowed
            node_blocker = reservations.check_node_conflict(
                entry.to_node,
                entry.exit_tick,
                exclude_vid=exclude_vid
            )
            if node_blocker is not None:
                node_seg_id = f"NODE__{entry.to_node}"
                conflicts.append(ConflictEvent(
                    segment_id = node_seg_id,
                    enter_a    = entry.exit_tick,
                    exit_a     = entry.exit_tick + 1,
                    vehicle_b  = node_blocker,
                    enter_b    = entry.exit_tick,
                    exit_b     = entry.exit_tick + 1,
                    priority_b = "NORMAL"
                ))

        return conflicts

    def has_conflict(self, schedule: list, exclude_vid: str = None) -> bool:
        """
        Quick boolean check — any segment OR node conflict in the schedule?
        Faster than predict() when you only need a yes/no answer.
        """
        for entry in schedule:
            if reservations.check_conflict(
                entry.segment_id,
                entry.enter_tick,
                entry.exit_tick,
                exclude_vid=exclude_vid
            ):
                return True
            # Also check node
            if reservations.check_node_conflict(
                entry.to_node,
                entry.exit_tick,
                exclude_vid=exclude_vid
            ):
                return True
        return False


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

collision_pred = CollisionPredictor()
