"""
brain/speed_coordinator.py — Adaptive Speed Coordinator with ML Enhancement

PURPOSE:
    Generates per-segment speed multiplier profiles based on current traffic
    density. Used by the Schedule Builder to determine how many ticks each
    segment will take.

    TWO MODES:
    ─────────
    1. RULE-BASED (default / fallback):
       mult = max(MIN_SPEED_MULT, 1.0 - density * DENSITY_WEIGHT)
       Simple linear formula keyed on current segment density.

    2. ML-ENHANCED (active after first training run ≈ tick 300):
       Uses a 2-layer numpy MLP that predicts the optimal speed multiplier
       from 8 features: near/far future density, junction type, station
       proximity, fleet state, and time-of-day cycle.

       Model trains automatically in the background every 300 ticks.
       If the model isn't ready, or if its output is invalid,
       the rule-based formula acts as the fallback automatically.

STATION PROXIMITY:
    Vehicles near stations slow down regardless of model output.
    This ensures safe merging at pickup/drop zones.

TRAINING DATA COLLECTION:
    Every time generate() is called, each segment's formula output and
    feature vector are recorded as a training sample. If that segment later
    has a confirmed collision, the sample label is revised downward.
"""

from __future__ import annotations
import math
from config import (DENSITY_WEIGHT, MIN_SPEED_MULT, LOOKAHEAD_TICKS,
                    STATION_PROXIMITY_MULT, BUFFER_RADIUS)
from brain.road_graph import graph
from brain.reservation_manager import reservations

# ML Adaptive Speed Model — imported with graceful fallback
_ml_speed_ready: bool = False
try:
    from brain.ml.speed_model import ml_speed
    from brain.ml.speed_features import build_features as _build_speed_features
    _ml_speed_ready = True
except Exception as _e:
    print(f"[SpeedCoordinator] ML import skipped: {_e}")
    ml_speed = None              # type: ignore
    _build_speed_features = None  # type: ignore


class SpeedCoordinator:
    """
    Generates per-segment speed profiles based on reservation density.

    The profile influences how the Schedule Builder computes tick durations —
    slower segments take more ticks, shifting the vehicle's time window forward
    and potentially avoiding conflicts with existing reservations.

    When the ML model is trained (≥300 ticks), it replaces the linear formula.
    """

    def __init__(self):
        # Station pixel positions set by main.py after loading map
        self._station_positions: list = []   # list of (x, y) tuples

    def set_stations(self, positions: list) -> None:
        """
        Register all station positions for proximity slowdown.
        Called once from main.py after map_config.json is loaded.

        Args:
            positions: list of (x_px, y_px) tuples for all pickups and drops
        """
        self._station_positions = positions
        # Also pass to feature extractor for normalisation
        try:
            from brain.ml.allocator_features import set_map_dimensions
            # Infer rough map size from station positions
        except Exception:
            pass

    def generate(self, route: list, current_tick: int) -> list:
        """
        Generate a speed multiplier profile for a route.

        For each segment, tries the ML model first. Falls back to the
        rule-based formula if the model is not ready or fails.

        Args:
            route:        ordered list of node_ids
            current_tick: current simulation tick (for density window)

        Returns:
            List of floats, one per segment in the route.
            1.0 = full speed, MIN_SPEED_MULT = minimum speed.
            Length = len(route) - 1
        """
        if len(route) < 2:
            return []

        profile = []
        lookahead_end = current_tick + LOOKAHEAD_TICKS

        # Gather fleet state once for all segments in this route
        fleet_util = 0.0
        fleet_queue = 0
        try:
            from brain.metrics_tracker import metrics
            from brain.task_manager import task_mgr
            fleet_util  = metrics.fleet_utilisation
            fleet_queue = task_mgr.pending_count()
        except Exception:
            pass

        for i in range(len(route) - 1):
            from_node = route[i]
            to_node   = route[i + 1]
            seg_id    = f"{from_node}__{to_node}"

            # Current density (always computed for fallback and feature building)
            density = reservations.density(seg_id, current_tick, lookahead_end)

            # Rule-based formula (baseline)
            formula_mult = max(MIN_SPEED_MULT, 1.0 - density * DENSITY_WEIGHT)

            # Station proximity check (applied AFTER model/formula)
            to_pos      = graph.node_pos(to_node)
            near_station = self._is_near_station(to_pos[0], to_pos[1])
            if near_station:
                formula_mult = min(formula_mult, STATION_PROXIMITY_MULT)

            # ── ML path ──────────────────────────────────────
            mult = formula_mult   # start with formula as default
            if _ml_speed_ready and ml_speed is not None and ml_speed.is_ready():
                try:
                    features = _build_speed_features(
                        segment_id       = seg_id,
                        to_node          = to_node,
                        current_tick     = current_tick,
                        is_near_station  = near_station,
                        fleet_utilisation = fleet_util,
                        fleet_queue_size = fleet_queue,
                    )
                    ml_mult = ml_speed.predict(features)
                    if MIN_SPEED_MULT <= ml_mult <= 1.0:
                        mult = ml_mult   # ML takes over
                        # Apply station cap even on ML output
                        if near_station:
                            mult = min(mult, STATION_PROXIMITY_MULT)
                except Exception:
                    pass  # fallthrough to formula_mult

                # Record training sample continuously (bootstrap labels)
                try:
                    features = _build_speed_features(
                        segment_id       = seg_id,
                        to_node          = to_node,
                        current_tick     = current_tick,
                        is_near_station  = near_station,
                        fleet_utilisation = fleet_util,
                        fleet_queue_size = fleet_queue,
                    )
                    ml_speed.record_sample(features, formula_mult)
                except Exception:
                    pass

            profile.append(mult)

        return profile

    def segment_multiplier(self, segment_id: str, current_tick: int) -> float:
        """
        Compute the speed multiplier for a single segment at the current tick.

        Used by vehicle.py for real-time speed re-evaluation when a vehicle
        enters a segment (corrects stale speed profiles).

        Tries ML model first, falls back to formula.

        Args:
            segment_id:   e.g., "2_0__3_0"
            current_tick: current tick

        Returns:
            Speed multiplier float
        """
        density = reservations.density(
            segment_id, current_tick, current_tick + LOOKAHEAD_TICKS
        )
        formula_mult = max(MIN_SPEED_MULT, 1.0 - density * DENSITY_WEIGHT)

        if _ml_speed_ready and ml_speed is not None and ml_speed.is_ready():
            try:
                # Parse to_node from segment_id ("from__to")
                parts = segment_id.split("__")
                if len(parts) == 2:
                    to_node = parts[1]
                    to_pos  = graph.node_pos(to_node)
                    near_st = self._is_near_station(to_pos[0], to_pos[1])
                    features = _build_speed_features(
                        segment_id       = segment_id,
                        to_node          = to_node,
                        current_tick     = current_tick,
                        is_near_station  = near_st,
                        fleet_utilisation = 0.0,
                        fleet_queue_size = 0,
                    )
                    ml_mult = ml_speed.predict(features)
                    if MIN_SPEED_MULT <= ml_mult <= 1.0:
                        return ml_mult
            except Exception:
                pass

        return formula_mult

    def _is_near_station(self, x: float, y: float) -> bool:
        """
        Check if a pixel position is within BUFFER_RADIUS of any station.

        Args:
            x, y: pixel coordinates

        Returns:
            True if within buffer radius of any pickup or drop station
        """
        for sx, sy in self._station_positions:
            if math.hypot(x - sx, y - sy) <= BUFFER_RADIUS:
                return True
        return False


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

speed_coordinator = SpeedCoordinator()
