"""
brain/task_manager.py — Task Lifecycle Management

PURPOSE:
    Manages every task from creation through completion or failure.
    Maintains the pending queue, handles state transitions, implements
    priority escalation (starvation prevention), and task expiry.

STATE MACHINE:
    PENDING → ASSIGNED → MOVING_TO_PICKUP → MOVING_TO_DESTINATION → COMPLETED
                     ↓                 ↓
                  FAILED            FAILED (vehicle had cargo → task stays FAILED)

PRIORITY ESCALATION (P4 fix):
    Tasks that stay PENDING too long have their effective_priority boosted.
    Every STARVATION_THRESHOLD ticks, LOW tasks become NORMAL-priority for
    allocation scoring. This prevents a continuous stream of HIGH tasks
    from starving LOW tasks indefinitely.
    Note: task.priority (the enum) never changes — only effective_priority
    used by the allocator. Conflict resolution still uses original priority.

TASK EXPIRY (P14 fix):
    Tasks pending longer than TASK_EXPIRY_TICKS are automatically expired.
    This prevents phantom tasks from accumulating in a broken system.
"""

from __future__ import annotations
from typing import Optional
from config import (PRIORITY_WEIGHT, STARVATION_THRESHOLD,
                    TASK_EXPIRY_TICKS)
from core.models import Task, TaskState
from core.event_bus import bus, EventType


class TaskManager:
    """
    Full lifecycle manager for all tasks.

    Internal storage:
        _tasks[task_id] = Task
        _pending: list of task_ids in PENDING state, sorted by effective priority
    """

    def __init__(self):
        self._tasks: dict[str, Task] = {}

    # ─── Create ───────────────────────────────────────────

    def add(self, task: Task) -> None:
        """
        Register a new task. Called by TaskGenerator.

        The task starts in PENDING state with effective_priority
        equal to its base priority weight.

        Args:
            task: fully constructed Task dataclass
        """
        task.state = TaskState.PENDING
        task.effective_priority = PRIORITY_WEIGHT.get(task.priority, 2)
        self._tasks[task.task_id] = task

    # ─── Query ────────────────────────────────────────────

    def get_task(self, task_id: str) -> Optional[Task]:
        """Return a task by id, or None if not found."""
        return self._tasks.get(task_id)

    def get_pending(self) -> list:
        """
        Return all tasks currently in PENDING state.
        Sorted by effective_priority DESCENDING (highest priority first).
        Pre-assigned tasks (assigned_to is not None) are excluded —
        they already have a vehicle committed to them.

        Returns:
            Sorted list of Task objects (highest priority / most urgent first)
        """
        pending = [
            t for t in self._tasks.values()
            if t.state == TaskState.PENDING and t.assigned_to is None
        ]
        # Sort: highest effective_priority first, then oldest first (FIFO within same priority)
        pending.sort(key=lambda t: (-t.effective_priority, t.created_tick))
        return pending

    def all_tasks(self) -> list:
        """Return all tasks (any state)."""
        return list(self._tasks.values())

    def pending_count(self) -> int:
        """How many tasks are in PENDING state."""
        return sum(1 for t in self._tasks.values() if t.state == TaskState.PENDING)

    # ─── State Transitions ────────────────────────────────

    def assign(self, task_id: str, vehicle_id: str, tick: int = 0) -> None:
        """
        Mark a task as assigned to a vehicle.
        Called by the allocator when a vehicle is selected.

        Args:
            task_id:    task to assign
            vehicle_id: vehicle receiving the task
            tick:       current simulation tick
        """
        task = self._tasks.get(task_id)
        if not task:
            return
        task.state = TaskState.ASSIGNED
        task.assigned_to = vehicle_id
        task.assign_tick = tick

    def mark_pickup_enroute(self, task_id: str) -> None:
        """Vehicle is now heading to pickup."""
        task = self._tasks.get(task_id)
        if task:
            task.state = TaskState.MOVING_TO_PICKUP

    def mark_to_destination(self, task_id: str) -> None:
        """Vehicle has picked up and is heading to drop."""
        task = self._tasks.get(task_id)
        if task:
            task.state = TaskState.MOVING_TO_DESTINATION

    def complete(self, task_id: str, tick: int = 0) -> None:
        """
        Mark a task as successfully completed.
        Called by CommManager when vehicle arrives at drop.

        Args:
            task_id: completed task
            tick:    completion tick (for throughput calculation)
        """
        task = self._tasks.get(task_id)
        if not task:
            return
        task.state = TaskState.COMPLETED
        task.complete_tick = tick
        bus.emit_event(EventType.TASK_COMPLETED, tick,
                       {"task_id": task_id, "vehicle_id": task.assigned_to})

    def fail(self, task_id: str, reason: str = "vehicle_failure") -> None:
        """
        Mark a task as failed and requeue it if before pickup.

        Args:
            task_id: failed task
            reason:  "vehicle_failure" | "timeout" | "emergency_stop"
        """
        task = self._tasks.get(task_id)
        if not task:
            return

        if reason == "vehicle_failure" and task.state in (
            TaskState.ASSIGNED, TaskState.MOVING_TO_PICKUP
        ):
            # Task can be requeued — vehicle failed before picking up
            task.state = TaskState.PENDING
            task.assigned_to = None
            task.assign_tick = None
            # Small priority boost to get it reassigned quickly
            task.effective_priority = min(
                PRIORITY_WEIGHT["HIGH"],
                task.effective_priority + 1
            )
        else:
            # Task failed terminally (vehicle had cargo, or timeout)
            task.state = TaskState.FAILED

    def requeue(self, task_id: str) -> None:
        """
        Force a task back to PENDING (used by failure_manager for cargo-free failures).
        """
        task = self._tasks.get(task_id)
        if task:
            task.state = TaskState.PENDING
            task.assigned_to = None
            task.assign_tick = None

    # ─── Periodic Maintenance ─────────────────────────────

    def tick_update(self, current_tick: int) -> None:
        """
        Periodic maintenance. Called every tick from central_brain.

        1. Priority escalation: boost effective_priority of old PENDING tasks
        2. Expiry: mark very old PENDING tasks as FAILED (TIMEOUT)

        Args:
            current_tick: current simulation tick
        """
        for task in list(self._tasks.values()):
            if task.state != TaskState.PENDING:
                continue

            age = current_tick - task.created_tick

            # Priority escalation: every STARVATION_THRESHOLD ticks,
            # boost effective_priority by 1 (capped at HIGH weight)
            if age > 0 and age % STARVATION_THRESHOLD == 0:
                max_priority = PRIORITY_WEIGHT["HIGH"]
                if task.effective_priority < max_priority:
                    task.effective_priority += 1

            # Task expiry
            if age >= TASK_EXPIRY_TICKS:
                task.state = TaskState.FAILED
                from brain.brain_logger import brain_log
                from brain.metrics_tracker import metrics
                metrics.tasks_expired += 1
                brain_log(f"Task {task.task_id} EXPIRED after {age} ticks")


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

task_mgr = TaskManager()


# Patch EventBus to add emit_event helper
def _emit_event(self, event_type: str, tick: int, data: dict = None):
    from core.models import SystemEvent
    self.emit(SystemEvent(event_type=event_type, tick=tick, data=data or {}))

import types
bus.emit_event = types.MethodType(_emit_event, bus)
