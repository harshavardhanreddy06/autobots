"""
brain/__init__.py

PURPOSE:
    Marks the 'brain' directory as a Python package.
    The brain layer contains all Central Brain intelligence modules.
    It depends on core/ and is used by vehicle/ and visualization/.
"""
