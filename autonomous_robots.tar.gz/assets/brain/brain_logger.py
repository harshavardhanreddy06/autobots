"""
brain/brain_logger.py — Central Brain Decision Log

PURPOSE:
    Provides the brain_log() function used by every brain module to record
    decisions, events, and status messages into a fixed-size ring buffer.

    This buffer is displayed in the UI panel as the "Brain Log" section,
    showing the last N decisions the Central Brain made.

WHY A SEPARATE MODULE:
    brain_log() is called by 15+ brain modules. If it lived in central_brain.py,
    every module would need to import central_brain, creating circular imports.
    By putting it here with zero upward dependencies, all modules can safely
    import it without any circularity.

DESIGN:
    A collections.deque with maxlen=DECISION_LOG_SIZE acts as the ring buffer.
    When the buffer is full, the oldest entry is automatically dropped.
    Thread-safe enough for single-threaded simulation.
"""

from collections import deque
from config import DECISION_LOG_SIZE


# ─────────────────────────────────────────────────────────
# THE LOG BUFFER
# Fixed-size ring buffer — oldest entry dropped when full.
# ─────────────────────────────────────────────────────────

_log: deque = deque(maxlen=DECISION_LOG_SIZE)


def brain_log(message: str) -> None:
    """
    Append a message to the brain decision log.

    Called by brain modules when they make a significant decision:
        - Task assigned to vehicle
        - Conflict resolved at Level N
        - Vehicle sent to parking
        - Deadlock detected and resolved
        - Failure handled

    Args:
        message: Human-readable description of the decision (keep it short)
    """
    _log.append(message)


def get_brain_log() -> list:
    """
    Return current log contents as a list (newest last).
    Called by the UI panel to render the log.
    """
    return list(_log)


def clear_brain_log() -> None:
    """Clear the log. Useful for testing or fresh starts."""
    _log.clear()
