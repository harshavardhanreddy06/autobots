"""
brain/route_planner.py — Density-Weighted A* Route Planner

PURPOSE:
    Finds the optimal path through the road graph from a start node
    to an end node. Uses A* with a density-weighted edge cost so that
    routes naturally flow around congested segments.

HOW A* WORKS HERE:
    Standard A* with:
        g(n) = actual cost from start to n (in hops + density penalty)
        h(n) = Manhattan distance heuristic from n to goal (in hops)
        f(n) = g(n) + h(n)

    Edge cost formula for segment (from_node → to_node):
        cost = 1.0 + DENSITY_WEIGHT * density(segment, now, now+LOOKAHEAD)

    This means:
        - Empty segment: cost = 1.0 (one hop)
        - 3 vehicles on segment: cost = 1.0 + 0.15*3 = 1.45
        - 7 vehicles: cost = 1.0 + 0.15*7 = 2.05

    A* naturally avoids high-cost (dense) segments in favor of
    slightly longer but emptier routes.

CACHE INTEGRATION:
    Computed routes are cached in decision_cache by (start, end) key.
    Cache is invalidated when nodes are disabled (exact membership check).

BLOCKED SEGMENTS SUPPORT:
    Decision Engine Level 5 (reroute) can pass a set of blocked_segs
    to force the planner around specific conflicting segments.
"""

from __future__ import annotations
import heapq
from typing import Optional
from config import DENSITY_WEIGHT, LOOKAHEAD_TICKS
from core.decision_cache import cache
from brain.road_graph import graph
from brain.reservation_manager import reservations


class RoutePlanner:
    """
    A* pathfinder on the road graph with density-weighted edge costs.
    """

    def plan(self, start_node: str, end_node: str,
             current_tick: int = 0,
             blocked_segs: Optional[set] = None,
             use_cache: bool = True) -> Optional[list]:
        """
        Find the optimal route from start_node to end_node.

        Args:
            start_node:   starting graph node id (e.g., "1_0")
            end_node:     destination node id (e.g., "3_1")
            current_tick: used for density queries
            blocked_segs: set of segment_ids to treat as impassable
                          (used by Decision Engine Level 5 reroute)
            use_cache:    whether to use/update the route cache

        Returns:
            Ordered list of node_ids from start to end (inclusive),
            or None if no path exists.
        """
        if start_node == end_node:
            return [start_node]

        # Check cache first (skip cache if density-weighted or segments blocked)
        if use_cache and not blocked_segs and current_tick == 0:
            cached = cache.get_route(start_node, end_node)
            if cached:
                return cached

        # A* priority queue: (f_score, node_id)
        open_set: list = [(0, start_node)]
        came_from: dict = {}
        g_score: dict = {start_node: 0.0}

        while open_set:
            _, current = heapq.heappop(open_set)

            if current == end_node:
                return self._reconstruct(came_from, current)

            for neighbor in graph.neighbors(current):
                seg_id = f"{current}__{neighbor}"

                # Skip blocked segments (Level 5 reroute)
                if blocked_segs and seg_id in blocked_segs:
                    continue

                # Edge cost: 1.0 base + density penalty
                density = reservations.density(
                    seg_id,
                    current_tick,
                    current_tick + LOOKAHEAD_TICKS
                )
                edge_cost = 1.0 + DENSITY_WEIGHT * density

                tentative_g = g_score[current] + edge_cost

                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    h = graph.heuristic(neighbor, end_node)
                    f = tentative_g + h
                    heapq.heappush(open_set, (f, neighbor))

        return None   # No path found

    def plan_around_segments(self, start_node: str, end_node: str,
                             blocked_segs: set,
                             current_tick: int = 0) -> Optional[list]:
        """
        Level 5 reroute: find a path that avoids specific conflicting segments.

        Tries with blocked_segs first. If no path found, tries with only
        the origin nodes of the blocking segments disabled (wider avoidance).
        Falls back to unrestricted plan if both fail.

        Args:
            start_node:   start
            end_node:     destination
            blocked_segs: set of segment_ids to avoid
            current_tick: for density queries

        Returns:
            Best available route, or None if completely unreachable
        """
        # Try 1: avoid specific segments
        route = self.plan(start_node, end_node, current_tick,
                          blocked_segs=blocked_segs, use_cache=False)
        if route:
            return route

        # Try 2: disable origin nodes of blocking segments
        blocked_nodes = set()
        for seg in blocked_segs:
            parts = seg.split("__")
            if parts:
                blocked_nodes.add(parts[0])

        for node in blocked_nodes:
            graph.disable_node(node)
        try:
            route = self.plan(start_node, end_node, current_tick, use_cache=False)
        finally:
            for node in blocked_nodes:
                graph.enable_node(node)

        if route:
            return route

        # Try 3: unrestricted (accept some conflict risk, Decision Engine will handle)
        return self.plan(start_node, end_node, current_tick, use_cache=False)

    def _reconstruct(self, came_from: dict, current: str) -> list:
        """Rebuild path from came_from chain (A* backtracking)."""
        path = [current]
        while current in came_from:
            current = came_from[current]
            path.append(current)
        return list(reversed(path))


# ─────────────────────────────────────────────────────────
# GLOBAL SINGLETON
# ─────────────────────────────────────────────────────────

route_planner = RoutePlanner()
